import random
import numpy as np
import torch
import os

def is_cuda_available():
    """检查CUDA是否可用"""
    return torch.cuda.is_available()

def set_seed(seed):
    """
    设置所有随机种子以保证可重复性
    参考:
    - https://pytorch.org/docs/stable/notes/randomness.html
    - https://pytorch.org/docs/stable/generated/torch.use_deterministic_algorithms.html
    """
    # Python内置随机数
    random.seed(seed)
    
    # NumPy随机数
    np.random.seed(seed)
    
    # PyTorch随机数
    torch.manual_seed(seed)
    
    # 如果使用CUDA
    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)  # 多GPU情况
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False
    
    # 设置环境变量
    os.environ['PYTHONHASHSEED'] = str(seed)
    os.environ['CUBLAS_WORKSPACE_CONFIG'] = ':4096:8'  # 为确定性算法设置
    
    # 启用确定性算法
    torch.use_deterministic_algorithms(True)