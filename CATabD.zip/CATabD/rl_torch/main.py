import logging
import platform
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import torch
from torch.utils.tensorboard import SummaryWriter

from data_loader import DataGenerator_read_data
from models import Actor
from rewards import get_Reward
from helpers.config_graph import get_config
from helpers.dir_utils import create_dir
from helpers.log_helper import LogHelper
from helpers.tf_utils import set_seed
from helpers.analyze_utils import (
    convert_graph_int_to_adj_mat,
    graph_prunned_by_coef,
    count_accuracy,
    graph_prunned_by_coef_2nd,
)
from helpers.lambda_utils import BIC_lambdas


device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
torch.set_default_device(device)  # 全局设置默认设备

def generate_DAG(d=6, prob=0.5, low=0.5, high=2.0):
    g_random = np.float32(np.random.rand(d, d) < prob)
    g_random = np.tril(g_random, -1)
    U = np.round(np.random.uniform(low=low, high=high, size=[d, d]), 1)
    U[np.random.randn(d, d) < 0] *= -1
    W = (g_random != 0).astype(float) * U
    p = np.random.permutation(d)
    W[:, :] = W[p, :]
    W[:, :] = W[:, p]
    return W


def prepare_data(opt_path=None):
    create_dir(opt_path + "/cdrl/data")
    df = pd.read_csv(opt_path + "/vae/data/processed_data.csv")
    np.save(opt_path + "/cdrl/data/data.npy", df.to_numpy().astype(np.float32))
    dag = generate_DAG(d=df.shape[1], prob=0.5, low=0.5, high=2.0)
    np.save(opt_path + "/cdrl/data/DAG.npy", dag)


def train_cdrl(opt_path=None, config=None, epochs=30000):
    config.nb_epoch = epochs
    output_dir = opt_path + f"/cdrl/models"
    create_dir(output_dir)
    LogHelper.setup(log_path=f"{output_dir}/training.log", level_str="INFO")
    _logger = logging.getLogger(__name__)
    _logger.info(f"Python version is {platform.python_version()}")

    config.save_model_path = f"{output_dir}/model"
    config.summary_dir = f"{output_dir}/summary"
    config.plot_dir = f"{output_dir}/plot"
    config.graph_dir = f"{output_dir}/graph"

    create_dir(config.summary_dir)
    create_dir(config.plot_dir)
    create_dir(config.graph_dir)

    set_seed(config.seed)
    _logger.info(f"Configuration parameters: {vars(config)}")

    file_path = f"{opt_path}/cdrl/data/data.npy"
    solution_path = f"{opt_path}/cdrl/data/DAG.npy"
    training_set = DataGenerator_read_data(
        file_path, solution_path, config.normalize, config.transpose
    )

    # Set penalty weights
    if config.lambda_flag_default:
        sl, su, strue = BIC_lambdas(
            training_set.inputdata,
            None,
            None,
            training_set.true_graph.T,
            config.reg_type,
            config.score_type,
        )
        lambda1 = 0
        lambda1_upper = 5
        lambda1_update_add = 1
        lambda2 = 1 / (10 ** (np.round(config.max_length / 3)))
        lambda2_upper = 0.01
        lambda2_update_mul = 10
        lambda_iter_num = config.lambda_iter_num

        _logger.info(f"Original sl: {sl}, su: {su}, strue: {strue}")
        _logger.info(
            f"Transformed sl: {sl}, su: {su}, lambda2: {lambda2}, true: {(strue - sl) / (su - sl) * lambda1_upper}"
        )
    else:
        sl = config.score_lower
        su = config.score_upper
        if config.score_bd_tight:
            lambda1 = 2
            lambda1_upper = 2
        else:
            lambda1 = 0
            lambda1_upper = 5
            lambda1_update_add = 1
        lambda2 = 1 / (10 ** (np.round(config.max_length / 3)))
        lambda2_upper = 0.01
        lambda2_update_mul = config.lambda2_update
        lambda_iter_num = config.lambda_iter_num

    # Initialize actor
    actor = Actor(config)
    optimizer = torch.optim.Adam(actor.parameters())

    callreward = get_Reward(
        actor.batch_size,
        config.max_length,
        actor.input_dimension,
        training_set.inputdata,
        sl,
        su,
        lambda1_upper,
        config.score_type,
        config.reg_type,
        config.l1_graph_reg,
        False,
    )

    _logger.info("Finished creating training dataset, actor model and reward class")

    # Training variables
    rewards_avg_baseline = []
    rewards_batches = []
    reward_max_per_batch = []
    lambda1s = []
    lambda2s = []
    graphss = []
    probsss = []
    max_rewards = []
    max_reward = float("-inf")
    image_count = 0
    accuracy_res = []
    accuracy_res_pruned = []
    max_reward_score_cyc = (lambda1_upper + 1, 0)

    # Tensorboard writer
    writer = SummaryWriter(config.summary_dir)

    _logger.info("Starting training.")

    for i in range(1, config.nb_epoch + 1):
        if config.verbose:
            _logger.info(f"Start training for {i}-th epoch")

        # Forward pass
        graphs_feed = actor.graphs.detach().cpu().numpy()
        reward_feed = callreward.cal_rewards(graphs_feed, lambda1, lambda2)

        # Update max reward
        max_reward = -callreward.update_scores(
            [max_reward_score_cyc], lambda1, lambda2
        )[0]
        max_reward_batch = float("inf")
        max_reward_batch_score_cyc = (0, 0)

        for reward_, score_, cyc_ in reward_feed:
            if reward_ < max_reward_batch:
                max_reward_batch = reward_
                max_reward_batch_score_cyc = (score_, cyc_)

        max_reward_batch = -max_reward_batch

        if max_reward < max_reward_batch:
            max_reward = max_reward_batch
            max_reward_score_cyc = max_reward_batch_score_cyc

        # Average reward per batch
        reward_batch_score_cyc = np.mean(reward_feed[:, 1:], axis=0)

        if config.verbose:
            _logger.info("Finish calculating reward for current batch of graph")

        # Prepare data for training
        reward_tensor = torch.tensor(-reward_feed[:, 0], dtype=torch.float32,requires_grad=True)
        graphs_tensor = torch.tensor(graphs_feed, dtype=torch.float32, requires_grad=True)

        actor.reward_ = reward_tensor
        actor.graphs_ = graphs_tensor

        # Training step
        optimizer.zero_grad()
        actor.build_optim()

        # Logging
        if i == 1 or i % 500 == 0:
            if i >= 500:
                writer.add_scalar("reward_batch", reward_batch_score_cyc[0], i)
                writer.add_scalar("max_reward", max_reward, i)

            _logger.info(
                f"[iter {i}] reward_batch: {reward_batch_score_cyc[0]}, "
                f"max_reward: {max_reward}, max_reward_batch: {max_reward_batch}"
            )

            # Plotting
            plt.figure(1)
            plt.plot(rewards_batches, label="reward per batch")
            plt.plot(max_rewards, label="max reward")
            plt.legend()
            plt.savefig(f"{config.plot_dir}/reward_batch_average.png")
            plt.close()

            image_count += 1
            fig = plt.figure(2)
            fig.suptitle(f"Iteration: {i}")
            ax = fig.add_subplot(1, 2, 1)
            ax.set_title("recovered_graph")
            ax.imshow(
                np.around(actor.graph_batch.detach().cpu().numpy().T).astype(int),
                cmap=plt.cm.gray,
            )
            ax = fig.add_subplot(1, 2, 2)
            ax.set_title("ground truth")
            ax.imshow(training_set.true_graph, cmap=plt.cm.gray)
            plt.savefig(
                f"{config.plot_dir}/recovered_graph_iteration_{image_count}.png"
            )
            plt.close()

        # Update lambda parameters
        if (i + 1) % lambda_iter_num == 0:
            ls_kv = callreward.update_all_scores(lambda1, lambda2)
            max_rewards_re = callreward.update_scores(max_rewards, lambda1, lambda2)
            rewards_batches_re = callreward.update_scores(
                rewards_batches, lambda1, lambda2
            )
            reward_max_per_batch_re = callreward.update_scores(
                reward_max_per_batch, lambda1, lambda2
            )

            np.save(f"{config.graph_dir}/solvd_dict.npy", np.array(ls_kv))
            pd.DataFrame(np.array(max_rewards_re)).to_csv(
                f"{output_dir}/max_rewards.csv"
            )
            pd.DataFrame(rewards_batches_re).to_csv(f"{output_dir}/rewards_batch.csv")
            pd.DataFrame(reward_max_per_batch_re).to_csv(
                f"{output_dir}/reward_max_batch.csv"
            )
            pd.DataFrame(lambda1s).to_csv(f"{output_dir}/lambda1s.csv")
            pd.DataFrame(lambda2s).to_csv(f"{output_dir}/lambda2s.csv")

            graph_int, score_min, cyc_min = (
                np.int64(ls_kv[0][0]),
                ls_kv[0][1][1],
                ls_kv[0][1][-1],
            )

            if cyc_min < 1e-5:
                lambda1_upper = score_min
            lambda1 = min(lambda1 + lambda1_update_add, lambda1_upper)
            lambda2 = min(lambda2 * lambda2_update_mul, lambda2_upper)

            _logger.info(
                f"[iter {i+1}] lambda1 {lambda1}, upper {lambda1_upper}, "
                f"lambda2 {lambda2}, upper {lambda2_upper}, "
                f"score_min {score_min}, cyc_min {cyc_min}"
            )

            graph_batch = convert_graph_int_to_adj_mat(graph_int)

            if config.reg_type == "LR":
                graph_batch_pruned = np.array(
                    graph_prunned_by_coef(graph_batch, training_set.inputdata)
                )
            elif config.reg_type == "QR":
                graph_batch_pruned = np.array(
                    graph_prunned_by_coef_2nd(graph_batch, training_set.inputdata)
                )

            # Calculate accuracy
            acc_est = count_accuracy(training_set.true_graph, graph_batch.T)
            acc_est2 = count_accuracy(training_set.true_graph, graph_batch_pruned.T)

            fdr, tpr, fpr, shd, nnz = (
                acc_est["fdr"],
                acc_est["tpr"],
                acc_est["fpr"],
                acc_est["shd"],
                acc_est["pred_size"],
            )
            fdr2, tpr2, fpr2, shd2, nnz2 = (
                acc_est2["fdr"],
                acc_est2["tpr"],
                acc_est2["fpr"],
                acc_est2["shd"],
                acc_est2["pred_size"],
            )

            accuracy_res.append((fdr, tpr, fpr, shd, nnz))
            accuracy_res_pruned.append((fdr2, tpr2, fpr2, shd2, nnz2))

            np.save(f"{output_dir}/accuracy_res.npy", np.array(accuracy_res))
            np.save(f"{output_dir}/accuracy_res2.npy", np.array(accuracy_res_pruned))

            _logger.info(
                f"before pruning: fdr {fdr}, tpr {tpr}, fpr {fpr}, shd {shd}, nnz {nnz}"
            )
            _logger.info(
                f"after pruning: fdr {fdr2}, tpr {tpr2}, fpr {fpr2}, shd {shd2}, nnz {nnz2}"
            )

        # Save model
        if i % max(1, int(config.nb_epoch / 5)) == 0 and i != 0:
            torch.save(actor.state_dict(), f"{config.save_model_path}/model_{i}.pth")
            _logger.info(f"Model saved at iteration {i}")

    # Save final model
    torch.save(actor.state_dict(), f"{config.save_model_path}/actor_final.pth")
    _logger.info("Training COMPLETED!")
    writer.close()


if __name__ == "__main__":
    num_f = {
        "adult": 15,
        "abalone": 9,
        "pm25": 12,
        "statlog": 37,
        "shuttle": 10,
        "asia": 8,
        "cancer": 5,
        "survey": 6,
        "syn": 12,
    }

    dataset = "adult"
    opt_path = f"output/{dataset}"
    import os

    os.environ["CUDA_VISIBLE_DEVICES"] = "0"

    config, _ = get_config()
    config.seed = 105
    config.device = "cuda" if torch.cuda.is_available() else "cpu"
    config.opt_path = opt_path
    config.max_length = num_f[dataset]
    config.hidden_dim = 64
    config.lambda_flag_default = True
    config.transpose = True

    prepare_data(opt_path=opt_path)
    torch.autograd.set_detect_anomaly(True)
    train_cdrl(opt_path=opt_path, config=config, epochs=20000)
