import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.tensorboard import SummaryWriter

from .decoder import TransformerDecoder

# from .critic import Critic
from .critic2 import Critic2


class Actor(nn.Module):
    def __init__(self, config):
        super(Actor, self).__init__()
        self.config = config
        self.device = config.device
        self.is_train = True

        # Data config
        self.batch_size = config.batch_size
        self.max_length = config.max_length
        self.input_dimension = config.input_dimension

        # Reward config
        self.register_buffer("avg_baseline", torch.tensor(config.init_baseline))
        self.alpha = config.alpha

        # Training config
        self.global_step = 0
        self.global_step2 = 0
        self.lr1_start = config.lr1_start
        self.lr1_decay_rate = config.lr1_decay_rate
        self.lr1_decay_step = config.lr1_decay_step
        self.lr2_start = config.lr1_start
        self.lr2_decay_rate = config.lr1_decay_rate
        self.lr2_decay_step = config.lr1_decay_step

        # Tensorboard
        self.writer = SummaryWriter()

        # placeholder
        self.reward_ = torch.zeros(self.batch_size).to(torch.float32)
        self.graphs_ = torch.zeros(
            self.batch_size, self.max_length, self.max_length
        ).to(torch.float32)

        # Build modules
        self.build_features()
        self.build_tabddpm()
        self.build_permutation()
        self.build_critic()

        # Optimizers
        self.optim1 = torch.optim.Adam(
            self.parameters(), lr=self.lr1_start, betas=(0.9, 0.99), eps=1e-7
        )
        self.optim2 = torch.optim.Adam(
            self.critic.parameters(), lr=self.lr2_start, betas=(0.9, 0.99), eps=1e-7
        )
        
        self.to(self.device)

    def build_permutation(self):
        # if self.config.encoder_type == "TransformerEncoder":
        #     self.encoder = TransformerEncoder(self.config, self.is_train)
        # elif self.config.encoder_type == "GATEncoder":
        #     pass
        # else:
        #     raise NotImplementedError("Current encoder type is not implemented yet!")

        if self.config.decoder_type == "SingleLayerDecoder":
            self.decoder = TransformerDecoder(self.config, self.is_train)
        elif self.config.decoder_type == "TransformerDecoder":
            self.decoder = TransformerDecoder(self.config, self.is_train)
        elif self.config.decoder_type == "BilinearDecoder":
            pass
        elif self.config.decoder_type == "NTNDecoder":
            pass
        else:
            raise NotImplementedError("Current decoder type is not implemented yet!")

        self.decoder.to(self.device)
        
        # Diffusion Step
        encoder_output = torch.zeros(
            (self.config.max_length, self.config.batch_size, self.config.hidden_dim),
            dtype=torch.float32,
            device=self.device
        )
        
        for i in range(self.config.max_length):
            row_indices = torch.randint(
                high=self.data[i].size(0),
                size=(self.config.batch_size,),
                device=self.device
            )
            encoder_output[i] = self.data[i][row_indices]
        
        self.encoder_output = encoder_output.permute(1, 0, 2).contiguous()
        encoder_output = self.encoder_output.clone()
        self.encoder_output.requires_grad_(True)

        # Decoder Step
        samples, scores, entropy = self.decoder(self.encoder_output.clone())

        graphs_gen = torch.stack(samples).permute(1, 0, 2).clone()
        self.graphs = graphs_gen
        self.graph_batch = torch.mean(graphs_gen, dim=0)

        logits_for_rewards = torch.stack(scores)
        entropy_for_rewards = torch.stack(entropy)
        logits_for_rewards = logits_for_rewards.permute(1, 0, 2)

        self.test_scores = torch.sigmoid(logits_for_rewards)[:2]
        log_probss = F.binary_cross_entropy_with_logits(
            logits_for_rewards, self.graphs_, reduction="none"
        )
        self.log_softmax = torch.mean(log_probss, dim=[1, 2])
        self.entropy_regularization = torch.mean(entropy_for_rewards, dim=[1, 2])

        # Log to tensorboard
        self.writer.add_scalar("log_softmax", self.log_softmax.mean())

    def build_critic(self):
        self.critic = Critic2(self.config)
        self.critic.predict_rewards(self.encoder_output)
        self.writer.add_scalar("critic_predictions", self.critic.predictions.mean())

    def build_tabddpm(self):
        self.data = []
        opt_path = self.config.opt_path
        sample_save_path = f"{opt_path}/tabppdm/data/sampled_data.csv"

        for i in range(self.config.max_length):
            path = sample_save_path.replace("sampled_data.csv", f"sampled_data_{i}.csv")
            df = pd.read_csv(path)
            # 转换为Tensor并移动到相同设备
            tensor_data = torch.from_numpy(df.to_numpy()).float().to(self.device)
            tensor_data.requires_grad_(False)
            self.data.append(tensor_data)

    def build_features(self):
        opt_path = self.config.opt_path
        path = f"{opt_path}/vae/data/encode/encoded_data.csv"
        df = pd.read_csv(path)
        self.node_features = torch.tensor(df.groupby(df.columns[-1]).mean().to_numpy())

    def build_reward(self):
        self.writer.add_scalar("reward", self.reward_.mean())

    def build_optim(self):
        self.encoder_output.requires_grad_(True)
        self.graphs.requires_grad_(True)
        # Update baseline
        reward_mean = torch.mean(self.reward_)
        self.avg_baseline = (
            self.alpha * self.avg_baseline + (1.0 - self.alpha) * reward_mean
        )
        self.writer.add_scalar("average_baseline", self.avg_baseline)

        # Actor learning rate decay
        self.lr1 = self.lr1_start * (
            self.lr1_decay_rate ** (self.global_step / self.lr1_decay_step)
        )
        for param_group in self.optim1.param_groups:
            param_group["lr"] = self.lr1

        # Critic learning rate decay
        self.lr2 = self.lr2_start * (
            self.lr2_decay_rate ** (self.global_step2 / self.lr2_decay_step)
        )
        for param_group in self.optim2.param_groups:
            param_group["lr"] = self.lr2

        # Reinforce loss
        self.reward_baseline = (
            self.reward_ - self.avg_baseline - self.critic.predictions
        ).detach()
        self.loss1 = torch.mean(
            self.reward_baseline * self.log_softmax
        ) - self.lr1 * torch.mean(self.entropy_regularization)

        # Critic loss
        self.loss2 = F.mse_loss(
            self.reward_ - self.avg_baseline, self.critic.predictions, reduction="none"
        )
        weights = 1.0  # Could be modified as in original code
        self.loss2 = torch.mean(weights * self.loss2)

        # Log losses
        self.writer.add_scalar("loss1", self.loss1)
        self.writer.add_scalar("loss2", self.loss2)

        # Clip gradients and optimize
        torch.nn.utils.clip_grad_norm_(self.parameters(), 1.0)
        self.optim1.zero_grad()
        self.loss1.backward(retain_graph=True)
        self.optim1.step()
        self.global_step += 1

        torch.nn.utils.clip_grad_norm_(self.critic.parameters(), 1.0)
        self.optim2.zero_grad()
        self.loss2.backward()
        self.optim2.step()
        self.global_step2 += 1
