import torch
import torch.nn as nn
import torch.nn.functional as F
from torch_geometric.nn import GATConv, global_mean_pool

class Critic(nn.Module):
    """简化版GNN Critic，保留GAT和池化架构"""
    
    def __init__(self, config):
        super(Critic, self).__init__()
        self.config = config

        # 网络配置
        self.num_neurons = config.hidden_dim
        
        # 初始化GAT层和池化层
        self.gat_layer = GATConv(
            in_channels=self.num_neurons,
            out_channels=self.num_neurons,
            heads=1,  # 单头注意力
            concat=True,
            dropout=0.0,
            add_self_loops=True  # 自动添加自连接
        )
        
        # 输出层
        self.output_layer = nn.Linear(self.num_neurons, 1)
        
        # 初始化权重
        self._initialize_weights()
    
    def _initialize_weights(self):
        # Xavier初始化GAT层
        nn.init.xavier_normal_(self.gat_layer.lin_src.weight)
        nn.init.xavier_normal_(self.gat_layer.lin_dst.weight)
        nn.init.xavier_normal_(self.gat_layer.att_src)
        nn.init.xavier_normal_(self.gat_layer.att_dst)
        
        # Xavier初始化输出层
        nn.init.xavier_normal_(self.output_layer.weight)
        nn.init.zeros_(self.output_layer.bias)
    
    def forward(self, adj, node_features):
        """
        简化的GNN预测流程
        adj: [batch_size, max_length, max_length] 邻接矩阵
        node_features: [batch_size, max_length, hidden_dim] 节点特征
        """
        batch_size, max_length, _ = adj.size()
        
        # 准备图数据格式 (PyTorch Geometric需要边缘索引格式)
        edge_indices = []
        batch_indices = []
        
        # 为每个图样本创建边缘索引
        for b in range(batch_size):
            # 获取当前图的邻接矩阵
            adj_matrix = adj[b]
            
            # 转换为边缘索引格式 [2, num_edges]
            edge_index = (adj_matrix > 0).nonzero().t()
            
            # 添加偏移量以处理批次
            edge_index[0] += b * max_length
            edge_index[1] += b * max_length
            
            edge_indices.append(edge_index)
            batch_indices.extend([b] * max_length)
        
        # 合并所有图的边缘索引
        edge_index = torch.cat(edge_indices, dim=1)
        
        # 重塑节点特征 [batch_size * max_length, hidden_dim]
        x = node_features.view(-1, self.num_neurons)
        
        # 批次索引 [batch_size * max_length]
        batch = torch.tensor(batch_indices, device=node_features.device)
        
        # GAT层处理
        h = F.relu(self.gat_layer(x, edge_index))
        
        # 全局平均池化 [batch_size, hidden_dim]
        graph_embed = global_mean_pool(h, batch)
        
        # 输出层 [batch_size]
        predictions = self.output_layer(graph_embed).squeeze()
        
        return predictions