import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.distributions import Bernoulli


class MultiheadAttention(nn.Module):
    def __init__(self, num_units, num_heads, dropout_rate):
        super(MultiheadAttention, self).__init__()
        self.num_units = num_units
        self.num_heads = num_heads
        self.dropout_rate = dropout_rate

        self.Q = nn.Linear(num_units, num_units)
        self.K = nn.Linear(num_units, num_units)
        self.V = nn.Linear(num_units, num_units)
        self.dropout = nn.Dropout(dropout_rate)
        self.ln = nn.LayerNorm(num_units)

    def forward(self, inputs, is_training=True):
        # Linear projections
        Q = self.Q(inputs)
        K = self.K(inputs)
        V = self.V(inputs)
        Q = F.relu(Q, inplace=False)
        K = F.relu(K, inplace=False)
        V = F.relu(V, inplace=False)

        # Split and concat
        Q_ = torch.cat(torch.split(Q, self.num_units // self.num_heads, dim=2), dim=0)
        K_ = torch.cat(torch.split(K, self.num_units // self.num_heads, dim=2), dim=0)
        V_ = torch.cat(torch.split(V, self.num_units // self.num_heads, dim=2), dim=0)

        # Multiplication
        outputs = torch.matmul(Q_, K_.transpose(1, 2))

        # Scale
        outputs = outputs / (K_.size(-1) ** 0.5)

        # Activation
        outputs = F.softmax(outputs, dim=-1)

        # Dropouts
        outputs = self.dropout(outputs)

        # Weighted sum
        outputs = torch.matmul(outputs, V_)

        # Restore shape
        outputs = torch.cat(
            torch.split(outputs, outputs.size(0) // self.num_heads, dim=0), dim=2
        )

        # Residual connection
        outputs = outputs + inputs.clone()

        # Normalize
        outputs = self.ln(outputs)

        return outputs


class FeedForward(nn.Module):
    def __init__(self, num_units):
        super(FeedForward, self).__init__()
        self.conv1 = nn.Conv1d(num_units[1], num_units[0], kernel_size=1)
        self.conv2 = nn.Conv1d(num_units[0], num_units[1], kernel_size=1)
        self.ln = nn.LayerNorm(num_units[1])

    def forward(self, inputs, is_training=True):
        x = inputs.transpose(1, 2).contiguous()  # 确保内存连续
        x = self.conv1(x)
        x = F.relu(x, inplace=False)  # 使用inplace=False避免原地修改
        x = self.conv2(x)
        x = F.relu(x, inplace=False)  # 使用inplace=False避免原地修改
        x = x.transpose(1, 2).contiguous()
        x = x + inputs.clone()  # 确保不原地修改
        x = self.ln(x)
        return x


class TransformerDecoder(nn.Module):
    def __init__(self, config, is_train):
        super(TransformerDecoder, self).__init__()
        self.batch_size = config.batch_size
        self.max_length = config.max_length
        self.input_dimension = config.hidden_dim
        self.input_embed = config.hidden_dim
        self.num_heads = config.num_heads
        self.num_stacks = config.num_stacks

        self.is_training = is_train

        # Initialize layers
        self.embedding = nn.Conv1d(
            in_channels=self.input_embed,
            out_channels=self.input_embed,
            kernel_size=1,  # 对应TensorFlow中W_embed的第一个维度1
            stride=1,
            padding="valid",  # 对应TensorFlow的"VALID"
        )
        self.ln = nn.LayerNorm(self.input_embed)

        self.attention_layers = nn.ModuleList(
            [
                MultiheadAttention(self.input_embed, self.num_heads, 0.0)
                for _ in range(self.num_stacks)
            ]
        )

        self.ffn_layers = nn.ModuleList(
            [
                FeedForward([self.input_embed, self.input_embed])
                for _ in range(self.num_stacks)
            ]
        )

        self.readout = nn.Conv1d(self.input_embed, self.max_length, kernel_size=1)

        self.samples = []
        self.mask_scores = []
        self.entropy = []
        self.mask = 0

    def forward(self, inputs):
        all_user_embedding = torch.mean(inputs, dim=1)
        inputs_with_all_user_embedding = torch.cat(
            [inputs, all_user_embedding.unsqueeze(1).expand(-1, self.max_length, -1)],
            dim=-1,
        )

        # 修改1：确保所有操作都不原地修改张量
        embedded_input = self.embedding(
            inputs.permute(0, 2, 1).contiguous()
        )  # 添加contiguous()
        embedded_input = embedded_input.permute(
            0, 2, 1
        ).contiguous()  # 添加contiguous()
        enc = self.ln(embedded_input)

        for i in range(self.num_stacks):
            enc = self.attention_layers[i](enc, self.is_training)
            enc = self.ffn_layers[i](enc, self.is_training)

        # 修改2：确保readout操作不破坏计算图
        enc_transposed = enc.transpose(1, 2).contiguous()
        conv_output = self.readout(enc_transposed.clone())
        adj_prob = conv_output.clone().transpose(1, 2).contiguous()  # 关键修复
        
        samples = []
        mask_scores = []
        entropy = []

        for i in range(self.max_length):
            position = torch.ones(inputs.size(0), dtype=torch.long) * i
            mask = F.one_hot(position, self.max_length).float()
            masked_score = adj_prob[:, i, :] - (1e8 * mask)
            prob = Bernoulli(logits=masked_score)
            sampled_arr = prob.sample().detach().clone()  # 显式断开采样梯度
            entropy_val = prob.entropy().clone()  # 确保熵值不修改原张量

            samples.append(sampled_arr.clone())  # 显式detach和clone
            mask_scores.append(masked_score.clone())
            entropy.append(entropy_val.clone())

        return samples, mask_scores, entropy
