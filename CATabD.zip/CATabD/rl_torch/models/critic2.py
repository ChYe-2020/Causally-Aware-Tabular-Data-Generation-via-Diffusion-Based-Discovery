import torch
import torch.nn as nn
from torch.nn import functional as F


class Critic2(nn.Module):
    def __init__(self, config):
        super(Critic2, self).__init__()
        self.config = config

        # Data config
        self.batch_size = config.batch_size
        self.max_length = config.max_length
        self.input_dimension = config.input_dimension

        # Network config
        self.input_embed = config.hidden_dim
        self.num_neurons = config.hidden_dim

        # Baseline setup
        self.init_baseline = 0.0

        # Define layers
        self.ffn1 = nn.Linear(self.num_neurons, self.num_neurons)
        self.ffn2 = nn.Linear(self.num_neurons, 1)

        # Initialize weights
        nn.init.xavier_uniform_(self.ffn1.weight)
        nn.init.xavier_uniform_(self.ffn2.weight)
        self.ffn2.bias.data.fill_(self.init_baseline)

    def predict_rewards(self, encoder_output):
        # [Batch size, Sequence Length, Num_neurons] to [Batch size, Num_neurons]
        frame = torch.mean(encoder_output, dim=1)

        # FFN 1
        h0 = F.relu(self.ffn1(frame))

        # FFN 2
        self.predictions = self.ffn2(h0).squeeze()