# CTabDM: Causality-Aware Tabular Data Generation with Diffusion Models

## Overview
CATabD is a novel framework for generating synthetic tabular data while preserving causal dependencies between columns. It integrates:
- **Diffusion Models** for high-fidelity data generation
- **Reinforcement Learning** for causal structure discovery
- **Bayesian Networks** for enforcing acyclicity constraints
The architecture of CTabDM is shown below:

![](image.png)


## Requirements

to run this project, you need to create 2 virtual environments:
- for training the TabVAE,Diffusion model:
  - Python 3.12
  - PyTorch 2.7
  - CUDA 12.6 (for GPU acceleration)
  - the required packages are listed in `requirements.txt` under `pre_models`
- for training the RL agent to discover the causal structure:
  - Python 3.6
  - nvidia-tensorflow 1.15 (if you have GPU that supports tensorflow-gpu==1.15 you can use it instead)
  - CUDA 12.6 (for GPU acceleration)
  - the required packages are listed in `requirements.txt` under `rl_training`

## Usage

### 1. Data Preparation

put your tabular dataset in the `datasets/` directory. The dataset should be in CSV format with the first row as headers.

### 2. Training the PreModels

modify the config in `main.py` under `pre_models/` to set the dataset and model parameters. 
```python
    dataset = "statlog" 
    opt_path = f"output/{dataset}"
    data_path = f"datasets/{dataset}.csv"
    config, _ = get_config()
    config.max_length = 37 # set the nums of columns in your dataset
```

then run the `main.py` script to train the VAE and Diffusion model:
```bash
python pre_models/main.py
```
### 3. Training the RL Agent

modify the config in `main.py` under `rl_training/` to set the dataset and model parameters. 
```python
    dataset = "statlog" 
    opt_path = f"output/{dataset}"
    data_path = f"datasets/{dataset}.csv"
    config, _ = get_config()
    config.max_length = 37 # set the nums of columns in your dataset
```

then run the `main.py` script to train the RL agent:
```bash
python rl_training/main.py
```

the results will be saved in the `output/` directory, including the trained model and the DAG structure discovered by the RL agent.

### 4. Evaluating Results

use the `sample.py` under the `rl_training` to generate synthetic data and evaluate its utility and privacy.


## Datasets

In the paper, we evaluate CTabDM on several benchmark datasets, including:
- Adult
- Abalone
- Shuttle
- Satellite
- Beijing PM2.5

## Third-Party Code Usage

This project incorporates code from the following open-source repositories:

| Project                                                                                                                      | License    |
| ---------------------------------------------------------------------------------------------------------------------------- | ---------- |
| [Causal Discovery with RL](https://github.com/huawei-noah/trustworthyAI/tree/master/research/Causal%20Discovery%20with%20RL) | Apache-2.0 |
| [TTVAE](https://github.com/coksvictoria/TTVAE/tree/main/baselines/tabddpm)                                                   | Apache-2.0 |

## Citation

