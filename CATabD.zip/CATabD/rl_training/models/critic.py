import tensorflow as tf
from spektral.layers import GlobalAvgPool, GraphAttention

class Critic(object):
    """简化版GNN Critic，保留GAT和池化架构"""
    
    def __init__(self, config):
        self.config = config

        # 网络配置
        self.num_neurons = config.hidden_dim
        self.initializer = tf.contrib.layers.xavier_initializer(dtype=tf.float32)
        
        # 初始化GAT层和池化层
        self.gat_layer = GraphAttention(
            self.num_neurons,
            activation='relu',
            kernel_initializer=self.initializer
        )
        self.global_pool = GlobalAvgPool()

    def predict_rewards(self, adj, node_features):
        """
        简化的GNN预测流程
        adj: [batch_size, max_length, max_length] 邻接矩阵
        node_features: [batch_size, max_length, hidden_dim] 节点特征
        """
        
        if not isinstance(node_features, tf.Tensor):
            node_features = tf.convert_to_tensor(node_features, dtype=tf.float32)
        
        # 归一化邻接矩阵 (添加自连接)
        adj_norm = adj + tf.eye(self.config.max_length)
        
        # GAT层处理
        with tf.variable_scope("gnn_layer"):
            h = self.gat_layer([node_features, adj_norm])
        
        # 全局平均池化
        with tf.variable_scope("pooling"):
            graph_embed = self.global_pool(h)  # [batch_size, hidden_dim]
        
        # 输出层
        with tf.variable_scope("output"):
            w = tf.get_variable("w", [self.num_neurons, 1], initializer=self.initializer)
            b = tf.Variable(0.0, name="b")
            predictions = tf.squeeze(tf.matmul(graph_embed, w) + b)
        
        self.predictions = predictions