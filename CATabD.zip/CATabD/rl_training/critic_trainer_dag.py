import os
import pandas as pd
import argparse
import logging
import pickle
import numpy as np
import tensorflow as tf
from tqdm import tqdm
import matplotlib
from datetime import datetime
from helpers.config_graph import get_config, print_config
from helpers.dir_utils import create_dir
from helpers.log_helper import LogHelper
from sklearn.preprocessing import StandardScaler
from spektral.layers import  GlobalAvgPool, GraphAttention
from spektral.utils import normalized_adjacency  # 邻接矩阵归一化
from typing import List, Tuple
from rewards import get_Reward  # 原代码中的reward计算函数
from helpers.lambda_utils import BIC_lambdas

matplotlib.use("Agg")  # 使用非交互式后端
tf.config.optimizer.set_jit(False)  # 在代码开头添加
import os
os.environ['XLA_FLAGS'] = '--xla_gpu_cuda_data_dir=/home/zh/.conda/envs/zh'

class RandomDAGGenerator:
    def __init__(self, config=None):
        self.config = config
        self.rng = np.random.RandomState(
            config.random_seed if hasattr(config, "random_seed") else None
        )

        # 默认边生成概率为0.3，可以通过config覆盖
        self.edge_prob = getattr(config, "edge_prob", 0.3)

    def generate_dag(self, nodes: List[str]) -> Tuple[np.ndarray, dict]:
        """
        完全随机生成邻接矩阵，不保证是DAG

        Args:
            nodes: 节点名称列表

        Returns:
            adj_matrix: 邻接矩阵，形状为[n_nodes, n_nodes]
            model_info: 包含模型信息的字典
        """
        n_nodes = len(nodes)

        # 为每个可能的边独立生成，包括自环
        adj_matrix = (self.rng.random((n_nodes, n_nodes)) < self.edge_prob).astype(
            np.float32
        )

        # 创建模型信息字典
        model_info = {
            "adjmat": pd.DataFrame(adj_matrix, index=nodes, columns=nodes),
            "nodes": nodes,
            "method": "fully_random",
            "edges": int(adj_matrix.sum()),
            "edge_prob": self.edge_prob,
        }

        return adj_matrix, model_info

    def _has_cycle(self, adj_matrix: np.ndarray) -> bool:
        """检查邻接矩阵是否有环"""
        n = adj_matrix.shape[0]
        visited = [False] * n
        path = [False] * n

        for node in range(n):
            if not visited[node]:
                if self._dfs_cycle_check(adj_matrix, node, visited, path):
                    return True
        return False

    def _dfs_cycle_check(self, adj_matrix, node, visited, path):
        """深度优先搜索检查环"""
        visited[node] = True
        path[node] = True

        for neighbor in np.where(adj_matrix[node] == 1)[0]:
            if not visited[neighbor]:
                if self._dfs_cycle_check(adj_matrix, neighbor, visited, path):
                    return True
            elif path[neighbor]:
                return True

        path[node] = False
        return False

    def generate_dag_dataset(
        self, nodes: List[str], num_dags: int, save_dir: str
    ) -> str:
        """
        批量生成DAG数据集并保存到文件

        Args:
            nodes: 节点名称列表
            num_dags: 要生成的DAG数量
            save_dir: 保存目录

        Returns:
            保存的文件路径
        """
        os.makedirs(save_dir, exist_ok=True)
        save_path = os.path.join(save_dir, f"rand_dags.npz")

        # 预分配数组
        adj_matrices = np.zeros((num_dags, len(nodes), len(nodes)), dtype=np.float32)

        # 生成DAG
        for i in tqdm(range(num_dags), desc="Generating DAGs"):
            adj_matrix, _ = self.generate_dag(nodes)
            adj_matrices[i] = adj_matrix

        # 保存到压缩文件
        np.savez_compressed(
            save_path, adj_matrices=adj_matrices, nodes=nodes, num_dags=num_dags
        )

        return save_path


# class BNGraphGenerator:
#     """使用bnlearn生成DAG图的封装类"""

#     def __init__(self, method_type: str = "hc", score_type: str = "bic"):
#         """
#         初始化BN图生成器

#         Args:
#             method_type: 结构学习方法，可选 'hc'(hill-climbing), 'tabu', 'pc'等
#             score_type: 评分类型，可选 'bic', 'k2', 'bdeu'等
#         """
#         self.method_type = method_type
#         self.score_type = score_type

#     # TODO: 使用gpu进行？
#     def generate_dag(
#         self,
#         data: pd.DataFrame,
#     ) -> Tuple[np.ndarray, dict]:
#         """
#         从数据生成DAG邻接矩阵

#         Args:
#             data: 输入数据，形状为[n_samples, max_length]

#         Returns:
#             adj_matrix: 邻接矩阵，形状为[max_length, max_length]
#             model_info: 包含模型信息的字典
#         """
#         # 使用bnlearn学习结构
#         dag = bn.structure_learning.fit(
#             data, methodtype=self.method_type, scoretype=self.score_type, verbose=0
#         )

#         # 获取邻接矩阵
#         adj_matrix = dag["adjmat"].values.astype(np.float32)

#         return adj_matrix, dag

#     def visualize_dag(self, dag: dict, save_path: Optional[str] = None):
#         """
#         可视化DAG图

#         Args:
#             dag: bnlearn返回的DAG字典
#             save_path: 图片保存路径，如果为None则不保存
#         """
#         # 可视化 不弹出
#         bn.plot(dag, interactive=False)

#         if save_path:
#             plt.savefig(save_path, dpi=300, bbox_inches="tight")
#         plt.close()

#     def generate_dag_dataset(
#         self,
#         data: pd.DataFrame,
#         num_dags: int,
#         save_dir: str,
#         n_samples: int = 1024,
#     ) -> str:
#         """
#         批量生成DAG数据集并保存到文件

#         Args:
#             data: 原始数据(用于学习结构)
#             num_dags: 要生成的DAG数量
#             save_dir: 保存目录
#             n_samples: 每个DAG采样的样本数量
#         Returns:
#             保存的文件路径
#         """
#         os.makedirs(save_dir, exist_ok=True)
#         save_path = os.path.join(save_dir, f"bn_dags.npz")

#         nodes = data.columns.tolist()
#         n_nodes = len(nodes)
#         adj_matrices = []
#         dags = []

#         for i in tqdm(range(num_dags), desc="Generating DAGs", leave=False):
#             # 随机选择n_samples行数据（允许重复采样）
#             row_indices = np.random.choice(len(data), size=n_samples, replace=False)
#             sampled_data = data.iloc[row_indices].copy()
#             adj, dag = self.generate_dag(sampled_data)
#             dags.append(dag)

#         # 去重：基于边集合的唯一性
#         unique_dags = {}
#         for dag in dags:
#             edges = frozenset(dag["model_edges"])
#             if edges not in unique_dags:
#                 unique_dags[edges] = dag
#                 adj_matrices.append(dag["adjmat"].values.astype(np.float32))

#         # 获取唯一DAG列表
#         dags = list(unique_dags.values())

#         print(f"Unique DAGs generated: {len(dags)}")

#         # 保存到压缩文件
#         np.savez_compressed(
#             save_path,
#             adj_matrices=adj_matrices,
#             nodes=nodes,
#             num_dags=num_dags,
#             method_type=self.method_type,
#             score_type=self.score_type,
#             dags=dags,
#         )

#         return save_path


class SpektralCritic(tf.keras.Model):
    """基于spektral库的GNN Critic实现"""

    def __init__(self, config, **kwargs):
        super(SpektralCritic, self).__init__(**kwargs)
        self.config = config
        self.config.n_samples = 1024  # 新增参数：单次采样数据量 TODO: 提取到config

        # 网络配置
        self.num_neurons = config.hidden_dim
        self.initializer = tf.keras.initializers.VarianceScaling(
            scale=1.0, mode="fan_avg", distribution="uniform"
        )

        # 使用spektral构建GNN（GAT GCN DAGNN） 可以先用一层
        self.gnn_layers = [
            # GCNConv(
            #     self.num_neurons, activation="relu", kernel_initializer=self.initializer
            # ),
            GraphAttention(
                self.num_neurons, activation="relu", kernel_initializer=self.initializer
            ),
            # DAGNNLayer(
            #     self.num_neurons,
            # ),
        ]

        # 全局池化层
        self.global_pool = GlobalAvgPool()

        # 输出层
        self.output_layer = tf.keras.layers.Dense(
            1,
            kernel_initializer=self.initializer,
            bias_initializer=tf.constant_initializer(0.0),
        )

    def call(self, inputs):
        """前向传播
        Args:
            inputs: 邻接矩阵 [batch_size, max_length, max_length]
        Returns:
            预测的reward值 [batch_size,]
        """
        # 1. 生成节点特征 TODO: 使用预先处理的embedding
        batch_size = tf.shape(inputs)[0]
        max_length = inputs.shape[1]
        node_features = tf.eye(max_length)  # [max_length, max_length]
        node_features = tf.tile(
            tf.expand_dims(node_features, 0), [batch_size, 1, 1]
        )  # [batch_size, max_length, max_length]

        # 2. 处理每个样本的图结构
        all_outputs = []
        for i in range(batch_size):
            # 获取当前样本的邻接矩阵和节点特征
            adj = inputs[i]  # [max_length, max_length]
            x = node_features[i]  # [max_length, max_length]

            # 归一化邻接矩阵（添加自连接）TODO: 已经是二值矩阵了 不知道是否需要归一化
            adj_norm = adj + tf.eye(max_length)  # 添加自连接

            # 通过GNN层
            h = x
            for layer in self.gnn_layers:
                h = layer([h, adj_norm], mask=None)

            # 全局池化
            graph_embedding = self.global_pool(h)  # [num_neurons]
            all_outputs.append(graph_embedding)

        # 3. 堆叠所有样本的图嵌入
        graph_embeddings = tf.stack(all_outputs, axis=0)  # [batch_size, num_neurons]

        # 4. 输出层 + 形状强制处理
        predictions = self.output_layer(graph_embeddings)

        # 确保输出形状为 [batch_size,]
        predictions = tf.reshape(predictions, [-1])  # 强制展平为一维数组 [batch_size,]
        
        # print(self.get_weights()[0][0][0][0])

        return predictions


class CriticTrainer:
    """修改后的Critic网络训练器，使用bnlearn生成DAG"""

    def __init__(self, config, data_path=None, opt_path=None, dataset_path=None):
        self.config = config
        self.dataset_path = dataset_path
        self.opt_path = opt_path
        self.setup_logging()
        self.setup_dirs()

        # Reward config
        self.avg_baseline = tf.Variable(
            config.init_baseline, trainable=False, name="moving_avg_baseline"
        )  # moving baseline for Reinforce
        self.alpha = config.alpha  # moving average update

        # 初始化组件 - 使用spektral GNN Critic
        self.critic = SpektralCritic(config)
        # self.graph_generator = BNGraphGenerator(method_type="hc", score_type="bic")
        self.random_dag_generator = RandomDAGGenerator(config)

        # 优化器
        self.optimizer = tf.keras.optimizers.Adam(learning_rate=config.lr1_start)
        self.loss_fn = tf.keras.losses.MeanSquaredError()

        # 加载数据
        if data_path:
            self.load_data(data_path)

        # 初始化reward计算器
        self.init_reward_calculator()

        self.init_tensorboard()

    def init_tensorboard(self):
        """初始化TensorBoard记录器"""
        self.train_log_dir = os.path.join(self.tensorboard_dir, "train")
        self.train_writer = tf.summary.create_file_writer(self.train_log_dir)

    def init_reward_calculator(self):
        """严格按照论文和原始代码逻辑初始化reward计算器"""
        batch_num = self.config.batch_size
        maxlen = self.config.max_length  # 变量数量d
        dim = self.config.input_dimension  # 输入维度

        # 1. 计算score的上下界 - 使用原始代码中的BIC_lambdas函数
        sl, su, _ = BIC_lambdas(
            self.data,
            None,  # 完全图(除去自环)
            None,  # 空图
            None,  # 如果没有真实图可以传None
            reg_type="LR",  # 线性回归
            score_type="BIC",  # BIC分数
        )

        # 手动设置上下界
        # sl = 2.49
        # su = 2.54

        # 2. 设置论文5.1节提到的参数
        lambda1_upper = 5  # 论文中的S0
        lambda1 = 0  # 初始λ1值(原始代码初始为0)
        lambda1_update_add = 1  # λ1每次增加量(原始代码)
        lambda2 = 1 / (10 ** (np.round(maxlen / 3)))  # 论文中的λ2=1/10^(d/3)
        lambda2_upper = 0.01  # λ2上限(原始代码)
        lambda2_update_mul = 10  # λ2每次乘以这个值(原始代码)
        lambda_iter_num = 1000  # λ更新频率(原始代码)

        # 3. 其他参数设置
        score_type = "BIC"  # 论文主要使用BIC score
        reg_type = "LR"  # 线性回归

        # 4. 初始化reward计算器
        self.reward_func = get_Reward(
            batch_num=batch_num,
            maxlen=maxlen,
            dim=dim,
            inputdata=self.data,
            sl=sl,
            su=su,
            lambda1_upper=lambda1_upper,
            score_type=score_type,
            reg_type=reg_type,
            l1_graph_reg=0.0,  # 论文中没有使用L1正则
            verbose_flag=False,  # 不需要详细输出
        )

        # 5. 保存lambda参数用于后续更新(与原始代码一致)
        self.lambda1 = lambda1
        self.lambda2 = lambda2
        self.lambda1_upper = lambda1_upper
        self.lambda1_update_add = 0  # 保持不变
        self.lambda2_update_mul = 1  # 保持不变
        self.lambda2_upper = lambda2_upper  # λ2上限(原始代码)
        self.lambda_iter_num = lambda_iter_num  # λ更新频率(原始代码)

        # 6. 记录日志
        self.logger.info(
            f"Reward calculator initialized with:\n"
            f"  sl={sl:.4f} (complete graph score)\n"
            f"  su={su:.4f} (empty graph score)\n"
            f"  lambda1={lambda1} (initial), upper={lambda1_upper}\n"
            f"  lambda2={lambda2:.6f} (initial), upper={self.lambda2_upper}\n"
            f"  update: λ1 += {self.lambda1_update_add}, λ2 *= {self.lambda2_update_mul}\n"
            f"  update frequency: every {self.lambda_iter_num} steps"
        )

    def setup_logging(self):
        """设置日志"""
        if self.opt_path:
            self.output_dir = "output/models/critic/{}".format(self.opt_path)
        else:
            self.output_dir = "output/models/critic/{}".format(
                datetime.now().strftime("%Y-%m-%d_%H-%M-%S-%f")[:-3]
            )
        create_dir(self.output_dir)
        LogHelper.setup(log_path=f"{self.output_dir}/training.log", level_str="INFO")
        self.logger = logging.getLogger(__name__)

    def setup_dirs(self):
        """创建必要的目录"""
        self.model_dir = f"{self.output_dir}/models"
        self.tensorboard_dir = f"{self.output_dir}/tensorboard"
        self.dag_visual_dir = f"{self.output_dir}/dag_visualizations"
        create_dir(self.model_dir)
        create_dir(self.tensorboard_dir)
        create_dir(self.dag_visual_dir)

    def load_data(self, data_path):
        """加载训练数据"""
        if data_path.endswith(".csv"):
            self.load_data_from_csv(data_path)
        elif data_path.endswith(".npy"):
            self.data = np.load(data_path).astype(np.float32)
            self.logger.info(f"Loaded data with shape: {self.data.shape}")
        else:
            raise ValueError("Unsupported data format. Use CSV or NPY.")

    def load_data_from_csv(self, csv_path):
        """从CSV文件加载数据并进行预处理"""
        try:
            # 读取CSV文件
            self.raw_data = pd.read_csv(csv_path)
            self.logger.info(f"成功加载CSV文件，形状: {self.raw_data.shape}")

            # 保存列名用于bnlearn
            self.column_names = self.raw_data.columns.tolist()

            self.scaler = StandardScaler()

            # 数据预处理
            numeric_cols = self.raw_data.select_dtypes(
                include=["float64", "int64"]
            ).columns
            self.raw_data[numeric_cols] = self.scaler.fit_transform(
                self.raw_data[numeric_cols]
            )

            # 转换为numpy数组
            self.data = self.raw_data.values
            self.logger.info(f"处理后数据形状: {self.data.shape}")

            # 更新配置参数
            self.config.input_dimension = self.raw_data.shape[1]  # 输入维度
            self.config.max_length = self.raw_data.shape[1]  # 变量数量d

        except Exception as e:
            self.logger.error(f"加载CSV文件失败: {str(e)}")
            raise

    def sample_batch(self, nums=None) -> List[pd.DataFrame]:
        """采样一批数据用于训练

        Args:
            nums: 采样的批次大小，默认为config.batch_size

        Returns:
            包含batch_size个DataFrame的列表，每个DataFrame形状为[n_samples, max_length]
        """
        if nums is None:
            nums = self.config.batch_size

        batch_data = []

        for _ in range(nums):
            # 随机选择n_samples行数据（允许重复采样）
            row_indices = np.random.choice(
                len(self.raw_data), size=self.config.n_samples, replace=True
            )
            sampled_data = self.raw_data.iloc[row_indices].copy()
            batch_data.append(sampled_data)

        return batch_data

    def load_dag_dataset(self, file_path: str) -> np.ndarray:
        """
        从文件加载预生成的DAG数据集

        Args:
            file_path: .npz文件路径

        Returns:
            邻接矩阵数组 [num_dags, max_length, max_length]
        """
        data = np.load(file_path, allow_pickle=True)
        adj_matrices = data["adj_matrices"]
        dags = "dags" in data and data["dags"]
        # self.logger.info(f"从 {file_path} 加载了 {len(adj_matrices)} 个DAG")
        return adj_matrices, dags

    def generate_batch_dags(self, batch_data: List[pd.DataFrame]) -> np.ndarray:
        """为一批数据生成DAG邻接矩阵

        Args:
            batch_data: 包含batch_size个DataFrame的列表

        Returns:
            邻接矩阵堆叠成的张量，形状为[batch_size, max_length, max_length]
        """
        # 如果已经加载了预生成的DAG数据集，则从中采样
        if self.dataset_path:
            adj_matrices, dags = self.load_dag_dataset(self.dataset_path)
            indices = np.random.choice(
                len(adj_matrices), size=len(batch_data), replace=True
            )
            return adj_matrices[indices]

        batch_adj = []

        for i, data in enumerate(batch_data):
            try:
                # 完全随机生成DAG
                adj_matrices, _ = self.random_dag_generator.generate_dag(
                    self.column_names
                )  # 使用随机生成器
                batch_adj.append(adj_matrices)

                # 每个epoch保存一次DAG可视化
                # if hasattr(self, "train_epoch") and self.train_epoch % 10 == 0 and i == 1:
                #     save_path = os.path.join(
                #         self.dag_visual_dir,
                #         f"epoch_{self.train_epoch}_sample_{i}.png",
                #     )
                #     self.graph_generator.visualize_dag(dag, save_path)

            except Exception as e:
                self.logger.error(f"生成DAG失败: {str(e)}")
                # 返回全零矩阵作为失败时的默认值
                batch_adj.append(
                    np.zeros((self.config.max_length, self.config.max_length))
                )

        return np.stack(batch_adj, axis=0).astype(np.float32)

    def compute_rewards(self, dags: np.ndarray) -> np.ndarray:
        """计算实际reward

        Args:
            dags: 邻接矩阵，形状为[batch_size, max_length, max_length]

        Returns:
            形状为[batch_size,]的reward数组
        """
        rewards = self.reward_func.cal_rewards(
            dags,  # 转换为numpy数组
            lambda1=self.lambda1,
            lambda2=self.lambda2,
        )
        print(f"max: {np.max(rewards[:, 0])}, min: {np.min(rewards[:, 0])}")
        return rewards[:, 0]  # 假设第一个维度是reward值

    def log_training_metrics(self, epoch, loss, dags, true_rewards, pred_rewards):
        """记录训练指标到TensorBoard"""
        with self.train_writer.as_default():
            # Reward对比
            tf.summary.scalar(
                "reward/true_reward_mean", tf.reduce_mean(true_rewards), step=epoch
            )
            tf.summary.scalar(
                "reward/pred_reward_mean", tf.reduce_mean(pred_rewards), step=epoch
            )
            # 计算并记录调整后的reward
            adjusted_rewards = true_rewards - self.avg_baseline.numpy() - pred_rewards
            tf.summary.scalar(
                "reward/adjusted_reward_mean", np.mean(adjusted_rewards), step=epoch
            )
            tf.summary.scalar("reward/baseline", self.avg_baseline, step=epoch)
            # Reward分布
            tf.summary.histogram("reward/true_rewards", true_rewards, step=epoch)
            tf.summary.histogram("reward/pred_rewards", pred_rewards, step=epoch)
            # 新增baseline记录
            tf.summary.histogram(
                "reward/adjusted_rewards", adjusted_rewards, step=epoch
            )

            # 基础指标
            tf.summary.scalar("loss/train_loss", loss, step=epoch)
            # tf.summary.scalar("learning_rate", self.optimizer.learning_rate, step=epoch)

            # # Critic参数统计
            # for var in self.critic.trainable_variables:
            #     tf.summary.histogram(f"critic/{var.name}", var, step=epoch)
            #     tf.summary.scalar(
            #         f"critic/{var.name}_mean", tf.reduce_mean(var), step=epoch
            #     )

            # # 图结构统计
            # tf.summary.scalar("graph/edge_density", tf.reduce_mean(dags), step=epoch)
            # tf.summary.histogram("graph/edge_weights", dags, step=epoch)

    def train_step(self) -> Tuple[float, np.ndarray, np.ndarray, np.ndarray]:
        """修改后的训练步骤，包含baseline逻辑"""
        # 1. 采样一批数据
        batch_data = self.sample_batch()

        # 2. 为这批数据生成DAG邻接矩阵
        dags = self.generate_batch_dags(batch_data)
        dag_tensor = tf.convert_to_tensor(dags, dtype=tf.float32)

        with tf.GradientTape() as tape:
            # 3. critic预测reward
            pred_rewards = self.critic(dag_tensor)

            # 4. 计算实际reward
            true_rewards = self.compute_rewards(dags)
            true_rewards_tensor = tf.convert_to_tensor(true_rewards, dtype=tf.float32)

            # 5. 计算baseline (与正式训练相同逻辑)
            reward_mean = tf.reduce_mean(true_rewards_tensor)
            self.base_op = self.avg_baseline.assign(
                self.alpha * self.avg_baseline + (1.0 - self.alpha) * reward_mean
            )

            # 6. 计算baseline调整后的reward
            adjusted_rewards = true_rewards_tensor - self.avg_baseline - pred_rewards

            # 7. 计算损失 (使用调整后的reward)
            loss = self.loss_fn(
                tf.stop_gradient(adjusted_rewards),  # 与正式训练相同的stop_gradient
                pred_rewards,
            )

        # 8. 计算梯度并更新
        gradients = tape.gradient(loss, self.critic.trainable_variables)
        self.optimizer.apply_gradients(zip(gradients, self.critic.trainable_variables))

        return loss.numpy(), dags, true_rewards, pred_rewards.numpy()

    def train(
        self,
        epochs: int,
        eval_freq: int = 0,
        test_data_path: str = None,
    ):
        """训练循环

        Args:
            epochs: 训练轮数
            eval_freq: 评估频率（每eval_freq轮评估一次）如果为0则不评估
            test_data_path: 评估数据路径（如果eval_during_training为True）
        """

        # 加载评估数据 如果没有 则在训练数据上评估 TODO: 反复load可能有开销
        if eval_freq > 0 and test_data_path:
            self.load_data(test_data_path)

        start_epoch = getattr(self, "train_epoch", 1)  # 获取当前epoch（如果有的话）

        for epoch in range(start_epoch, epochs + start_epoch):

            self.train_epoch = epoch

            # 更新lambda参数(每lambda_iter_num步更新一次)
            if epoch % self.lambda_iter_num == 0:
                self.lambda1 = min(
                    self.lambda1 + self.lambda1_update_add, self.lambda1_upper
                )
                self.lambda2 = min(
                    self.lambda2 * self.lambda2_update_mul, self.lambda2_upper
                )
                self.logger.info(
                    f"Updated lambda params: λ1={self.lambda1}, λ2={self.lambda2:.6f}"
                )

            # 执行训练步骤
            loss, dags, true_rewards, pred_rewards = self.train_step()

            # 记录日志
            self.logger.info(
                f"Epoch {epoch}/{epochs+start_epoch-1}, Loss: {loss:.4f}, "
                f"True Reward: {np.mean(true_rewards):.4f}, "
                f"Pred Reward: {np.mean(pred_rewards):.4f}"
            )

            # 记录TensorBoard指标
            self.log_training_metrics(epoch, loss, dags, true_rewards, pred_rewards)

            # 定期保存模型
            if epoch % 10 == 0:
                self.save_critic(
                    os.path.join(self.model_dir, f"critic_epoch_{epoch:04d}")
                )

            # 训练过程中评估
            if eval_freq > 0 and epoch % eval_freq == 0:
                self.eval_epoch = epoch
                eval_results = self.eval_step()

                # 记录评估指标
                with self.train_writer.as_default():
                    tf.summary.scalar(
                        f"eval/r2",
                        eval_results["global_metrics"]["r2"],
                        step=epoch,
                    )
                    tf.summary.scalar(
                        f"loss/eval_loss",
                        eval_results["global_metrics"]["mse"],
                        step=epoch,
                    )
                    tf.summary.scalar(
                        f"eval/pearson",
                        eval_results["global_metrics"]["pearson_correlation"],
                        step=epoch,
                    )
                    tf.summary.scalar(
                        f"eval/spearman",
                        eval_results["global_metrics"]["spearman_correlation"],
                        step=epoch,
                    )

    def eval_step(self, bs=None) -> dict:
        """
        在测试集上评估Critic模型的性能

        Args:
            test_data_path: 测试数据路径
            num_samples: 评估时采样的DAG数量

        Returns:
            包含两种指标的字典:
            - per_sample_metrics: 每个DAG的独立指标（用于可视化）
            - global_metrics: 整体统计指标
        """
        bs = bs or self.config.batch_size

        # 2. 生成评估用的DAG样本
        batch_data = self.sample_batch(nums=bs)

        # 3. 生成DAG邻接矩阵
        dags = self.generate_batch_dags(batch_data)
        dag_tensor = tf.convert_to_tensor(dags, dtype=tf.float32)

        # 4. 计算真实reward和预测reward
        true_rewards = self.compute_rewards(dags)
        pred_rewards = self.critic(dag_tensor).numpy()

        # ==================== 逐样本指标计算 ====================
        per_sample_metrics = {
            "true_reward": true_rewards,
            "pred_reward": pred_rewards,
            "absolute_error": np.abs(true_rewards - pred_rewards),
            "squared_error": (true_rewards - pred_rewards) ** 2,
        }

        # ==================== 全局指标计算 ====================
        # MSE/MAE/R2（整体计算）
        mse = np.mean(per_sample_metrics["squared_error"])
        mae = np.mean(per_sample_metrics["absolute_error"])
        ss_res = np.sum(per_sample_metrics["squared_error"])
        ss_tot = np.sum((true_rewards - np.mean(true_rewards)) ** 2)
        r2 = 1 - (ss_res / (ss_tot + 1e-10))

        # 相关性（整体计算）
        pearson_corr = np.corrcoef(true_rewards, pred_rewards)[0, 1]
        spearman_corr = (
            pd.DataFrame({"true": true_rewards, "pred": pred_rewards})
            .corr(method="spearman")
            .iloc[0, 1]
        )

        global_metrics = {
            "mse": float(mse),
            "mae": float(mae),
            "r2": float(r2),
            "pearson_correlation": float(pearson_corr),
            "spearman_correlation": float(spearman_corr),
            "true_reward_mean": float(np.mean(true_rewards)),
            "pred_reward_mean": float(np.mean(pred_rewards)),
            "true_reward_std": float(np.std(true_rewards)),
            "pred_reward_std": float(np.std(pred_rewards)),
        }

        return {
            "per_sample_metrics": per_sample_metrics,
            "global_metrics": global_metrics,
        }

    def eval(self, test_data_path: str, num_epochs: int, bs=None):
        """执行多轮评估并记录指标变化"""
        # 1. 加载测试数据
        self.load_data(test_data_path)

        # 初始化评估历史记录
        eval_history = {"mse": [], "mae": [], "r2": [], "pearson": [], "spearman": []}

        # 创建评估用的独立TensorBoard writer
        eval_writer = tf.summary.create_file_writer(
            os.path.join(self.tensorboard_dir, "eval")
        )

        # 多轮评估循环
        for epoch in tqdm(range(num_epochs), desc="Evaluating"):
            self.eval_epoch = epoch
            # 单次评估
            results = self.eval_step(bs)

            # 记录指标
            eval_history["mse"].append(results["global_metrics"]["mse"])
            eval_history["mae"].append(results["global_metrics"]["mae"])
            eval_history["r2"].append(results["global_metrics"]["r2"])
            eval_history["pearson"].append(
                results["global_metrics"]["pearson_correlation"]
            )
            eval_history["spearman"].append(
                results["global_metrics"]["spearman_correlation"]
            )

            # 记录到TensorBoard
            with eval_writer.as_default():
                for metric in eval_history:
                    tf.summary.scalar(
                        f"metrics/{metric}", eval_history[metric][-1], step=epoch
                    )

            # 可选：定期打印进度
            if epoch % 10 == 0:
                self.logger.info(
                    f"Epoch {epoch}: MSE={eval_history['mse'][-1]:.4f}, "
                    f"R²={eval_history['r2'][-1]:.4f}"
                )

        return eval_history

    def save_critic(self, path: str):
        """保存模型完整状态（包括当前epoch）"""
        os.makedirs(path, exist_ok=True)

        # 1. 保存模型权重
        weights = self.critic.get_weights()
        weights_path = os.path.join(path, "model_weights")
        os.makedirs(weights_path, exist_ok=True)

        for i, w in enumerate(weights):
            np.save(os.path.join(weights_path, f"weight_{i}.npy"), w)

        # 2. 保存优化器状态
        optimizer_path = os.path.join(path, "optimizer.pkl")
        with open(optimizer_path, "wb") as f:
            pickle.dump(
                {
                    "variables": [v.numpy() for v in self.optimizer.variables],
                    "learning_rate": float(self.optimizer.learning_rate.numpy()),
                },
                f,
            )

        # 3. 保存训练状态（关键修改：确保保存当前epoch）
        training_state_path = os.path.join(path, "training_state.pkl")
        with open(training_state_path, "wb") as f:
            pickle.dump(
                {
                    "current_epoch": getattr(self, "train_epoch", 0)
                    + 1,  # 保存下一个要训练的epoch
                    "lambda1": self.lambda1,
                    "lambda2": self.lambda2,
                    "config": self.config.__dict__,
                    "reward_params": {
                        "lambda1_upper": self.lambda1_upper,
                        "lambda2_upper": self.lambda2_upper,
                        "lambda1_update_add": self.lambda1_update_add,
                        "lambda2_update_mul": self.lambda2_update_mul,
                        "lambda_iter_num": self.lambda_iter_num,
                    },
                    "weight_shapes": [w.shape for w in weights],
                },
                f,
            )

        # 4. 保存数据预处理状态
        if hasattr(self, "scaler"):
            scaler_path = os.path.join(path, "scaler.pkl")
            with open(scaler_path, "wb") as f:
                pickle.dump(self.scaler, f)

        self.logger.info(
            f"完整模型状态保存到 {path} (当前epoch: {getattr(self, 'train_epoch', 0)})"
        )
        print(self.critic.get_weights()[0][0][0][0])

    def load_critic(self, path: str):
        """加载模型完整状态（恢复训练位置）"""
        try:
            # 1. 加载训练状态
            training_state_path = os.path.join(path, "training_state.pkl")
            with open(training_state_path, "rb") as f:
                state = pickle.load(f)

            # 恢复配置
            self.config = argparse.Namespace(**state["config"])

            # 2. 加载模型权重
            weights_path = os.path.join(path, "model_weights")
            weight_files = sorted(
                [f for f in os.listdir(weights_path) if f.startswith("weight_")]
            )
            loaded_weights = [
                np.load(os.path.join(weights_path, f)) for f in weight_files
            ]

            # 3. 重建模型
            self.critic = SpektralCritic(self.config)
            input_shape = (self.config.max_length, self.config.max_length)
            dummy_input = tf.zeros([1, *input_shape])
            _ = self.critic(dummy_input)  # 强制构建模型

            # 设置权重
            self.critic.set_weights(loaded_weights)

            # 4. 恢复优化器
            optimizer_path = os.path.join(path, "optimizer.pkl")
            with open(optimizer_path, "rb") as f:
                optimizer_state = pickle.load(f)

            self.optimizer = tf.keras.optimizers.Adam(
                learning_rate=optimizer_state["learning_rate"]
            )

            # 初始化优化器变量
            with tf.GradientTape() as tape:
                dummy_loss = tf.reduce_sum(self.critic(dummy_input))
            grads = tape.gradient(dummy_loss, self.critic.trainable_variables)
            self.optimizer.apply_gradients(zip(grads, self.critic.trainable_variables))

            # 恢复优化器状态
            for v, val in zip(self.optimizer.variables, optimizer_state["variables"]):
                v.assign(val)

            # 5. 恢复训练状态（关键修改：恢复epoch计数）
            self.lambda1 = state["lambda1"]
            self.lambda2 = state["lambda2"]
            self.train_epoch = state["current_epoch"]  # 恢复保存时的下一个epoch

            # 恢复reward参数
            reward_params = state["reward_params"]
            self.lambda1_upper = reward_params["lambda1_upper"]
            self.lambda2_upper = reward_params["lambda2_upper"]
            self.lambda1_update_add = reward_params["lambda1_update_add"]
            self.lambda2_update_mul = reward_params["lambda2_update_mul"]
            self.lambda_iter_num = reward_params["lambda_iter_num"]

            # 6. 加载数据预处理器
            scaler_path = os.path.join(path, "scaler.pkl")
            if os.path.exists(scaler_path):
                with open(scaler_path, "rb") as f:
                    self.scaler = pickle.load(f)

            self.logger.info(f"成功从 {path} 加载模型状态")
            self.logger.info(f"将从 epoch {self.train_epoch} 继续训练")
            print(self.critic.get_weights()[0][0][0][0])

        except Exception as e:
            self.logger.error(f"加载失败: {str(e)}")
            raise


def main():

    r = RandomDAGGenerator()

    # 获取配置
    config, _ = get_config()
    config.max_length = 15
    config.hidden_dim = 64


    # 创建训练器
    trainer = CriticTrainer(
        config,
        data_path="datasets/adult.csv",
        opt_path="test",
        # dataset_path="datasets/dags/bn_dags.npz",
        dataset_path=None,
    )
    # r.generate_dag_dataset(
    #     nodes=trainer.column_names,
    #     num_dags=10000,
    #     save_dir="datasets/dags",
    # )
    # b.generate_dag_dataset(
    #     data=trainer.raw_data,
    #     num_dags=10000,
    #     save_dir="datasets/dags",
    #     n_samples=1024,
    # )
    # a,d = trainer.load_dag_dataset("datasets/dags/bn_dags.npz")
    # b.visualize_dag(d[0], save_path="datasets/dags/test.png")

    # 加载模型
    # trainer.load_critic("output/models/critic/critic_epoch_20000")
    # print(trainer.critic.get_weights()[0][0][0][0])

    # 训练
    trainer.train(epochs=10, eval_freq=1)

    # 评估
    test_data_path = "datasets/adult.csv"  # 测试数据路径
    # eval_results = trainer.eval(test_data_path, num_epochs=100)


if __name__ == "__main__":
    main()
