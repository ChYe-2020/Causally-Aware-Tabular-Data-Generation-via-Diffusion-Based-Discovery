from ..kdb import *
from ..kdb import _add_uniform
from ..utils import *
from pgmpy.models import DiscreteBayesianNetwork
from pgmpy.sampling import BayesianModelSampling
from pgmpy.factors.discrete import TabularCPD
from sklearn.preprocessing import OrdinalEncoder, LabelEncoder
import numpy as np
import tensorflow as tf
import matplotlib.pyplot as plt
import networkx as nx
import joblib
import os
from pathlib import Path


class GANBLR:
    """
    The GANBLR Model.
    """

    def __init__(self) -> None:
        self._d = None
        self.__gen_weights = None
        self.batch_size = None
        self.epochs = None
        self.k = None
        self.constraints = None
        self._external_dag = None  # 存储外部传入的DAG
        self._ordinal_encoder = OrdinalEncoder(
            dtype=int, handle_unknown="use_encoded_value", unknown_value=-1, encoded_missing_value=-1
        )
        self._label_encoder = LabelEncoder()
        self.tensorboard_writer = None

    def fit(
        self,
        x,
        y,
        k=0,
        batch_size=32,
        epochs=10,
        warmup_epochs=1,
        verbose=1,
        save_dir="models",
        save_freq=5,
        tensorboard_dir=None,
        convergence_window=10,
        tolerance=0.01,
        min_epochs=20,
        dag=None,  # Optional external DAG
    ):
        """
        Fit the model to the given data.

        Parameters
        ----------
        x : array_like of shape (n_samples, n_features)
            Dataset to fit the model. The data should be discrete.

        y : array_like of shape (n_samples,)
            Label of the dataset.

        k : int, default=0
            Parameter k of ganblr model. Must be greater than 0. No more than 2 is Suggested.

        batch_size : int, default=32
            Size of the batch to feed the model at each step.

        epochs : int, default=0
            Number of epochs to use during training.

        warmup_epochs : int, default=1
            Number of epochs to use in warmup phase. Defaults to :attr:`1`.

        verbose : int, default=1
            Whether to output the log. Use 1 for log output and 0 for complete silence.

        save_dir : str, optional
            Directory to save model checkpoints. If None, no saving.

        save_freq : int, default=5
            Frequency (in epochs) to save model checkpoints.

        tensorboard_dir : str, default="logs"
            Directory to save TensorBoard logs. If None, no logging.

        Returns
        -------
        self : object
            Fitted model.
        """
        if verbose is None or not isinstance(verbose, int):
            verbose = 1

        # Initialize history tracking
        history = {"g_loss": [], "g_acc": [], "d_loss": [], "d_acc": []}

        # Prepare save directory
        if save_dir is not None:
            Path(save_dir).mkdir(parents=True, exist_ok=True)

        x = self._ordinal_encoder.fit_transform(x)
        y = self._label_encoder.fit_transform(y).astype(int)
        d = DataUtils(x, y)
        self._d = d
        self.k = k
        self.batch_size = batch_size
        d.get_kdbe_x(k, dag=dag)  # 生成dag结构

        if epochs > 0:
            if verbose:
                print(f"warmup run:")
            warmup_history = self._warmup_run(warmup_epochs, verbose=verbose)
            syn_data = self._sample(verbose=0)
            discriminator_label = np.hstack(
                [np.ones(d.data_size), np.zeros(d.data_size)]
            )

        # 初始化TensorBoard
        if tensorboard_dir is not None:
            Path(tensorboard_dir).mkdir(parents=True, exist_ok=True)
            self.tensorboard_writer = tf.summary.create_file_writer(tensorboard_dir)

        for i in range(epochs):
            discriminator_input = np.vstack([x, syn_data[:, :-1]])
            disc_input, disc_label = sample(
                discriminator_input, discriminator_label, frac=0.8
            )
            disc = self._discrim()
            d_history = disc.fit(
                disc_input, disc_label, batch_size=batch_size, epochs=1, verbose=0
            ).history
            prob_fake = disc.predict(x, verbose=0)
            ls = np.mean(-np.log(np.subtract(1, prob_fake)))
            g_history = self._run_generator(loss=ls).history
            syn_data = self._sample(verbose=0)

            # Record history
            history["g_loss"].append(g_history["loss"][0])
            history["g_acc"].append(g_history["accuracy"][0])
            history["d_loss"].append(d_history["loss"][0])
            history["d_acc"].append(d_history["accuracy"][0])

            if verbose:
                print(
                    f"Epoch {i+1}/{epochs}: G_loss = {history['g_loss'][-1]:.6f}, "
                    f"G_accuracy = {history['g_acc'][-1]:.6f}, "
                    f"D_loss = {history['d_loss'][-1]:.6f}, "
                    f"D_accuracy = {history['d_acc'][-1]:.6f}"
                )

            # Save model checkpoint
            if save_dir is not None and (i + 1) % save_freq == 0:
                checkpoint_path = Path(save_dir) / f"ganblr_epoch_{i+1}.joblib"
                self.save(checkpoint_path)
                if verbose:
                    print(f"Model saved to {checkpoint_path}")

            # 记录到TensorBoard
            if tensorboard_dir is not None:
                with self.tensorboard_writer.as_default():
                    tf.summary.scalar("Generator/loss", history["g_loss"][-1], step=i)
                    tf.summary.scalar(
                        "Generator/accuracy", history["g_acc"][-1], step=i
                    )
                    tf.summary.scalar(
                        "Discriminator/loss", history["d_loss"][-1], step=i
                    )
                    tf.summary.scalar(
                        "Discriminator/accuracy", history["d_acc"][-1], step=i
                    )
                    tf.summary.scalar("KL_Loss", ls, step=i)
                    tf.summary.histogram(
                        "Generator/weights", self.__gen_weights[0], step=i
                    )
                    self.tensorboard_writer.flush()

            # 收敛检测（至少训练min_epochs轮后开始检测）
            # if i >= min_epochs and len(history["g_loss"]) >= convergence_window:
            #     # 计算窗口内的相对波动率
            #     recent_g = history["g_loss"][-convergence_window:]
            #     recent_d = history["d_loss"][-convergence_window:]

            #     g_fluct = (max(recent_g) - min(recent_g)) / np.mean(recent_g)
            #     d_fluct = (max(recent_d) - min(recent_d)) / np.mean(recent_d)

            #     # 双重收敛条件
            #     if g_fluct < tolerance and d_fluct < tolerance:
            #         history["converged"] = True
            #         if verbose:
            #             print(
            #                 f"\nTraining converged at epoch {i+1} "
            #                 f"(G_fluct={g_fluct:.2%}, D_fluct={d_fluct:.2%})"
            #             )
            #         break

        # Save final model
        if save_dir is not None:
            final_path = Path(save_dir) / "ganblr_final.joblib"
            self.save(final_path)
            if verbose:
                print(f"Final model saved to {final_path}")

        self.training_history_ = history
        return self

    def evaluate(self, x, y, model="lr") -> float:
        """
        Perform a TSTR(Training on Synthetic data, Testing on Real data) evaluation.

        Parameters
        ----------
        x, y : array_like
            Test dataset.

        model : str or object
            The model used for evaluate. Should be one of ['lr', 'mlp', 'rf'], or a model class that have sklearn-style `fit` and `predict` method.

        Return:
        --------
        accuracy_score : float.

        """
        from sklearn.linear_model import LogisticRegression
        from sklearn.neural_network import MLPClassifier
        from sklearn.ensemble import RandomForestClassifier
        from sklearn.preprocessing import OneHotEncoder
        from sklearn.pipeline import Pipeline
        from sklearn.metrics import accuracy_score

        eval_model = None
        models = dict(
            lr=LogisticRegression, rf=RandomForestClassifier, mlp=MLPClassifier
        )
        if model in models.keys():
            eval_model = models[model]()
        elif hasattr(model, "fit") and hasattr(model, "predict"):
            eval_model = model
        else:
            raise Exception(
                "Invalid Arugument `model`, Should be one of ['lr', 'mlp', 'rf'], or a model class that have sklearn-style `fit` and `predict` method."
            )

        synthetic_data = self._sample()
        synthetic_x, synthetic_y = synthetic_data[:, :-1], synthetic_data[:, -1]
        x_test = self._ordinal_encoder.transform(x)
        y_test = self._label_encoder.transform(y)

        categories = self._d.get_categories()
        pipline = Pipeline(
            [
                (
                    "encoder",
                    OneHotEncoder(categories=categories, handle_unknown="ignore"),
                ),
                ("model", eval_model),
            ]
        )
        pipline.fit(synthetic_x, synthetic_y)
        pred = pipline.predict(x_test)
        return accuracy_score(y_test, pred)

    def sample(self, size=None, verbose=1) -> np.ndarray:
        """
        Generate synthetic data.

        Parameters
        ----------
        size : int or None
            Size of the data to be generated. set to `None` to make the size equal to the size of the training set.

        verbose : int, default=1
            Whether to output the log. Use 1 for log output and 0 for complete silence.

        Return:
        -----------------
        synthetic_samples : np.ndarray
            Generated synthetic data.
        """
        ordinal_data = self._sample(size, verbose)
        origin_x = self._ordinal_encoder.inverse_transform(ordinal_data[:, :-1])
        origin_y = self._label_encoder.inverse_transform(ordinal_data[:, -1]).reshape(
            -1, 1
        )
        return np.hstack([origin_x, origin_y])

    def _sample(self, size=None, verbose=1) -> np.ndarray:
        """
        Generate synthetic data in ordinal encoding format
        """
        if verbose is None or not isinstance(verbose, int):
            verbose = 1
        # basic varibles
        d = self._d
        feature_cards = np.array(d.feature_uniques)
        # ensure sum of each constraint group equals to 1, then re concat the probs
        _idxs = np.cumsum([0] + d._kdbe.constraints_.tolist())
        constraint_idxs = [(_idxs[i], _idxs[i + 1]) for i in range(len(_idxs) - 1)]

        probs = np.exp(self.__gen_weights[0])
        cpd_probs = [probs[start:end, :] for start, end in constraint_idxs]
        cpd_probs = np.vstack([p / p.sum(axis=0) for p in cpd_probs])

        # assign the probs to the full cpd tables
        idxs = np.cumsum([0] + d._kdbe.high_order_feature_uniques_)
        feature_idxs = [(idxs[i], idxs[i + 1]) for i in range(len(idxs) - 1)]
        have_value_idxs = d._kdbe.have_value_idxs_
        full_cpd_probs = []
        for have_value, (start, end) in zip(have_value_idxs, feature_idxs):
            # (n_high_order_feature_uniques, n_classes)
            cpd_prob_ = cpd_probs[start:end, :]
            # (n_all_combination) Note: the order is (*parent, variable)
            have_value_ravel = have_value.ravel()
            # (n_classes * n_all_combination)
            have_value_ravel_repeat = np.hstack([have_value_ravel] * d.num_classes)
            # (n_classes * n_all_combination) <- (n_classes * n_high_order_feature_uniques)
            full_cpd_prob_ravel = np.zeros_like(have_value_ravel_repeat, dtype=float)
            # full_cpd_prob_ravel[have_value_ravel_repeat] = cpd_prob_.T.ravel()
            # 如果使用传入的dag 可能出现实际数据中不存在的特征依赖 因此需要限制
            valid_positions = np.where(have_value_ravel_repeat)[0][: cpd_prob_.size]
            full_cpd_prob_ravel[valid_positions] = cpd_prob_.T.ravel()
            # (n_classes * n_parent_combinations, n_variable_unique)
            full_cpd_prob = full_cpd_prob_ravel.reshape(-1, have_value.shape[-1]).T
            full_cpd_prob = _add_uniform(full_cpd_prob, noise=0)
            full_cpd_probs.append(full_cpd_prob)

        # prepare node and edge names
        node_names = [str(i) for i in range(d.num_features + 1)]
        edge_names = [(str(i), str(j)) for i, j in d._kdbe.edges_]
        y_name = node_names[-1]

        # create TabularCPD objects
        evidences = d._kdbe.dependencies_
        feature_cpds = [
            TabularCPD(
                str(name),
                feature_cards[name],
                table,
                evidence=[y_name, *[str(e) for e in evidences]],
                evidence_card=[d.num_classes, *feature_cards[evidences].tolist()],
            )
            for (name, evidences), table in zip(evidences.items(), full_cpd_probs)
        ]
        y_probs = (d.class_counts / d.data_size).reshape(-1, 1)
        y_cpd = TabularCPD(y_name, d.num_classes, y_probs)

        import warnings

        with warnings.catch_warnings():
            warnings.simplefilter("ignore", category=RuntimeWarning)
            # create kDB model, then sample the data
            model = DiscreteBayesianNetwork(edge_names)
            model.add_cpds(y_cpd, *feature_cpds)
            sample_size = d.data_size if size is None else size
            result = BayesianModelSampling(model).forward_sample(
                size=sample_size, show_progress=verbose > 0
            )
            sorted_result = result[node_names].values

        return sorted_result

    def _warmup_run(self, epochs, verbose=None):
        d = self._d
        tf.keras.backend.clear_session()
        ohex = d.get_kdbe_x(self.k)
        self.constraints = softmax_weight(d.constraint_positions)
        elr = get_lr(ohex.shape[1], d.num_classes, self.constraints)
        history = elr.fit(
            ohex, d.y, batch_size=self.batch_size, epochs=epochs, verbose=verbose
        )
        self.__gen_weights = elr.get_weights()
        tf.keras.backend.clear_session()
        return history

    def _run_generator(self, loss):
        d = self._d
        ohex = d.get_kdbe_x(self.k)
        tf.keras.backend.clear_session()
        model = tf.keras.Sequential()
        model.add(
            tf.keras.layers.Dense(
                d.num_classes,
                input_dim=ohex.shape[1],
                activation="softmax",
                kernel_constraint=self.constraints,
            )
        )
        model.compile(
            loss=elr_loss(loss),
            optimizer="adam",
            metrics=["accuracy"],
            run_eagerly=False,
        )
        model.set_weights(self.__gen_weights)
        history = model.fit(ohex, d.y, batch_size=self.batch_size, epochs=1, verbose=0)
        self.__gen_weights = model.get_weights()
        tf.keras.backend.clear_session()
        return history

    def _discrim(self):
        model = tf.keras.Sequential()
        model.add(
            tf.keras.layers.Dense(
                1, input_dim=self._d.num_features, activation="sigmoid"
            )
        )
        model.compile(
            loss="binary_crossentropy",
            optimizer="adam",
            metrics=["accuracy"],
            run_eagerly=False,
        )
        return model

    def save_plot(
        self,
        col_names=None,
        figsize=(10, 6),
        with_labels=True,
        node_size=800,
        arrow_size=15,
        save_path=None,
    ):
        """
        Visualize the Bayesian Network structure (DAG) used in the generator.

        Parameters
        ----------
        feature_names : array-like, optional
            Names for each feature node. If None, will use numeric indices.
            Length should be equal to number of features + 1 (for label node).
            Last element is assumed to be the label node name.

        figsize : tuple, default=(10, 6)
            Figure size (width, height).
        with_labels : bool, default=True
            Whether to show node labels.
        node_size : int, default=800
            Size of nodes.
        arrow_size : int, default=15
            Size of arrows.

        Returns
        -------
        None (displays the plot).
        """
        if not hasattr(self, "_d"):
            raise ValueError("Model not fitted yet. Call `fit()` first.")

        # Get edges and prepare node names
        edges = self._d._kdbe.edges_

        # Handle feature names
        if col_names is None:
            node_names = [
                str(i) for i in range(self._d.num_features + 1)
            ]  # Default to indices
        else:
            if len(col_names) != self._d.num_features + 1:
                raise ValueError(
                    f"feature_names should have length {self._d.num_features + 1} "
                    f"(num_features + 1 for label), got {len(col_names)}"
                )
            node_names = col_names

        # Create a pgmpy BayesianNetwork model
        model = DiscreteBayesianNetwork([(str(u), str(v)) for u, v in edges])

        # Convert to networkx graph for visualization
        nx_graph = nx.DiGraph()
        nx_graph.add_edges_from(model.edges())

        # Create label mapping (numeric index to feature name)
        label_mapping = {str(i): name for i, name in enumerate(node_names)}

        # Plot the graph
        plt.figure(figsize=figsize)
        pos = nx.spring_layout(nx_graph, seed=42)  # Layout for consistent visualization
        nx.draw(
            nx_graph,
            pos=pos,
            with_labels=with_labels,
            labels=label_mapping,  # Use the name mapping
            node_size=node_size,
            node_color="skyblue",
            edge_color="gray",
            arrowsize=arrow_size,
            font_weight="bold",
        )
        plt.title("Bayesian Network Structure (DAG)")

        if save_path is not None:
            plt.savefig(save_path)
            print(f"Bayesian Network saved to {save_path}")

    # 添加保存和加载模型的方法
    def save(self, filepath: str) -> None:
        """
        Save the trained GANBLR model to a file.

        Parameters
        ----------
        filepath : str
            Path to save the model (e.g., "model/ganblr_model.joblib").
        """
        # Ensure directory exists
        Path(filepath).parent.mkdir(parents=True, exist_ok=True)

        # Collect all necessary attributes
        model_state = {
            # Model parameters
            "_gen_weights": self.__gen_weights,
            "k": self.k,
            "batch_size": self.batch_size,
            "epochs": self.epochs,
            "constraints": self.constraints,
            # Data utils
            "_ordinal_encoder": self._ordinal_encoder,
            "_label_encoder": self._label_encoder,
            # Bayesian network structure
            "_d_attrs": {
                "num_features": self._d.num_features,
                "num_classes": self._d.num_classes,
                "feature_uniques": self._d.feature_uniques,
                "class_counts": self._d.class_counts,
                "data_size": self._d.data_size,
                "_kdbe_edges": self._d._kdbe.edges_,
                "_kdbe_constraints": self._d._kdbe.constraints_,
                "_kdbe_dependencies": self._d._kdbe.dependencies_,
                "_kdbe_have_value_idxs": self._d._kdbe.have_value_idxs_,
                "_kdbe_high_order_feature_uniques": self._d._kdbe.high_order_feature_uniques_,
            },
        }

        # Save to file
        joblib.dump(model_state, filepath)
        print(f"Model saved to {filepath}")

    @classmethod
    def load(cls, filepath: str) -> "GANBLR":
        """
        Load a trained GANBLR model from a file.

        Parameters
        ----------
        filepath : str
            Path to the saved model file.

        Returns
        -------
        GANBLR
            The loaded GANBLR model instance.
        """
        if not os.path.exists(filepath):
            raise FileNotFoundError(f"Model file not found at {filepath}")

        # Load the saved state
        model_state = joblib.load(filepath)

        # Create a new instance of the model
        model = cls()

        # Restore basic attributes
        model.__gen_weights = model_state["_gen_weights"]
        model.k = model_state["k"]
        model.batch_size = model_state["batch_size"]
        model.epochs = model_state["epochs"]
        model.constraints = model_state["constraints"]

        # Restore encoders
        model._ordinal_encoder = model_state["_ordinal_encoder"]
        model._label_encoder = model_state["_label_encoder"]

        # Restore DataUtils (_d) object
        d_attrs = model_state["_d_attrs"]

        # Create dummy x and y arrays with correct dimensions to initialize DataUtils
        # We use zeros just for initialization - actual values aren't needed
        dummy_x = np.zeros((d_attrs["data_size"], d_attrs["num_features"]))
        dummy_y = np.zeros(d_attrs["data_size"])

        # Initialize DataUtils with dummy arrays
        model._d = DataUtils(dummy_x, dummy_y)

        # Override the dummy values with the actual saved attributes
        model._d.num_features = d_attrs["num_features"]
        model._d.num_classes = d_attrs["num_classes"]
        model._d.feature_uniques = d_attrs["feature_uniques"]
        model._d.class_counts = d_attrs["class_counts"]
        model._d.data_size = d_attrs["data_size"]
        model._d.constraint_positions = d_attrs.get("constraint_positions", None)

        # Reconstruct the KDBE (k-Dependence Bayesian Estimator) part
        model._d._kdbe = KdbHighOrderFeatureEncoder()  # Create proper KDBE instance

        # Set KDBE attributes
        model._d._kdbe.edges_ = d_attrs["_kdbe_edges"]
        model._d._kdbe.constraints_ = d_attrs["_kdbe_constraints"]
        model._d._kdbe.dependencies_ = d_attrs["_kdbe_dependencies"]
        model._d._kdbe.have_value_idxs_ = d_attrs["_kdbe_have_value_idxs"]
        model._d._kdbe.high_order_feature_uniques_ = d_attrs[
            "_kdbe_high_order_feature_uniques"
        ]

        # Initialize the ohe_ attribute if needed (assuming it's a OneHotEncoder)
        if "_kdbe_ohe_" in d_attrs:
            model._d._kdbe.ohe_ = OneHotEncoder()
            # Here you would need to properly restore the OneHotEncoder state
            # This might require additional attributes to be saved/loaded

        return model
