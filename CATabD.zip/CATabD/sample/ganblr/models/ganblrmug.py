from ..kdb import *
from ..utils import *
from pgmpy.models import BayesianNetwork
from pgmpy.sampling import BayesianModelSampling
from pgmpy.factors.discrete import TabularCPD
from sklearn.preprocessing import OrdinalEncoder, LabelEncoder
import numpy as np
import tensorflow as tf
from scipy.spatial import distance
from scipy.special import softmax
from .ganblr import GANBLR
import numpy as np
import tensorflow as tf
import joblib
import os
from pathlib import Path
import matplotlib.pyplot as plt
import networkx as nx


def get_weight(group_loss):
    weight = softmax(1- softmax(group_loss))
    #weight = (1 - softmax(group_loss))/len(group_loss)
    #weight = softmax(1000 - group_loss)
    return weight

class GANBLR_MUG_UNIT(GANBLR):
    def init_unit(self, x, y, k, batch_size=32):
        x = self._ordinal_encoder.fit_transform(x)
        y = self._label_encoder.fit_transform(y).astype(int)
        d = DataUtils(x, y)
        self._d = d
        self.k = k
        self.batch_size = batch_size

    def run_one_epoch(self, x, y, syn_x):
        x = self._ordinal_encoder.transform(x)
        y = self._label_encoder.transform(y).astype(int)
        d = DataUtils(x, y)
        self._d = d
        batch_size = self.batch_size

        discriminator_label = np.hstack([np.ones(d.data_size), np.zeros(len(syn_x))])
        discriminator_input = np.vstack([x, syn_x])
        disc_input, disc_label = sample(discriminator_input, discriminator_label, frac=0.8)
        disc = self._discrim()
        d_history = disc.fit(disc_input, disc_label, batch_size=batch_size, epochs=1, verbose=0).history
        prob_fake = disc.predict(x, verbose=0)
        sim_loss = distance.euclidean(x.ravel(), syn_x.ravel())*0.1
        ls = np.mean(-np.log(np.subtract(1, prob_fake))) + sim_loss
        g_history = self._run_generator(loss=ls).history
        #syn_data = self._sample(verbose=0)
        return self, sim_loss, d_history, g_history


class GANBLR_MUG:
    """
    Multi-Unit GANBLR with enhanced features:
    - Model checkpoint saving
    - Convergence detection
    - DAG visualization
    - TensorBoard logging
    - Save/load functionality
    """
    def __init__(self, random_state=None):
        self._units = None
        self._candidate_labels = None
        self._ordinal_encoder = OrdinalEncoder(
            dtype=int, 
            handle_unknown='use_encoded_value', 
            unknown_value=-1
        )
        self._weight = None
        self.batch_size = None
        self.epochs = None
        self.k = None
        self.tensorboard_writer = None
        self.training_history_ = None
        self._random_state = random_state

    def _init_units(self, data_frame, candidate_labels=None):
        '''
        Parameters
        ----------
        data_frame : array_like of shape (n_samples, n_features)
            Dataset to fit the model. The data should be discrete.

        candidate_labels : array_like of shape (n_labels,), default=None
            Index of candidate labels of the dataset. If `None`, all the features will be used as candidate labels.
        '''
        if candidate_labels is None:
            num_units = data_frame.shape[1]
            candidate_labels = np.arange(num_units).astype(int)
        else:
            candidate_label_idxs = []
            for label in candidate_labels:
                if isinstance(label, str):
                    label_idx = data_frame.columns.get_loc(label)
                    candidate_label_idxs.append(label_idx)
                elif isinstance(label, int):
                    candidate_label_idxs.append(label)
                else:
                    raise Exception(f"Invalid Value in Arugument `candidate_labels`, `{label}` is not a valid column name or index.")

            num_units = len(candidate_label_idxs)
            candidate_labels = np.array(candidate_label_idxs).astype(int)

        units = {idx:GANBLR_MUG_UNIT() for idx in candidate_labels}

        self._ordinal_encoder = OrdinalEncoder().fit(data_frame)
        self._candidate_labels = candidate_labels
        self._units = units
        print(self._units[0])

        return units


    def fit(self, data_frame, candidate_labels=None, k=0, batch_size=32, epochs=10, 
            warmup_epochs=2, verbose=1, save_dir="models", save_freq=5,
            tensorboard_dir="logs", convergence_window=10, tolerance=0.01, min_epochs=20):
        """
        Enhanced fit() with convergence check and model saving.
        """
        # Initialize directories and logging
        if save_dir is not None:
            Path(save_dir).mkdir(parents=True, exist_ok=True)
        if tensorboard_dir is not None:
            Path(tensorboard_dir).mkdir(parents=True, exist_ok=True)
            self.tensorboard_writer = tf.summary.create_file_writer(tensorboard_dir)

        self.k = k
        self.batch_size = batch_size
        self.epochs = epochs
        
        # Initialize units
        units = self._init_units(data_frame, candidate_labels)
        
        # Warmup phase
        if verbose:
            print("Warmup phase:")
        weight = self._warmup_run(data_frame, k, batch_size, warmup_epochs, verbose=verbose)
        syn_data = self._weighted_sample(weight, verbose=0)

        # Training history
        history = {
            'g_loss': [], 'd_loss': [], 'sim_loss': [],
            'weights': [], 'converged': False
        }

        # Main training loop
        for epoch in range(epochs):
            epoch_g_loss, epoch_d_loss, epoch_sim_loss = [], [], []
            
            for label_idx, unit in units.items():
                X, y = self._split_dataset(data_frame.values, label_idx)
                syn_X, _ = self._split_dataset(syn_data, label_idx)
                
                # Train unit for one epoch
                unit, sim_loss, d_history, g_history = unit.run_one_epoch(X, y, syn_X)
                
                # Record metrics
                epoch_g_loss.append(g_history['loss'][0])
                epoch_d_loss.append(d_history['loss'][0])
                epoch_sim_loss.append(sim_loss)

            # Update weights based on losses
            weight = get_weight(epoch_sim_loss)
            self._weight = weight
            
            # Record epoch metrics
            history['g_loss'].append(np.mean(epoch_g_loss))
            history['d_loss'].append(np.mean(epoch_d_loss))
            history['sim_loss'].append(np.mean(epoch_sim_loss))
            history['weights'].append(weight.copy())

            # Log to TensorBoard
            if self.tensorboard_writer is not None:
                with self.tensorboard_writer.as_default():
                    tf.summary.scalar('Generator/loss', history['g_loss'][-1], step=epoch)
                    tf.summary.scalar('Discriminator/loss', history['d_loss'][-1], step=epoch)
                    tf.summary.scalar('Similarity/loss', history['sim_loss'][-1], step=epoch)
                    for i, w in enumerate(weight):
                        tf.summary.scalar(f'Weights/unit_{i}', w, step=epoch)
                    self.tensorboard_writer.flush()

            # Print progress
            if verbose:
                print(f"Epoch {epoch+1}/{epochs}: "
                      f"G_loss = {history['g_loss'][-1]:.4f}, "
                      f"D_loss = {history['d_loss'][-1]:.4f}, "
                      f"Sim_loss = {history['sim_loss'][-1]:.4f}, "
                      f"Weights = {np.round(weight, 2)}")

            # Save checkpoint
            if save_dir is not None and (epoch+1) % save_freq == 0:
                self.save(Path(save_dir) / f"ganblr_mug_epoch_{epoch+1}.joblib")
                if verbose:
                    print(f"Checkpoint saved at epoch {epoch+1}")

            # Check convergence
            if (epoch >= min_epochs and 
                len(history['g_loss']) >= convergence_window):
                recent_g = history['g_loss'][-convergence_window:]
                recent_d = history['d_loss'][-convergence_window:]
                
                g_fluct = (max(recent_g) - min(recent_g)) / np.mean(recent_g)
                d_fluct = (max(recent_d) - min(recent_d)) / np.mean(recent_d)
                
                if g_fluct < tolerance and d_fluct < tolerance:
                    history['converged'] = True
                    if verbose:
                        print(f"\nTraining converged at epoch {epoch+1}")
                    break

            # Generate new synthetic data for next epoch
            syn_data = self._weighted_sample(weight, verbose=0)

        # Save final model
        if save_dir is not None:
            final_path = Path(save_dir) / "ganblr_mug_final.joblib"
            self.save(final_path)
            if verbose:
                print(f"Final model saved to {final_path}")

        self.training_history_ = history
        return self
    
    def evaluate(self, test_data, label_idx=None, model='lr') -> float:
        """
        Perform a TSTR(Training on Synthetic data, Testing on Real data) evaluation.

        Parameters
        ----------
        test_data : array_like
            Test dataset.

        model : str or object
            The model used for evaluate. Should be one of ['lr', 'mlp', 'rf'], or a model class that have sklearn-style `fit` and `predict` method.

        Return:
        --------
        accuracy_score : float.

        """
        from sklearn.linear_model import LogisticRegression
        from sklearn.neural_network import MLPClassifier
        from sklearn.ensemble import RandomForestClassifier
        from sklearn.preprocessing import OneHotEncoder
        from sklearn.pipeline import Pipeline
        from sklearn.metrics import accuracy_score

        eval_model = None
        models = dict(
            lr=LogisticRegression,
            rf=RandomForestClassifier,
            mlp=MLPClassifier
        )
        if model in models.keys():
            eval_model = models[model]()
        elif hasattr(model, 'fit') and hasattr(model, 'predict'):
            eval_model = model
        else:
            raise Exception("Invalid Arugument `model`, Should be one of ['lr', 'mlp', 'rf'], or a model class that have sklearn-style `fit` and `predict` method.")

        oe = self._units[label_idx]._ordinal_encoder
        le = self._units[label_idx]._label_encoder
        d  = self._units[label_idx]._d

        synthetic_data = self._weighted_sample(self._weight, verbose=0)
        synthetic_x, synthetic_y = self._split_dataset(synthetic_data, label_idx)
        x, y = self._split_dataset(test_data.values, label_idx)
        x_test = oe.transform(x)
        y_test = le.transform(y)

        categories = d.get_categories()
        pipline = Pipeline([('encoder', OneHotEncoder(categories=categories, handle_unknown='ignore')), ('model',  eval_model)])
        pipline.fit(synthetic_x, synthetic_y)
        pred = pipline.predict(x_test)
        return accuracy_score(y_test, pred)

    def sample(self, size=None, verbose=1) -> np.ndarray:
        """
        Generate synthetic data.

        Parameters
        ----------
        size : int or None
            Size of the data to be generated. set to `None` to make the size equal to the size of the training set.

        verbose : int, default=1
            Whether to output the log. Use 1 for log output and 0 for complete silence.

        Return:
        -----------------
        synthetic_samples : np.ndarray
            Generated synthetic data.
        """
        ordinal_data = self._weighted_sample(self._weight, size, verbose)
        ordinal_data = self._ordinal_encoder.inverse_transform(ordinal_data)
        return ordinal_data

    def _weighted_sample(self, weight, size=None, verbose=1) -> np.ndarray:
        samples = []
        sample_size = self._units[0]._d.data_size if size is None else size

        sizes = np.round(weight * sample_size).astype(int)
        if sizes.sum() != sample_size:
            sizes[np.argmax(sizes)] += sample_size - sizes.sum()

        for _size, (idx, unit) in zip(sizes, self._units.items()):
            result = unit._sample(_size, verbose)

            sorted_result = self._reindex_dataset(result, idx)
            samples.append(sorted_result)
            #print(f"sizes: {sorted_result.shape}")
        return np.vstack(samples)

    def _split_dataset(self, data, label_idx):
        '''
        assume idx = 2
        this method convert [x0 x1 x2 x3 y] to [x0 x1 x3 y], x2
        '''
        feature_idxs = np.delete(np.arange(data.shape[1]), label_idx).astype(int)
        X = data[:,feature_idxs]
        y = data[:,label_idx]
        return X, y

    def _reindex_dataset(self, data, label_idx):
        '''
        assume idx = 2
        this method convert [x0 x1 x3 y x2] to [x0 x1 x2 x3 y]
        '''
        feature_idxs = list(range(data.shape[1]-1))
        feature_idxs.insert(label_idx, data.shape[1] - 1)

        return data[:,feature_idxs]

    def _warmup_run(self, data_frame, k, batch_size, epochs, verbose=None):
        if verbose:
            print(f"warmup run:")

        group_loss = []
        for label_idx, unit in self._units.items():
            X, y = self._split_dataset(data_frame.values, label_idx)

            unit.init_unit(X, y, k, batch_size)
            unit._warmup_run(epochs, verbose=verbose)
            syn_data = unit._sample(verbose=0)
            syn_X, syn_y = self._split_dataset(syn_data, label_idx)
            unit, sim_loss, d_history, g_history = unit.run_one_epoch(X, y, syn_X)
            group_loss.append(sim_loss)

        #print(group_loss)
        weight = get_weight(group_loss)
        if verbose:
            print(f'weight after warmup: {np.round(weight, 2).tolist()}')
        return weight

    def _run_generator(self, loss):
        d = self._d
        ohex = d.get_kdbe_x(self.k)
        tf.keras.backend.clear_session()
        model = tf.keras.Sequential()
        model.add(tf.keras.layers.Dense(d.num_classes, input_dim=ohex.shape[1], activation='softmax',kernel_constraint=self.constraints))
        model.compile(loss=elr_loss(loss), optimizer='adam', metrics=['accuracy'])
        model.set_weights(self.__gen_weights)
        history = model.fit(ohex, d.y, batch_size=self.batch_size,epochs=1, verbose=0)
        self.__gen_weights = model.get_weights()
        tf.keras.backend.clear_session()
        return history

    def _discrim(self):
        model = tf.keras.Sequential()
        model.add(tf.keras.layers.Dense(1, input_dim=self._d.num_features, activation='sigmoid'))
        model.compile(loss='binary_crossentropy', optimizer='adam', metrics=['accuracy'])
        return model

    def save_plot(self, col_names=None, figsize=(12, 8), save_path=None, **kwargs):
        """
        Visualize the DAG structure of the first unit.
        """
        if not self._units:
            raise ValueError("Model not fitted yet.")
        
        # Use first unit's DAG as representative
        unit = next(iter(self._units.values()))
        edges = unit._d._kdbe.edges_
        
        # Create graph
        plt.figure(figsize=figsize)
        G = nx.DiGraph()
        
        # Handle node names
        if col_names is None:
            node_names = [str(i) for i in range(unit._d.num_features + 1)]
        else:
            if len(col_names) != unit._d.num_features + 1:
                raise ValueError("col_names length mismatch")
            node_names = col_names
        
        # Add edges and labels
        G.add_edges_from([(node_names[u], node_names[v]) for u, v in edges])
        pos = nx.spring_layout(G, seed=self._random_state)
        
        # Draw with enhanced styling
        nx.draw_networkx(
            G, pos,
            with_labels=True,
            node_size=800,
            node_color="skyblue",
            edge_color="gray",
            arrowsize=20,
            font_size=10,
            **kwargs
        )
        plt.title("Bayesian Network Structure (First Unit)")
        
        if save_path:
            plt.savefig(save_path, bbox_inches='tight')
            plt.close()
            print(f"DAG visualization saved to {save_path}")
        else:
            plt.show()

    def save(self, filepath):
        """
        Save the complete MUG model state.
        """
        model_state = {
            'units_state': {
                idx: {
                    '_gen_weights': unit._GANBLR_MUG_UNIT__gen_weights,
                    '_ordinal_encoder': unit._ordinal_encoder,
                    '_label_encoder': unit._label_encoder,
                    '_d_attrs': self._get_unit_attrs(unit)
                }
                for idx, unit in self._units.items()
            },
            'candidate_labels': self._candidate_labels,
            'ordinal_encoder': self._ordinal_encoder,
            'weight': self._weight,
            'training_params': {
                'k': self.k,
                'batch_size': self.batch_size,
                'random_state': self._random_state
            },
            'training_history': self.training_history_
        }
        
        Path(filepath).parent.mkdir(parents=True, exist_ok=True)
        joblib.dump(model_state, filepath)
        print(f"Model saved to {filepath}")

    @classmethod
    def load(cls, filepath):
        """
        Load a saved MUG model.
        """
        if not os.path.exists(filepath):
            raise FileNotFoundError(f"Model file not found: {filepath}")
            
        model_state = joblib.load(filepath)
        model = cls(random_state=model_state['training_params']['random_state'])
        
        # Restore basic attributes
        model._candidate_labels = model_state['candidate_labels']
        model._ordinal_encoder = model_state['ordinal_encoder']
        model._weight = model_state['weight']
        model.k = model_state['training_params']['k']
        model.batch_size = model_state['training_params']['batch_size']
        model.training_history_ = model_state.get('training_history', {})
        
        # Rebuild units
        model._units = {}
        for idx, unit_state in model_state['units_state'].items():
            unit = GANBLR_MUG_UNIT()
            unit._GANBLR_MUG_UNIT__gen_weights = unit_state['_gen_weights']
            unit._ordinal_encoder = unit_state['_ordinal_encoder']
            unit._label_encoder = unit_state['_label_encoder']
            
            # Rebuild DataUtils
            dummy_x = np.zeros((unit_state['_d_attrs']['data_size'], 
                               unit_state['_d_attrs']['num_features']))
            dummy_y = np.zeros(unit_state['_d_attrs']['data_size'])
            unit._d = DataUtils(dummy_x, dummy_y)
            
            # Restore DataUtils attributes
            for attr, val in unit_state['_d_attrs'].items():
                setattr(unit._d, attr, val)
            
            model._units[idx] = unit
            
        return model

    # ... (保持原有的_split_dataset, _reindex_dataset等方法不变)