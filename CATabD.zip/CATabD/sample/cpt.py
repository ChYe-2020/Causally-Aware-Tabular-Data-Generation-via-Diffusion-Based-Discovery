import tensorflow as tf
from spektral.layers import GlobalAvgPool, GraphAttention
import numpy as np
from tqdm import tqdm
from helpers.config_graph import get_config
import os
import pickle

cp = tf.compat.v1.ConfigProto()
cp.gpu_options.allow_growth = True  # 动态分配GPU内存


class CPT(object):
    def __init__(self, config, num_values, adj, observations):
        self.config = config
        self.num_neurons = config.hidden_dim
        self.model_batch = config.model_batch
        self.data_batch = config.data_batch
        self.initializer = tf.contrib.layers.xavier_initializer()

        self.sess = tf.compat.v1.Session(config=cp)  # 全局会话
        tf.compat.v1.keras.backend.set_session(self.sess)  # 绑定到Keras后端
        self.sess.run(tf.compat.v1.global_variables_initializer())  # 初始化变量

        # 网络结构信息
        self.max_length = adj.shape[0]

        # GAT层
        self.gat_layer = GraphAttention(
            self.num_neurons, activation="relu", kernel_initializer=self.initializer
        )
        # 预计算
        self.num_values = tf.convert_to_tensor(num_values, dtype=tf.int32)
        self.base_adj = tf.convert_to_tensor(adj, dtype=tf.float32)

        # 新增：存储观测数据用于预计算
        self.observations = observations

        self.node_k, self.node_p, self.parent_combinations = self._precompute_k_values()
        # 在Python端计算unique_k值
        with tf.compat.v1.Session() as sess:
            self.unique_ks = sess.run(tf.unique(tf.squeeze(self.node_k))[0])

        # 投影矩阵
        self.proj_matrices = self._init_projection_matrices()

        # 优化器
        self.optimizer = tf.compat.v1.train.AdamOptimizer(config.learning_rate)

    def _precompute_k_values(self):
        """基于真实数据剪枝的k值计算"""
        with tf.compat.v1.Session() as sess:
            num_values_np = sess.run(self.num_values)
            base_adj_np = sess.run(self.base_adj)
            observations_np = self.observations

        k_list, p_list = [], []
        parent_combinations_list = []

        for i in range(self.max_length):
            parents = np.where(base_adj_np[:, i] > 0)[0]
            c = num_values_np[i]

            if len(parents) > 0:
                # 获取所有观测中父节点的组合
                parent_obs = observations_np[:, parents]
                # 找到所有唯一的父节点组合
                unique_combinations = np.unique(parent_obs, axis=0)
                p = len(unique_combinations)

                # 创建查找字典
                combination_map = {}
                for idx, comb in enumerate(unique_combinations):
                    combination_map[tuple(comb)] = idx
                parent_combinations_list.append((unique_combinations, combination_map))
            else:
                p = 1
                parent_combinations_list.append((None, None))

            k = p * c
            k_list.append(int(k))
            p_list.append(int(p))

            # 打印每个节点的父节点组合信息
            print(f"Node {i}: k={k}, p={p}, c={c}, parents={parents.tolist()}")

        return k_list, p_list, parent_combinations_list

    @tf.function
    def _init_projection_matrices(self):
        """初始化投影矩阵"""
        matrices = {}
        for k in self.unique_ks:
            print(f"Initializing projection matrix for k={k}")
            k_int = int(k)
            with tf.variable_scope(f"proj_matrix_{k_int}", reuse=tf.AUTO_REUSE):
                matrices[k_int] = tf.get_variable(
                    f"w_{k_int}",
                    [self.num_neurons, k_int],
                    initializer=self.initializer,
                )
        return matrices

    def predict(self, node_features):
        """
        生成多个贝叶斯网络的CPT
        node_features: [model_batch, max_length, hidden_dim]
        返回: [max_length, model_batch, c, p]
        """
        if not isinstance(node_features, tf.Tensor):
            node_features = tf.convert_to_tensor(node_features, dtype=tf.float32)

        model_batch = self.model_batch
        adj = tf.tile(tf.expand_dims(self.base_adj, 0), [model_batch, 1, 1])

        # GAT处理
        node_embeddings = self.gat_layer(
            [node_features, adj + tf.eye(self.max_length)]
        )  # [model_batch, max_length, hidden_dim]

        # 生成CPT
        cpt_list = []
        for i in range(self.max_length):
            p, c, k = self.node_p[i], self.num_values[i], self.node_k[i]
            proj_w = self.proj_matrices[int(k)]

            # [model_batch, k]
            logits = tf.matmul(node_embeddings[:, i, :], proj_w)

            # [model_batch, p, c]
            prob = tf.nn.softmax(tf.reshape(logits, [-1, p, c]), axis=-1)

            # [model_batch, c, p]
            cpt_list.append(tf.transpose(prob, [0, 2, 1]))

        return cpt_list  # [max_length, model_batch, c, p]

    @tf.function
    def compute_loss(self, observations):
        """
        修改后的loss计算，考虑真实数据中的父节点组合
        """
        model_batch = self.model_batch
        data_batch = self.data_batch

        total_loss = 0.0
        for model_idx in range(model_batch):
            # 获取当前网络的CPT [max_length, c, p]
            network_cpt = []
            for node in range(self.max_length):
                node_cpt = self.cpt_list[node][model_idx, :, :]
                network_cpt.append(node_cpt)

            # 计算当前网络在所有样本上的似然
            log_prob = 0.0
            for sample_idx in range(data_batch):
                sample_log_prob = 0.0
                for node in range(self.max_length):
                    parents = tf.where(self.base_adj[:, node] > 0)[:, 0]
                    current_obs = observations[sample_idx, node]

                    if tf.size(parents) > 0:
                        # 获取当前样本的父节点观测值
                        parent_obs = tf.gather(observations[sample_idx], parents)

                        # 将父节点观测转换为字符串作为字典键
                        parent_obs_str = tf.as_string(parent_obs)
                        parent_key = tf.strings.reduce_join(
                            parent_obs_str, separator=","
                        )

                        # 在Python端预先计算好的组合中查找
                        unique_combs, comb_map = self.parent_combinations[node]
                        if unique_combs is not None:
                            # 将组合转换为字符串键
                            comb_keys = [
                                ",".join(map(str, comb)) for comb in unique_combs
                            ]
                            # 创建查找表
                            lookup_table = tf.lookup.StaticHashTable(
                                tf.lookup.KeyValueTensorInitializer(
                                    keys=comb_keys,
                                    values=list(range(len(comb_keys))),
                                    key_dtype=tf.string,
                                    value_dtype=tf.int32,
                                ),
                                default_value=-1,
                            )
                            parent_idx = lookup_table.lookup(parent_key)
                        else:
                            parent_idx = 0
                    else:
                        parent_idx = 0

                    prob = network_cpt[node][current_obs, parent_idx]
                    sample_log_prob += tf.math.log(prob + 1e-10)

                log_prob += sample_log_prob

            # 平均对数似然
            total_loss += -log_prob / tf.cast(data_batch, tf.float32)

        return total_loss / tf.cast(model_batch, tf.float32)

    def train(self, node_features, num_epochs):
        """
        训练函数
        node_features: [model_batch, max_length, hidden_dim] 生成网络的初始特征
        """
        data_batch = self.data_batch
        total_samples = len(self.observations)

        # 前向传播
        self.cpt_list = self.predict(node_features)

        # 创建placeholder
        obs_ph = tf.compat.v1.placeholder(tf.int32, [None, self.max_length])

        # 计算loss
        self.loss = self.compute_loss(obs_ph)
        self.train_op = self.optimizer.minimize(self.loss)

        with self.sess.as_default():
            print("GAT layer weight:", self.gat_layer.get_weights()[0][0][0])
            # self.sess.run(tf.global_variables_initializer())

            for epoch in tqdm(range(num_epochs), desc="Training"):
                print("GAT layer weight:", self.gat_layer.get_weights()[0][0][0])
                # 打乱数据
                idx = np.random.permutation(total_samples)
                shuffled_obs = self.observations[idx]

                epoch_loss = 0
                num_batches = int(total_samples // data_batch)

                for batch_idx in range(num_batches):
                    start = batch_idx * data_batch
                    end = start + data_batch
                    batch_obs = shuffled_obs[start:end]

                    # 训练步骤
                    _, loss_val = self.sess.run(
                        [self.train_op, self.loss], feed_dict={obs_ph: batch_obs}
                    )
                    epoch_loss += loss_val

                # 打印epoch信息
                avg_loss = epoch_loss / num_batches
                tqdm.write(f"Epoch {epoch+1}, Loss: {avg_loss:.4f}")
                print("GAT layer weight:", self.gat_layer.get_weights()[0][0][0])

    def infer(self, node_features):
        """
        生成多个贝叶斯网络的CPT
        node_features: [max_length, hidden_dim]
        返回: [max_length, c, p]
        """
        if not isinstance(node_features, tf.Tensor):
            node_features = tf.convert_to_tensor(node_features, dtype=tf.float32)

        adj = self.base_adj  # [max_length, max_length]

        # GAT处理
        node_embeddings = self.gat_layer(
            [node_features, adj + tf.eye(self.max_length)]
        )  # [max_length, hidden_dim]

        # 生成CPT
        cpt_list = []
        for i in range(self.max_length):
            p, c, k = self.node_p[i], self.num_values[i], self.node_k[i]
            proj_w = self.proj_matrices[int(k)]

            # [ k]
            logits = tf.matmul(tf.reshape(node_embeddings[i, :], [1, -1]), proj_w)

            # [ p, c]
            prob = tf.nn.softmax(tf.reshape(logits, [p, c]), axis=-1)

            # [ c, p]
            cpt_list.append(tf.transpose(prob, [1, 0]))

        return cpt_list  # [max_length, c, p]

    def save(self, path):

        if not os.path.exists(path):
            os.makedirs(path)

        with self.sess.as_default():
            # 投影矩阵
            # self.sess.run(tf.compat.v1.global_variables_initializer())
            saver = tf.compat.v1.train.Saver()
            saver.save(self.sess, os.path.join(path, "model.ckpt"))
            # gat
            weights = self.gat_layer.get_weights()
            weights_path = os.path.join(path, "model_weights")
            os.makedirs(weights_path, exist_ok=True)

            for i, w in enumerate(weights):
                np.save(os.path.join(weights_path, f"weight_{i}.npy"), w)

            # 在同一个session中打印变量值


    def load(self, path):
        """
        Load the model from the specified directory
        """
        with self.sess.as_default():
            weights_path = os.path.join(path, "model_weights")
            weight_files = sorted(
                [f for f in os.listdir(weights_path) if f.startswith("weight_")]
            )
            loaded_weights = [
                np.load(os.path.join(weights_path, f)) for f in weight_files
            ]

            input_shape = [
                (self.max_length, self.num_neurons),
                (self.max_length, self.max_length),
            ]
            dummy_input = [
                tf.zeros([1, *input_shape[0]], dtype=tf.float32),
                tf.zeros([1, *input_shape[1]], dtype=tf.float32),
            ]
            _ = self.gat_layer(dummy_input)

            self.gat_layer.set_weights(loaded_weights)

            saver = tf.compat.v1.train.Saver()

            # Check if checkpoint exists
            ckpt = tf.train.get_checkpoint_state(path)
            if ckpt and ckpt.model_checkpoint_path:
                saver.restore(self.sess, ckpt.model_checkpoint_path)
                print(f"Model restored from {ckpt.model_checkpoint_path}")

            else:
                print(f"No checkpoint found in {path}")
                self.sess.run(tf.compat.v1.global_variables_initializer())


# 使用示例
if __name__ == "__main__":
    import os

    os.environ["XLA_FLAGS"] = "--xla_gpu_cuda_data_dir=/home/zh/.conda/envs/zh"

    config, _ = get_config()
    config.model_batch = 1  # 每次生成的网络数量
    config.data_batch = 128  # 每份数据的样本数
    config.hidden_dim = 8  # 特征向量维度
    config.learning_rate = 1e-3  # 学习率

    import numpy as np

    # 1. 定义网络结构
    adj_matrix = np.array([[0, 1, 0], [1, 0, 1], [0, 1, 0]], dtype=np.float32)
    num_values = [2, 3, 2]  # 各节点取值数量

    # 2. 生成匹配的观测数据
    observations = np.column_stack(
        [
            np.random.randint(0, 2, 1000),  # 节点0: 0-1
            np.random.randint(0, 3, 1000),  # 节点1: 0-2
            np.random.randint(0, 2, 1000),  # 节点2: 0-1
        ]
    )

    # 3. 调整隐藏层维度
    node_features = np.random.randn(
        config.model_batch, 3, config.hidden_dim
    )  # 更小的隐藏维度

    # 4. 创建并训练模型
    model = CPT(
        config, num_values=num_values, adj=adj_matrix, observations=observations
    )
    model.load("models")
    model.train(node_features, num_epochs=10)
    import os

    if not os.path.exists("models"):
        os.makedirs("models")
    # 保存和加载模型
    model.save("models")
