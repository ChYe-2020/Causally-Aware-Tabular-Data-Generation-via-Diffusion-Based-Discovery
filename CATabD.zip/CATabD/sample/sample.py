import numpy as np
import pandas as pd
import os
import tensorflow as tf
from helpers.config_graph import get_config
from pathlib import Path

os.environ["XLA_FLAGS"] = "--xla_gpu_cuda_data_dir=/home/zh/.conda/envs/zh"
# tf.config.set_visible_devices(tf.config.list_physical_devices("GPU")[1], "GPU")
# 连续列的索引
num_cols = {
    "adult": [],
    "abalone": [1, 2, 3, 4, 5, 6, 7],
    "pm25": [4, 5, 6, 7, 9],
    "shuttle": [],
    "statlog": [],
    "cancer": [],
    "asia": [],
    "syn": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9],
}


def convert_graph_int_to_adj_mat(graph_int):
    # Convert graph int to binary adjacency matrix
    # TODO: Make this more readable
    return np.array(
        [
            list(
                map(
                    int,
                    (
                        (len(graph_int) - len(np.base_repr(curr_int))) * "0"
                        + np.base_repr(curr_int)
                    ),
                )
            )
            for curr_int in graph_int
        ],
        dtype=int,
    )


def get_adj(dataset: str, type: str):

    # if dataset == "cancer":
    #     return np.array(
    #         [
    #             [0, 0, 0, 0, 0],
    #             [0, 0, 0, 0, 0],
    #             [1, 1, 0, 0, 0],
    #             [0, 0, 1, 0, 0],
    #             [0, 0, 1, 0, 0],
    #         ],
    #         dtype=int,
    #     )
    # if dataset == "asia":
    #     return np.array(
    #         [
    #             [0, 0, 1, 0, 0, 0, 0, 0],
    #             [0, 0, 0, 0, 0, 1, 0, 1],
    #             [0, 0, 0, 1, 1, 0, 0, 0],
    #             [0, 0, 0, 0, 0, 0, 0, 0],
    #             [0, 0, 0, 0, 0, 0, 0, 0],
    #             [0, 0, 1, 0, 0, 0, 0, 0],
    #             [1, 0, 0, 0, 0, 0, 0, 0],
    #             [0, 0, 0, 0, 1, 0, 0, 0],
    #         ],
    #         dtype=int,
    #     )

    # # 加载保存的候选图数据
    # solvd_dict = np.load(
    #     f"output/{dataset}/cdrl/models/graph/solvd_dict.npy", allow_pickle=True
    # )

    # # 1. 先筛选出无环图（x[1][2] == 0）
    # acyclic_graphs = [x for x in solvd_dict if x[1][2] == 0]

    # if not acyclic_graphs:
    #     raise ValueError("未找到无环图！请检查数据或调整参数。")

    # # 2. 从无环图中找到得分最优的图（x[1][0] 最小）
    # best_graph_info = min(acyclic_graphs, key=lambda x: x[1][0])

    # print(f"找到的最佳无环图信息: {best_graph_info}")
    # graph_int, score_info = best_graph_info
    # print(
    #     f"最高分图的编码: {graph_int}, 得分: {score_info[0]}, 是否有环: {score_info[2]}"
    # )

    # # 转换为邻接矩阵
    # adj_matrix = convert_graph_int_to_adj_mat(graph_int)

    adj_matrix = np.load(f"output/{dataset}/dags/matrix_{type}.npy", allow_pickle=True)

    print("邻接矩阵:\n", adj_matrix)

    return adj_matrix


def corl_dag(dataset: str):
    import os

    os.environ["CASTLE_BACKEND"] = "pytorch"

    from castle.common import GraphDAG
    from castle.metrics import MetricsDAG
    from castle.datasets import DAG, IIDSimulation
    from castle.algorithms import (
        CORL,
        PC,
        ANMNonlinear,
        DirectLiNGAM,
        ICALiNGAM,
        GES,
        PNL,
        Notears,
        NotearsLowRank,
        NotearsNonlinear,
        DAG_GNN,
        GOLEM,
        GraNDAG,
        MCSL,
        GAE,
        RL,
        TTPM,
    )
    from castle.common.priori_knowledge import PrioriKnowledge

    df = pd.read_csv(f"datasets/{dataset}.csv")
    df = df.dropna()  # 去除缺失值
    from sklearn.preprocessing import OrdinalEncoder
    from sklearn.preprocessing import MinMaxScaler

    X = df.values
    o_enc = OrdinalEncoder(
        handle_unknown="use_encoded_value",
        unknown_value=-1,  # 使用-1表示未知值
        dtype=int,  # 确保输出为整数类型
        encoded_missing_value=-1,  # 确保缺失值编码为-1
    )
    scaler = MinMaxScaler(feature_range=(0.0, 1.0))  # 设置范围为(0.51, 1.0)

    # 连续列
    X_num = X[:, num_cols[dataset]]  # 获取连续列
    if X_num.shape[1] > 0:
        X_num = scaler.fit_transform(X_num)  # 将数据缩放到0.0到1.0之间
        X[:, num_cols[dataset]] = X_num  # 更新原始数据中的连续列
    # 离散列
    disc_cols = [col for col in range(X.shape[1]) if col not in num_cols[dataset]]
    print(f"离散列索引: {disc_cols}")
    X_disc = X[:, disc_cols]
    if X_disc.shape[1] > 0:
        X_disc = o_enc.fit_transform(X_disc)
        X[:, disc_cols] = X_disc
        X = X.astype(np.float64)  # 确保数据类型为float64
        X_disc = scaler.fit_transform(X_disc)  # 将数据缩放到0.0到1.0之间
        X[:, disc_cols] = X_disc

    print(X)

    # PC learn
    # priori = PrioriKnowledge(X.shape[1])
    # model = PC(variant="original", priori_knowledge=priori)
    # model.learn(X)

    # ANM（要跑很久）
    # model = ANMNonlinear(alpha=0.05)
    # model.learn(data=X)

    # DirectLiNGAM learn
    # model = DirectLiNGAM()
    # model.learn(X)

    # ICALiNGAM learn
    # model = ICALiNGAM()
    # model.learn(X)

    # GES statlog跑不出来
    # model = GES(criterion="bic", method="scatter")
    # model.learn(X)

    # PNL 只有cancer能跑出来 并且图很差
    # model = PNL(device_type="gpu")
    # model.learn(X)

    # notears learn
    # model = Notears()
    # model.learn(X)

    # notears mlp
    # model = NotearsNonlinear(model_type="sob", device_type="gpu")
    # model.learn(X)

    # notears sob
    # model = NotearsNonlinear(model_type="sob", device_type="gpu")
    # model.learn(X)

    # notears-low-rank learn
    # nt = NotearsLowRank()
    # nt.learn(X, rank=rank)

    # daggnn learn
    # model = DAG_GNN(device_type="gpu",)
    # model.learn(X)

    # GOLEM learn
    # model = GOLEM(num_iter=1e5,device_type="gpu")
    # model.learn(X)

    # gran dag
    # model = GraNDAG(input_dim=X.shape[1], device_type="gpu")
    # model.learn(data=X)

    # mcsl learn
    # model = MCSL(
    #     model_type="nn",
    #     iter_step=100,
    #     rho_thresh=1e20,
    #     init_rho=1e-5,
    #     rho_multiply=10,
    #     graph_thresh=0.5,
    #     l1_graph_penalty=2e-3,
    #     device_type="gpu",
    # )
    # model.learn(X)

    # GAE learn
    # model = GAE(input_dim=10,device_type="gpu")
    # model.learn(X)

    # cdrl learn
    model = RL(nb_epoch=10000, device_type="gpu", score_type="BIC_different_var")
    model.learn(X)

    # CORL
    # model = CORL(
    #     encoder_name="transformer",
    #     decoder_name="lstm",
    #     reward_mode="episodic",
    #     reward_regression_type="LR",
    #     batch_size=64,
    #     input_dim=64,
    #     embed_dim=64,
    #     iteration=2000,
    #     device_type="gpu",
    # )
    # model.learn(X)

    # 保存dag
    m = "cdrl"  # 模型名称
    os.makedirs(f"output/{dataset}/dags", exist_ok=True)
    np.save(f"output/{dataset}/dags/matrix_{m}.npy", model.causal_matrix)
    print("Estimated DAG:\n", model.causal_matrix)

    cpt_sample(dataset, m)


# 线性高斯
def sample_linear(dataset: str, seed: int = 0):
    dag_dir = Path(f"output/{dataset}/dags/matrix_rl_{seed}.npy")

    for i in range(1, 6):
        sample_from_matrix(dataset, dag_dir, n_samples=10000, ii=i)


def sample_from_matrix(
    dataset: str, matrix_path: str, n_samples: int = 10000, ii: int = 0
):
    """对指定的数据集与邻接矩阵文件进行线性高斯贝叶斯网络拟合并采样。

    Args:
        dataset: 数据集名，对应 datasets/{dataset}.csv
        matrix_path: 矩阵文件路径（.npy），矩阵应为邻接矩阵 (shape p x p)
        n_samples: 采样数量
        out_path: 输出 CSV 路径；若为 None，会写入 output/{dataset}/sample/sampled_{dataset}_{basename}.csv

    Returns:
        dict: {'matrix': matrix_path, 'out': out_file, 'n_samples': n_samples, 'status': 'ok'/'skipped', 'reason': ...}
    """
    import numpy as np
    import pandas as pd

    file_path = Path(f"datasets/{dataset}.csv")
    if not file_path.exists():
        return {
            "matrix": matrix_path,
            "status": "skipped",
            "reason": f"data file not found: {file_path}",
        }

    df = pd.read_csv(file_path)
    df = df.dropna()
    cols = list(df.columns)

    try:
        adj = np.load(matrix_path, allow_pickle=True)
        print(f"Loaded adjacency matrix from {matrix_path}:\n{adj}")
    except Exception as e:
        return {
            "matrix": matrix_path,
            "status": "skipped",
            "reason": f"failed to load matrix: {e}",
        }

    if adj is None:
        return {"matrix": matrix_path, "status": "skipped", "reason": "matrix is None"}

    if adj.shape[0] != len(cols) or adj.shape[1] != len(cols):
        return {
            "matrix": matrix_path,
            "status": "skipped",
            "reason": f"matrix shape {adj.shape} does not match data columns {len(cols)}",
        }

    # build LinearGaussianBayesianNetwork
    try:
        from pgmpy.models import LinearGaussianBayesianNetwork
    except Exception as e:
        return {
            "matrix": matrix_path,
            "status": "skipped",
            "reason": f"pgmpy not available: {e}",
        }

    G = LinearGaussianBayesianNetwork()
    G.add_nodes_from(cols)
    for i in range(adj.shape[0]):
        for j in range(adj.shape[1]):
            if int(adj[i, j]) == 1:
                # edge from i -> j (i is parent of j)
                G.add_edge(cols[i], cols[j])

    try:
        G.fit(df)
    except Exception as e:
        return {
            "matrix": matrix_path,
            "status": "skipped",
            "reason": f"failed to fit LG-BN: {e}",
        }

    try:
        sampled = G.simulate(n_samples)
    except Exception as e:
        return {
            "matrix": matrix_path,
            "status": "skipped",
            "reason": f"failed to simulate: {e}",
        }

    # determine output path
    out_file = f"CTabDM/eval/fake_datasets/{dataset}/sampled_{dataset}_ctabdm_{ii}.csv"
    if not Path(out_file).parent.exists():
        os.makedirs(Path(out_file).parent, exist_ok=True)
    sampled_df = pd.DataFrame(sampled, columns=cols)
    sampled_df.to_csv(out_file, index=False)

    return {
        "matrix": matrix_path,
        "out": str(out_file),
        "n_samples": n_samples,
        "status": "ok",
    }


def batch_sample_dags(dataset: str, n_samples: int = 10000):
    """扫描 output/{dataset}/dags 下所有 .npy 矩阵文件，逐个调用 sample_from_matrix 并返回结果列表。"""
    import glob

    dag_dir = Path(f"output/{dataset}/dags")
    if not dag_dir.exists():
        print(f"[WARN] dags directory not found: {dag_dir}")
        return []

    files = sorted([str(p) for p in dag_dir.glob("*.npy")])
    results = []
    for f in files:
        res = sample_from_matrix(
            dataset, f, n_samples=n_samples, ii=f.split("_")[-1].split(".")[0]
        )
        results.append(res)
        if res.get("status") == "ok":
            print(f"Sampled from {f} -> {res.get('out')}")
        else:
            print(f"Skipped {f}: {res.get('reason')}")

    return results


def sample_disc(dataset: str):
    import pandas as pd
    import numpy as np

    # 1. 读取CSV并指定连续列（其余自动视为离散列）
    file_path = f"datasets/{dataset}.csv"
    continuous_cols = []  # 手动指定连续列

    df = pd.read_csv(file_path)
    cols = df.columns
    df = pd.DataFrame(df, columns=cols)
    # 2. 对连续列进行分箱（这里简单取整，后续可替换为其他分箱方法）
    processed_df = df.copy()

    # 3. 采样方法
    def _sample(adj_mat, data, verbose=1, n_bins=1) -> np.ndarray:
        if verbose is None or not isinstance(verbose, int):
            verbose = 1

        # 1. 识别连续特征并进行分箱离散化
        for col in continuous_cols:
            # 使用等频分箱(quantile)避免某些区间数据过少
            # data[col] = pd.qcut(data[col], q=n_bins, duplicates='drop', labels=False)
            # 或者使用等宽分箱
            data[col] = pd.cut(data[col], bins=n_bins, labels=False)

        # 2. 构建贝叶斯网络
        from pgmpy.models import DiscreteBayesianNetwork
        from pgmpy.sampling import BayesianModelSampling

        edges = []
        nodes = data.columns
        G = DiscreteBayesianNetwork()
        G.add_nodes_from(nodes)

        for i in range(len(adj_mat)):
            for j in range(len(adj_mat)):
                if adj_mat[i][j] == 1:
                    edges.append([i, j])
                    G.add_edge(nodes[i], nodes[j])

        # rows=np.random.randint(0, data.shape[0], size=100)
        # print(rows)
        # 3. 拟合模型
        G.fit(data[:5])

        # 4. 采样
        result = G.simulate(5000)
        sorted_result = result[nodes]

        return sorted_result

    sampled_data = _sample(get_adj(dataset), processed_df)

    # 4. 将连续列的离散值还原为连续值（通过随机数）
    final_data = sampled_data.copy()

    # 5. 保存最终数据
    final_data.to_csv("synthetic_data_continuous.csv", index=False)

    print("处理完成！")


def ganblr_sample(dataset: str):

    from ganblr.models import GANBLR, GANBLRPP

    os.makedirs(f"output/{dataset}/sample/", exist_ok=True)

    df = pd.read_csv(f"datasets/{dataset}.csv")
    x, y = df.values[:, :-1], df.values[:, -1]  # last column is the target variable
    dag = get_adj(dataset)  # get the adjacency matrix

    numcols = {
        "adult": [],
        "abalone": [1, 2, 3, 4, 5, 6, 7],
        "pm25": [4, 5, 6, 7, 9, 10],
        "statlog": range(36),
        "shuttle": range(9),
    }

    # model = GANBLR()
    model = GANBLRPP(numerical_columns=numcols[dataset])
    model.fit(
        x[:1000],
        y[:1000],
        epochs=30,
        dag=dag,
        k=0,
        save_dir=f"output/{dataset}/sample/models/",
    )

    # generate synthetic data
    synthetic_data = model.sample(5000)

    # save synthetic data to csv
    csv = pd.DataFrame(synthetic_data)
    csv.to_csv(f"output/{dataset}/sample/syn_{dataset}.csv", index=False)


def cpt_sample(dataset: str, type: str):
    from cpt_tf2 import CPT

    config, _ = get_config()
    config.model_batch = 10  # 每次生成的网络数量
    config.data_batch = 10000  # 每份数据的样本数
    config.hidden_dim = 64  # 特征向量维度
    config.learning_rate = 1e-4  # 学习率
    df = pd.read_csv(f"datasets/{dataset}.csv")
    columns = df.columns
    df = df.dropna()  # 去除缺失值
    config.max_length = df.shape[1]  # 设置最大长度为列数

    adj_matrix = get_adj(dataset, type)
    zeros = np.zeros((config.max_length, config.max_length), dtype=int)  # 无连接图
    ones = np.ones((config.max_length, config.max_length), dtype=int) - np.eye(
        config.max_length, dtype=int
    )  # 完全图（无自环）
    tri = np.triu(ones, k=1)
    # adj_matrix = tri
    # adj_matrix = corl_dag(dataset)

    print("邻接矩阵:\n", adj_matrix)

    def build_features():
        # node features
        with tf.name_scope("node_features"):
            path = f"output/{dataset}/vae/data/encode/encoded_data.csv"
            df = pd.read_csv(path)
            # 根据最后一列分组 得到max_length组特征向量 分别求平均得到最终的feature向量
            node_features = df.groupby(df.columns[-1]).mean().to_numpy()
            print("节点特征向量形状:", node_features.shape)

        return node_features

    # 复制扩展到modelbatch维
    node_features = build_features()
    # node_features = np.ones((config.max_length, config.hidden_dim), dtype=np.float32)
    node_features = np.tile(
        np.expand_dims(node_features, axis=0), (config.model_batch, 1, 1)
    )  # [model_batch, max_length, hidden_dim]
    num_cols = {
        "adult": None,
        "abalone": [4, 5, 6, 7],
        "pm25": [4, 9],
        "adult_o": [2],
        "abalone_o": [1, 2, 3, 4, 5, 6, 7],
        "pm25_o": [4, 5, 6, 7, 9],
        "shuttle": None,
        "statlog": None,
        "cancer": None,
        "asia": None,
        "syn": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9],
    }

    # 4. 创建并训练模型
    model = CPT(
        config, adj=adj_matrix, observations=df.values,#numerical_cols=num_cols[dataset]
    )

    # model.load(f"output/{dataset}/cpt/models")

    model.train(node_features, num_epochs=1000)

    # model.save(f"output/{dataset}/cpt/models")

    cpt_list = model.infer(node_features[0])

    samples = model.sample(cpt_list, num_samples=10000)
    # 6. 保存采样数据
    samples_df = pd.DataFrame(samples, columns=columns)
    global i
    path = f"CTabDM/eval/fake_datasets/{dataset}/sampled_{dataset}_ctabdm_{type}.csv"
    os.makedirs(os.path.dirname(path), exist_ok=True)
    samples_df.to_csv(path, index=False)
    print("采样数据已保存到:", path)


# 实际调用示例
if __name__ == "__main__":
    import os

    for dataset in [
        # "adult",
        # "statlog",
        # "shuttle",
        # "sachs",
        # "child",
        # "alarm",
        # "insurance",
        # "survey",
        # "mildew",
        # "water",
        "barley"
    ]:
        # os.environ["CUDA_VISIBLE_DEVICES"] = "1"
        for i in range(1000, 1003):
            cpt_sample(dataset, f"rl_{i}")  # 不行就跑104

    # corl_dag("asia")  # 替换为实际数据集名称
    # sample_linear("concrete",305)  # 替换为实际数据集名称
    # batch_sample_dags("statlog", n_samples=5000)
