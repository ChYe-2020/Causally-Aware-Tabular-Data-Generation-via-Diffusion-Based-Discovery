#!/usr/bin/env python3
# Minimal runner for five baselines: smote, ctgan, ctabgan, tabddpm, ttvae
# - Uses original CSV from datasets/{dataset}.csv
# - Creates minimal metadata files required by baselines
# - Calls each baseline's train/sample functions
# - Copies final sampled CSV to CTabDM/eval/fakedatasets/{dataset}/sampled_{dataset}_{baseline}.csv

import os
import shutil
import json
import pandas as pd
from types import SimpleNamespace
from pathlib import Path

BASE = os.path.dirname(__file__)
REPO = os.path.abspath(os.path.join(BASE, "..", ".."))
DATASETS = os.path.join("datasets")
DATA = os.path.join(REPO, "data")
DATAPROFILE = os.path.join(BASE, "data_profile")
TABDDPM_CONFIGS = os.path.join(BASE, "baselines", "tabddpm", "configs")
FAKE_ROOT = os.path.join("CTabDM", "eval", "fake_datasets")

# import baseline modules
from baselines.shallow import main as shallow
from baselines.sdv import main as sdv_main
from baselines.ctabgan import main as ctabgan_main
from baselines.tabddpm import main_train as tabddpm_train, main_sample as tabddpm_sample
from ttvae import main as ttvae_main

i = 1

def copy_out(dataset, baseline, src_path):
    out_dir = os.path.join(FAKE_ROOT, dataset)
    os.makedirs(out_dir, exist_ok=True)
    dst = os.path.join(out_dir, f"sampled_{dataset}_{baseline}_{i}.csv")
    shutil.copyfile(src_path, dst)

        


def run_smote(dataset):
    args = SimpleNamespace()
    args.dataname = dataset
    args.device = "gpu"
    args.sdv_epochs = 1
    shallow.train_smote(args)
    # expected output synthetic/{dataset}/SMOTE.csv
    src = os.path.join("synthetic", dataset, "SMOTE.csv")
    copy_out(dataset, "smote", src)


def run_ctgan(dataset):
    args = SimpleNamespace()
    args.dataname = dataset
    args.device = "gpu"
    args.sdv_epochs = 100
    args.save_path = os.path.join("synthetic", dataset, "ctgan.csv")
    sdv_main.train_ctgan(args)
    copy_out(dataset, "ctgan", args.save_path)


def run_ctabgan(dataset):
    args = SimpleNamespace()
    args.dataname = dataset
    args.device = "gpu"
    args.sdv_epochs = 100
    args.save_path = os.path.join("synthetic", dataset, "ctabgan.csv")
    ctabgan_main.train(args)
    ctabgan_main.sample(args)
    copy_out(dataset, "ctabgan", args.save_path)


def run_tabddpm(dataset):
    args = SimpleNamespace()
    args.dataset = dataset
    args.gpu = 0
    args.ddim = True
    args.tabddpm_epochs = 500
    args.save_path = os.path.join("synthetic", dataset, "tabddpm.csv")
    tabddpm_train.main(args)
    tabddpm_sample.main(args)
    copy_out(dataset, "tabddpm", args.save_path)


def run_ttvae(dataset):
    args = SimpleNamespace()
    args.dataname = dataset
    args.gpu = 0
    args.ttvae_epochs = 100
    args.save_path = os.path.join("synthetic", dataset, "ttvae.csv")
    ttvae_main.train(args)
    ttvae_main.sample(args)
    copy_out(dataset, "ttvae", args.save_path)


def main(dataset):
    for t in range(5):
        run_smote(dataset)
        run_ctgan(dataset)
        run_ctabgan(dataset)
        run_tabddpm(dataset)
        run_ttvae(dataset)
        global i
        i += 1
    i = 1

if __name__ == "__main__":
    for dataset in [
            # "adult",
            # "statlog",
            # "shuttle",
            # "sachs",
            # "child",
            # "alarm",
            # "insurance",
            # "survey",
            # "mildew",
            # "water",
            "barley"
        ]:
        main(dataset)  # 替换为实际数据集名称
