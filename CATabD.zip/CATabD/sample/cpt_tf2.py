import tensorflow as tf
from spektral.layers import GATConv
import numpy as np
from tqdm import tqdm
from helpers.config_graph import get_config
import os
import pickle
from sklearn.mixture import BayesianGaussianMixture
from sklearn.preprocessing import MinMaxScaler, LabelEncoder, OrdinalEncoder
from scipy.stats import truncnorm
import numpy as np


os.environ["XLA_FLAGS"] = "--xla_gpu_cuda_data_dir=/home/zh/.conda/envs/zh"
# 设置 GPU 内存增长
device = 1
gpus = tf.config.list_physical_devices("GPU")
print(f"Available GPUs: {gpus}")
tf.config.set_visible_devices(gpus[device], "GPU")  # 使用第二个 GPU
tf.config.experimental.set_memory_growth(gpus[device], True)  # 设置内存增长


class DMMDiscritizer:
    def __init__(self, random_state):
        self.__dmm_params = dict(
            weight_concentration_prior_type="dirichlet_process",
            n_components=2 * 5,
            reg_covar=0,
            init_params="random",
            max_iter=1500,
            mean_precision_prior=0.1,
            random_state=random_state,
        )

        self.__scaler = MinMaxScaler()
        self.__dmms = []
        self.__arr_mu = []
        self.__arr_sigma = []
        self._random_state = random_state

    def fit(self, x):
        """
        Do DMM Discritization.

        Parameter:
        ---------
        x (2d np.numpy): data to be discritize. Must bu numeric data.

        Return:
        ----------
        self

        """
        assert isinstance(x, np.ndarray)
        assert len(x.shape) == 2

        x_scaled = self.__scaler.fit_transform(x)
        self.__internal_fit(x_scaled)
        return self

    def transform(self, x) -> np.ndarray:
        x = self.__scaler.transform(x)
        arr_modes = []
        for i, dmm in enumerate(self.__dmms):
            modes = dmm.predict(x[:, i : i + 1])
            modes = LabelEncoder().fit_transform(modes)  # .astype(int)
            arr_modes.append(modes)
        return self.__internal_transform(x, arr_modes)

    def fit_transform(self, x) -> np.ndarray:
        assert isinstance(x, np.ndarray)
        assert len(x.shape) == 2

        x_scaled = self.__scaler.fit_transform(x)
        arr_modes = self.__internal_fit(x_scaled)
        return self.__internal_transform(x_scaled, arr_modes)

    def __internal_fit(self, x):
        self.__dmms.clear()
        self.__arr_mu.clear()
        self.__arr_sigma.clear()

        arr_mode = []
        for i in range(x.shape[1]):
            cur_column = x[:, i : i + 1]
            dmm = BayesianGaussianMixture(**self.__dmm_params)
            y = dmm.fit_predict(cur_column)
            lbe = LabelEncoder().fit(y)
            mu = dmm.means_[: len(lbe.classes_)]
            sigma = np.sqrt(dmm.covariances_[: len(lbe.classes_)])

            arr_mode.append(lbe.transform(y))  # .astype(int))
            # self.__arr_lbes.append(lbe)
            self.__dmms.append(dmm)
            self.__arr_mu.append(mu.ravel())
            self.__arr_sigma.append(sigma.ravel())
        return arr_mode

    def __internal_transform(self, x, arr_modes):
        _and = np.logical_and
        _not = np.logical_not

        discretized_data = []
        for i, (modes, mu, sigma) in enumerate(
            zip(arr_modes, self.__arr_mu, self.__arr_sigma)
        ):

            cur_column = x[:, i]
            cur_mu = mu[modes]
            cur_sigma = sigma[modes]
            x_std = cur_column - cur_mu

            less_than_n3sigma = x_std <= -3 * cur_sigma
            less_than_n2sigma = x_std <= -2 * cur_sigma
            less_than_n1sigma = x_std <= -cur_sigma
            less_than_0 = x_std <= 0
            less_than_1sigma = x_std <= cur_sigma
            less_than_2sigma = x_std <= 2 * cur_sigma
            less_than_3sigma = x_std <= 3 * cur_sigma

            discretized_x = 8 * modes
            discretized_x[_and(_not(less_than_n3sigma), less_than_n2sigma)] += 1
            discretized_x[_and(_not(less_than_n2sigma), less_than_n1sigma)] += 2
            discretized_x[_and(_not(less_than_n1sigma), less_than_0)] += 3
            discretized_x[_and(_not(less_than_0), less_than_1sigma)] += 4
            discretized_x[_and(_not(less_than_1sigma), less_than_2sigma)] += 5
            discretized_x[_and(_not(less_than_2sigma), less_than_3sigma)] += 6
            discretized_x[_not(less_than_3sigma)] += 7
            discretized_data.append(discretized_x.reshape(-1, 1))

        return np.hstack(discretized_data)

    def inverse_transform(self, x, verbose=1) -> np.ndarray:
        x_modes = x // 8
        x_bins = x % 8

        def __sample_one_column(i, mu, sigma):
            cur_column_modes = x_modes[:, i]
            cur_column_bins = x_bins[:, i]
            cur_column_mode_uniques = np.unique(cur_column_modes)
            inversed_x = np.zeros_like(cur_column_modes, dtype=float)

            for mode in cur_column_mode_uniques:
                mode = int(mode)
                cur_mode_idx = cur_column_modes == mode
                cur_mode_mu = mu[mode]
                cur_mode_sigma = sigma[mode]

                sample_results = self.__sample_from_truncnorm(
                    cur_column_bins[cur_mode_idx],
                    cur_mode_mu,
                    cur_mode_sigma,
                    random_state=self._random_state,
                )
                inversed_x[cur_mode_idx] = sample_results

            return inversed_x.reshape(-1, 1)

        if verbose:
            from tqdm import tqdm

            _progress_wrapper = lambda iterable: tqdm(
                iterable, desc="sampling", total=len(self.__arr_mu)
            )
        else:
            _progress_wrapper = lambda iterable: iterable
        inversed_data = np.hstack(
            [
                __sample_one_column(i, mu, sigma)
                for i, (mu, sigma) in _progress_wrapper(
                    enumerate(zip(self.__arr_mu, self.__arr_sigma))
                )
            ]
        )

        # the sampling progress is fast enough so there is no need for parallelization
        # inversed_data = np.hstack(Parallel(n_jobs=n_jobs, verbose=verbose)(delayed(__sample_one_column)(i, mu, sigma)
        #    for i, (mu, sigma) in enumerate(zip(self.__arr_mu, self.__arr_sigma))))
        return self.__scaler.inverse_transform(inversed_data)

    @staticmethod
    def __sample_from_truncnorm(bins, mu, sigma, random_state=None):
        sampled_results = np.zeros_like(bins, dtype=float)

        def __sampling(idx, range_min, range_max):
            sampling_size = np.sum(idx)
            if sampling_size != 0:
                sampled_results[idx] = truncnorm.rvs(
                    range_min,
                    range_max,
                    loc=mu,
                    scale=sigma,
                    size=sampling_size,
                    random_state=random_state,
                )

        # shape param (min, max) of scipy.stats.truncnorm.rvs are still defined with respect to the standard normal
        __sampling(bins == 0, np.NINF, -3)
        __sampling(bins == 1, -3, -2)
        __sampling(bins == 2, -2, -1)
        __sampling(bins == 3, -1, 0)
        __sampling(bins == 4, 0, 1)
        __sampling(bins == 5, 1, 2)
        __sampling(bins == 6, 2, 3)
        __sampling(bins == 7, 3, np.inf)
        return sampled_results


class CPT(tf.keras.Model):
    def __init__(self, config, adj, observations, numerical_cols=None):
        super(CPT, self).__init__()
        self.config = config
        self.num_neurons = config.hidden_dim
        self.model_batch = config.model_batch
        self.data_batch = config.data_batch
        self.numerical_cols = numerical_cols

        # 网络结构信息
        self.max_length = adj.shape[0]

        # GAT层
        self.gat_layers = [
            GATConv(
                self.num_neurons,
                attn_heads=1,
                concat_heads=False,
                activation=None,
                use_bias=True,  # 使用偏置
                dropout_rate=0,  # 不使用dropout
                kernel_initializer="glorot_uniform",  # 使用Glorot初始化
            ),
            GATConv(
                self.num_neurons,
                attn_heads=1,
                concat_heads=False,
                activation=None,  # 最后一层不使用激活函数
                use_bias=True,  # 使用偏置
                dropout_rate=0,  # 不使用dropout
                kernel_initializer="glorot_uniform",  # 使用Glorot初始化
            ),
        ]

        # normlayer
        self.norm_layer = tf.keras.layers.LayerNormalization(
            axis=-1, epsilon=1e-6, center=True, scale=True
        )

        # 检查是否有环
        assert np.all(
            np.linalg.matrix_power(adj, self.max_length) == 0
        ), "The input graph has cycles!"
        
        # 预计算
        self.base_adj = tf.convert_to_tensor(adj, dtype=tf.float32)

        # 存储观测数据用于预计算
        self.observations = observations

        self.data_preprocess()

        self.node_k, self.node_p, self.parent_combinations = self._precompute_k_values()

        # 在Python端计算unique_k值
        self.unique_ks = tf.unique(tf.squeeze(self.node_k))[0].numpy()

        # 投影矩阵
        self.proj_matrices = self._init_projection_matrices()

        self.lookup_tables = self._create_lookup_tables(observations)

        self.topo_order = self._get_topo_order()

        # 优化器
        self.optimizer = tf.keras.optimizers.Adam(config.learning_rate)

    def data_preprocess(self):

        # 连续列进行离散化
        if self.numerical_cols is not None:
            self.discritizer = DMMDiscritizer(random_state=42)
            numerical_data = self.observations[:, self.numerical_cols]
            self.observations[:, self.numerical_cols] = self.discritizer.fit_transform(
                numerical_data
            )

        # 离散列进行Ordinal编码
        from sklearn.preprocessing import OrdinalEncoder
        import pandas as pd

        #
        df = pd.DataFrame(self.observations)

        # 初始化 OrdinalEncoder
        self.ordinal_encoder = OrdinalEncoder(
            dtype=int,
            handle_unknown="use_encoded_value",
            unknown_value=-1,
            encoded_missing_value=-1,
        )

        # 进行编码（自动处理所有列）
        encoded_data = self.ordinal_encoder.fit_transform(df)

        # 转换为 DataFrame（保持列名）
        encoded_df = pd.DataFrame(encoded_data, columns=df.columns)

        # 计算每一列的取值数量（max + 1）
        n_values = [encoded_df[col].max() + 1 for col in encoded_df.columns]

        self.num_values = tf.constant(n_values, dtype=tf.int64)
        self.observations = encoded_df.values

        print(f"Encoded data shape: {encoded_df.shape}")
        print(f"Number of unique values per column: {n_values}")

    def _get_topo_order(self):
        in_degree = np.sum(self.base_adj.numpy(), axis=0)
        queue = list(np.where(in_degree == 0)[0])
        topo_order = []
        while queue:
            node = queue.pop(0)
            topo_order.append(node)
            for child in np.where(self.base_adj.numpy()[node] > 0)[0]:
                in_degree[child] -= 1
                if in_degree[child] == 0:
                    queue.append(child)
        return topo_order

    def _create_lookup_tables(self, observations):
        """预创建所有查找表"""
        tables = []
        for node in range(self.max_length):
            parents = tf.where(self.base_adj[:, node] > 0)[:, 0]
            if tf.size(parents) > 0:
                unique_combs, comb_map = self.parent_combinations[node]
                comb_keys = [",".join(map(str, comb)) for comb in unique_combs]
                table = tf.lookup.StaticHashTable(
                    tf.lookup.KeyValueTensorInitializer(
                        keys=comb_keys,
                        values=list(range(len(comb_keys))),
                        key_dtype=tf.string,
                        value_dtype=tf.int64,
                    ),
                    default_value=-1,
                )
            else:
                table = None
            tables.append(table)
        return tables

    def inspect_lookup_tables(self, save_path=None):
        """查看并可选地保存 lookup tables 内容"""
        table_info = {}

        for node_idx, table in enumerate(self.lookup_tables):
            if table is None:
                table_info[f"node_{node_idx}"] = "No parents (root node)"
                continue

            # 使用 export 方法获取键值对
            keys, values = table.export()

            # 转换为numpy数组
            keys = keys.numpy()
            values = values.numpy()

            # 转换为可读格式
            decoded_keys = [k.decode("utf-8") for k in keys]
            table_info[f"node_{node_idx}"] = dict(zip(decoded_keys, values))

            # 打印到控制台
            print(f"\nNode {node_idx} lookup table:")
            for k, v in zip(decoded_keys, values):
                print(f"  Parent combination: {k} -> Index: {v}")

        # 可选保存到文件
        if save_path:
            with open(save_path, "wb") as f:
                pickle.dump(table_info, f)
            print(f"\nLookup tables saved to {save_path}")

        return table_info

    def _precompute_k_values(self):
        """基于真实数据剪枝的k值计算"""
        num_values_np = self.num_values.numpy()
        base_adj_np = self.base_adj.numpy()
        observations_np = self.observations

        k_list, p_list = [], []
        parent_combinations_list = []

        for i in range(self.max_length):
            parents = np.where(base_adj_np[:, i] > 0)[0]
            c = num_values_np[i]

            if len(parents) > 0:
                # 获取所有观测中父节点的组合
                parent_obs = observations_np[:, parents]
                # 找到所有唯一的父节点组合
                unique_combinations = np.unique(parent_obs, axis=0)
                p = len(unique_combinations)

                # 创建查找字典
                combination_map = {}
                for idx, comb in enumerate(unique_combinations):
                    combination_map[tuple(comb)] = idx
                parent_combinations_list.append((unique_combinations, combination_map))
            else:
                p = 1
                parent_combinations_list.append((None, None))

            k = p * c
            k_list.append(int(k))
            p_list.append(int(p))

            # 打印每个节点的父节点组合信息
            print(f"Node {i}: k={k}, p={p}, c={c}, parents={parents.tolist()}")

        return k_list, p_list, parent_combinations_list

    def _init_projection_matrices(self):
        """初始化投影矩阵"""
        matrices = {}
        for k in self.unique_ks:
            # print(f"Initializing projection matrix for k={k}")
            k_int = int(k)
            matrices[k_int] = self.add_weight(
                name=f"proj_matrix_{k_int}",
                shape=(self.num_neurons, k_int),
                initializer="glorot_uniform",
                trainable=True,
            )
        return matrices

    def call(self, node_features):
        """
        生成多个贝叶斯网络的CPT
        node_features: [model_batch, max_length, hidden_dim]
        返回: [max_length, model_batch, c, p]
        """
        if not isinstance(node_features, tf.Tensor):
            node_features = tf.convert_to_tensor(node_features, dtype=tf.float32)

        model_batch = self.model_batch
        adj = tf.tile(tf.expand_dims(self.base_adj, 0), [model_batch, 1, 1])
        adj += tf.eye(self.max_length, dtype=tf.float32)  # 添加自环

        # 多层GAT
        node_embeddings = node_features
        for gat_layer in self.gat_layers:
            input = node_embeddings
            # 归一化
            node_embeddings = self.norm_layer(
                node_embeddings
            )  # [model_batch, max_length, hidden_dim]
            node_embeddings = gat_layer(
                [node_embeddings, adj]
            )  # [model_batch, max_length, hidden_dim]
            # residual connection

            # 激活（最后一层不使用激活函数）
            if gat_layer != self.gat_layers[-1]:
                node_embeddings = tf.nn.relu(node_embeddings)

            node_embeddings += input

        # 生成CPT
        cpt_list = []
        for i in range(self.max_length):
            p, c, k = self.node_p[i], self.num_values[i], self.node_k[i]
            proj_w = self.proj_matrices[int(k)]

            # [model_batch, k]
            logits = tf.matmul(node_embeddings[:, i, :], proj_w)

            # [model_batch, p, c]
            prob = tf.nn.softmax(tf.reshape(logits, [-1, p, c]), axis=-1)

            # [model_batch, c, p]
            cpt_list.append(tf.transpose(prob, [0, 2, 1]))

        return cpt_list  # [max_length, model_batch, c, p]

    def compute_loss(self, observations, cpt_list):
        """
        优化后的loss计算，使用预计算的查找表和向量化操作
        observations: [data_batch, max_length]
        cpt_list: [max_length, model_batch, c, p]
        """
        model_batch = self.model_batch
        data_batch = tf.shape(observations)[0]
        max_length = self.max_length

        total_loss = 0.0

        # 预处理所有节点的父节点组合索引
        parent_indices = []
        for node in range(max_length):
            parents = tf.where(self.base_adj[:, node] > 0)[:, 0]
            if tf.size(parents) > 0:
                # 获取当前批次中所有样本的父节点组合
                parent_obs = tf.gather(
                    observations, parents, axis=1
                )  # [data_batch, num_parents]

                # 将父节点观测转换为字符串键
                parent_keys = tf.strings.reduce_join(
                    tf.as_string(parent_obs), separator=",", axis=1
                )

                # 使用预创建的查找表获取索引
                parent_idx = self.lookup_tables[node].lookup(
                    parent_keys
                )  # [data_batch]
            else:
                parent_idx = tf.zeros(data_batch, dtype=tf.int64)

            parent_indices.append(parent_idx)

        # 转换为Tensor [max_length, data_batch]
        parent_indices = tf.stack(parent_indices, axis=0)

        # 获取所有节点的观测值 [max_length, data_batch]
        node_observations = tf.transpose(observations)  # [max_length, data_batch]

        for model_idx in range(model_batch):
            # 收集当前模型的所有CPT [max_length, c, p]
            network_cpt = []
            for node in range(max_length):
                network_cpt.append(cpt_list[node][model_idx])

            # 向量化计算对数概率
            log_probs = []
            for node in range(max_length):
                # 获取当前节点的CPT [c, p]
                cpt = network_cpt[node]

                # 获取当前节点的观测值和父节点索引 [data_batch]
                obs = node_observations[node]  # [data_batch]
                p_idx = parent_indices[node]  # [data_batch]

                # 使用gather_nd获取对应概率 [data_batch]
                indices = tf.stack([obs, p_idx], axis=1)  # [data_batch, 2]
                probs = tf.gather_nd(cpt, indices)  # [data_batch]

                log_probs.append(tf.math.log(probs + 1e-10))  # [data_batch]

            # 求和得到每个样本的对数概率 [data_batch]
            sample_log_probs = tf.reduce_sum(tf.stack(log_probs, axis=1), axis=1)

            # 平均对数似然
            total_loss += -tf.reduce_mean(sample_log_probs)

        return total_loss / tf.cast(model_batch, tf.float32)

    def train_step(self, node_features, observations):
        with tf.GradientTape() as tape:
            cpt_list = self(node_features)
            loss = self.compute_loss(observations, cpt_list)

        # 获取所有可训练变量
        trainable_vars = self.trainable_variables
        gradients = tape.gradient(loss, trainable_vars)

        # 梯度裁剪（关键修改点）
        max_gradient_norm = 1.0  # 根据任务调整阈值（常用1.0或5.0）
        gradients, _ = tf.clip_by_global_norm(gradients, max_gradient_norm)

        # 调试：打印梯度信息
        # for var, grad in zip(trainable_vars, gradients):
        #     if "proj_matrix" in var.name:
        #         print(f"Variable {var.name}:")
        #         print(f"  Value mean: {tf.reduce_mean(var).numpy():.4f}")
        #         print(f"  Gradient mean: {tf.reduce_mean(grad).numpy():.4f}")

        self.optimizer.apply_gradients(zip(gradients, self.trainable_variables))
        return loss

    def train(self, node_features, num_epochs):
        """使用tf.data优化训练"""
        # 计算最小损失
        min_loss = self.empirical_loss(
            self.observations, self.base_adj.numpy(), self.num_values.numpy()
        )
        print(f"Minimum empirical loss: {min_loss:.4f}")

        data_batch = self.data_batch
        total_samples = len(self.observations)

        # 创建tf.data.Dataset
        dataset = tf.data.Dataset.from_tensor_slices(self.observations)
        dataset = dataset.shuffle(total_samples).batch(data_batch)
        dataset = dataset.prefetch(tf.data.AUTOTUNE)

        train_loss = tf.keras.metrics.Mean(name="train_loss")

        for epoch in tqdm(range(num_epochs), desc="Training"):
            for batch_obs in dataset:
                # 训练步骤
                loss = self.train_step(node_features, batch_obs)
                train_loss(loss)

            tqdm.write(f"Epoch {epoch+1}, Loss: {train_loss.result():.4f}")
            train_loss.reset_state()
            print("GAT layer weight:", self.gat_layers[0].get_weights()[0][0][0][0])

    def infer(self, node_features):
        """
        生成多个贝叶斯网络的CPT
        node_features: [max_length, hidden_dim]
        返回: [max_length, c, p]
        """
        if not isinstance(node_features, tf.Tensor):
            node_features = tf.convert_to_tensor(node_features, dtype=tf.float32)

        adj = tf.expand_dims(self.base_adj, 0) + tf.eye(
            self.max_length, dtype=tf.float32
        )

        node_embeddings = tf.expand_dims(
            node_features, 0
        )  # [1, max_length, hidden_dim]

        for gat_layer in self.gat_layers:
            input = node_embeddings
            # 归一化
            node_embeddings = self.norm_layer(
                node_embeddings
            )  # [model_batch, max_length, hidden_dim]
            node_embeddings = gat_layer(
                [node_embeddings, adj]
            )  # [model_batch, max_length, hidden_dim]
            # residual connection

            # 激活（最后一层不使用激活函数）
            if gat_layer != self.gat_layers[-1]:
                node_embeddings = tf.nn.relu(node_embeddings)

            node_embeddings += input

        # 生成CPT
        cpt_list = []
        for i in range(self.max_length):
            p, c, k = self.node_p[i], self.num_values[i], self.node_k[i]
            proj_w = self.proj_matrices[int(k)]

            # [1, k]
            logits = tf.matmul(node_embeddings[:, i, :], proj_w)

            # [1, p, c]
            prob = tf.nn.softmax(tf.reshape(logits, [-1, p, c]), axis=-1)

            # [1, c, p]
            cpt_list.append(tf.squeeze(tf.transpose(prob, [0, 2, 1]), axis=0))

        return cpt_list  # [max_length, c, p]

    def inspect_cpt_list(self, cpt_list, save_path=None):
        """查看并可选地保存 CPT 列表内容"""
        cpt_info = {}

        for node_idx, cpt in enumerate(cpt_list):
            # 转换为 numpy 数组
            cpt_np = cpt.numpy()
            cpt_info[f"node_{node_idx}"] = cpt_np

            # 打印到控制台
            print(f"\nNode {node_idx} CPT (shape: {cpt_np.shape}):")
            print(cpt_np)

        # 可选保存到文件
        if save_path:
            with open(save_path, "wb") as f:
                pickle.dump(cpt_info, f)
            print(f"\nCPT list saved to {save_path}")

        return cpt_info

    def save(self, path):
        """完全使用 NumPy 方式保存所有参数"""
        if not os.path.exists(path):
            os.makedirs(path)

        # 1. 保存 GAT 层权重
        gat_weights_path = os.path.join(path, "gat_weights")
        os.makedirs(gat_weights_path, exist_ok=True)

        for l, gat_layer in enumerate(self.gat_layers):
            # 获取每个 GAT 层的权重
            gat_weights = gat_layer.get_weights()
            os.makedirs(os.path.join(gat_weights_path, f"layer_{l}"), exist_ok=True)
            for i, w in enumerate(gat_weights):
                np.save(
                    os.path.join(gat_weights_path, f"layer_{l}", f"gat_weight_{i}.npy"),
                    w,
                )

        # 2. 保存投影矩阵
        proj_matrices_path = os.path.join(path, "proj_matrices")
        os.makedirs(proj_matrices_path, exist_ok=True)

        for k, matrix in self.proj_matrices.items():
            np.save(
                os.path.join(proj_matrices_path, f"proj_matrix_{k}.npy"), matrix.numpy()
            )

    def load(self, path):
        """从 NumPy 文件加载所有参数"""
        # 1. 加载 GAT 层权重
        dummy_input = tf.zeros([1, self.max_length, self.num_neurons], dtype=tf.float32)
        _ = self(dummy_input)  # 这会初始化所有层和变量

        for l, gat_layer in enumerate(self.gat_layers):
            gat_weights_path = os.path.join(path, "gat_weights", f"layer_{l}")
            gat_weight_files = sorted(
                [f for f in os.listdir(gat_weights_path) if f.startswith("gat")]
            )
            gat_weights = [
                np.load(os.path.join(gat_weights_path, f)) for f in gat_weight_files
            ]
            gat_layer.set_weights(gat_weights)
        # for l, gat_layer in enumerate(self.gat_layers):

        #     gat_weights_path = os.path.join(path, "gat_weights", f"layer_{l}")
        #     gat_weight_files = sorted(
        #         [f for f in os.listdir(gat_weights_path) if f.startswith("gat")]
        #     )
        #     gat_weights = [
        #         np.load(os.path.join(gat_weights_path, f)) for f in gat_weight_files
        #     ]

        #     # 确保 GAT 层已初始化
        #     dummy_input = [
        #         tf.zeros([1, self.max_length, self.num_neurons], dtype=tf.float32),
        #         tf.zeros([1, self.max_length, self.max_length], dtype=tf.float32),
        #     ]
        #     _ = gat_layer(dummy_input)  # 初始化层

        #     # 设置权重
        #     gat_layer.set_weights(gat_weights)

        # 2. 加载投影矩阵
        proj_matrices_path = os.path.join(path, "proj_matrices")
        for k in self.unique_ks:
            k_int = int(k)
            matrix_value = np.load(
                os.path.join(proj_matrices_path, f"proj_matrix_{k_int}.npy")
            )
            # 直接赋值给已存在的变量，而不是创建新变量
            self.proj_matrices[k_int].assign(matrix_value)

    def sample(self, cpt_list, num_samples=1):
        max_length = self.max_length
        samples = np.zeros((num_samples, max_length), dtype=np.int32)

        # 预计算拓扑排序（若频繁调用，移至 __init__）
        topo_order = self.topo_order

        for node in topo_order:
            parents = np.where(self.base_adj.numpy()[:, node] > 0)[0]
            cpt = cpt_list[node]  # [c, p]

            if len(parents) == 0:
                # 根节点批量采样
                probs = cpt[:, 0].numpy()
                samples[:, node] = np.random.choice(
                    np.arange(self.num_values[node]), size=num_samples, p=probs
                )
            else:
                # 批量处理父节点组合
                parent_values = samples[:, parents]  # [num_samples, num_parents]
                parent_keys = tf.strings.reduce_join(
                    tf.as_string(parent_values), separator=",", axis=1
                )
                p_indices = self.lookup_tables[node].lookup(parent_keys).numpy()

                # 处理未见过组合
                uniform_mask = p_indices == -1
                p_indices = np.maximum(p_indices, 0)

                # 批量采样
                for s in range(num_samples):
                    if uniform_mask[s]:
                        probs = np.ones(self.num_values[node]) / self.num_values[node]
                    else:
                        probs = cpt[:, p_indices[s]].numpy()
                    samples[s, node] = np.random.choice(
                        np.arange(self.num_values[node]), p=probs
                    )

        # 对样本进行逆变换
        samples = self.ordinal_encoder.inverse_transform(samples)

        if self.numerical_cols is not None:
            # 对数值列进行逆变换
            numerical_data = samples[:, self.numerical_cols]
            samples[:, self.numerical_cols] = self.discritizer.inverse_transform(
                numerical_data
            )

        return samples

    # def sample(self, cpt_list, num_samples=1):
    #     max_length = self.max_length
    #     valid_samples = []  # 存储有效样本

    #     # 预计算拓扑排序
    #     topo_order = self.topo_order

    #     while len(valid_samples) < num_samples :
    #         # 初始化当前尝试的样本
    #         current_sample = np.zeros(max_length, dtype=np.int32)
    #         is_valid = True  # 标记当前样本是否有效

    #         for node in topo_order:
    #             parents = np.where(self.base_adj.numpy()[:, node] > 0)[0]
    #             cpt = cpt_list[node]  # [c, p]

    #             if len(parents) == 0:
    #                 # 根节点采样
    #                 probs = cpt[:, 0].numpy()
    #                 current_sample[node] = np.random.choice(
    #                     np.arange(self.num_values[node]), p=probs
    #                 )
    #             else:
    #                 # 获取父节点组合
    #                 parent_values = current_sample[parents]  # [num_parents]
    #                 parent_key = ",".join(parent_values.astype(str))
    #                 p_index = self.lookup_tables[node].lookup(tf.constant([parent_key])).numpy()[0]

    #                 # 如果父节点组合未出现过，标记样本无效并跳出循环
    #                 if p_index == -1:
    #                     is_valid = False
    #                     break

    #                 # 根据CPT采样子节点
    #                 probs = cpt[:, p_index].numpy()
    #                 current_sample[node] = np.random.choice(
    #                     np.arange(self.num_values[node]), p=probs
    #                 )

    #         # 如果样本有效，加入结果集
    #         if is_valid:
    #             valid_samples.append(current_sample.copy())

    #     # 转换为数组并逆变换
    #     samples = np.array(valid_samples)
    #     print(samples.shape)
    #     samples = self.ordinal_encoder.inverse_transform(samples)

    #     if self.numerical_cols is not None:
    #         # 对数值列进行逆变换
    #         numerical_data = samples[:, self.numerical_cols]
    #         samples[:, self.numerical_cols] = self.discritizer.inverse_transform(
    #             numerical_data
    #         )

    #     return samples

    def empirical_loss(
        self, observations, adj, num_values, use_laplace_smoothing=False
    ):
        loss = 0.0
        n = len(observations)

        for node in range(observations.shape[1]):
            parents = np.where(adj[:, node] > 0)[0]
            if len(parents) == 0:
                counts = np.bincount(observations[:, node], minlength=num_values[node])
                if use_laplace_smoothing:
                    probs = (counts + 1) / (n + num_values[node])
                else:
                    probs = counts / n
                loss -= np.sum(counts * np.log(probs + 1e-10)) / n
            else:
                unique_combs, comb_counts = np.unique(
                    observations[:, parents], axis=0, return_counts=True
                )
                for comb, cnt in zip(unique_combs, comb_counts):
                    mask = np.all(observations[:, parents] == comb, axis=1)
                    child_counts = np.bincount(
                        observations[mask, node], minlength=num_values[node]
                    )
                    if use_laplace_smoothing:
                        child_probs = (child_counts + 1) / (cnt + num_values[node])
                    else:
                        child_probs = child_counts / cnt
                    loss -= np.sum(child_counts * np.log(child_probs + 1e-10)) / n
        return loss


# 使用示例
if __name__ == "__main__":
    config, _ = get_config()
    config.model_batch = 1  # 每次生成的网络数量
    config.data_batch = 1000  # 每份数据的样本数
    config.hidden_dim = 8  # 特征向量维度
    config.learning_rate = 1e-2  # 学习率

    import numpy as np

    # 1. 定义网络结构
    adj_matrix = np.array([[0, 1, 0], [1, 0, 1], [0, 1, 0]], dtype=np.float32)

    # 2. 生成匹配的观测数据
    observations = np.column_stack(
        [
            np.random.randint(0, 2, 1000),  # 节点0: 0-1
            np.random.randint(0, 3, 1000),  # 节点1: 0-2
            np.random.randint(0, 2, 1000),  # 节点2: 0-1
        ]
    )

    # 3. 调整隐藏层维度
    node_features = np.random.randn(
        config.model_batch, 3, config.hidden_dim
    )  # 更小的隐藏维度

    # 4. 创建并训练模型
    model = CPT(config, adj=adj_matrix, observations=observations)
    # model.load("models")
    model.train(node_features, num_epochs=10)

    if not os.path.exists("models"):
        os.makedirs("models")
    # 保存和加载模型
    model.save("models")

    model.inspect_lookup_tables("models/lookup_tables.pkl")
    cpt_list = model.infer(node_features[0])  # 使用第一个模型
    model.inspect_cpt_list(cpt_list, "models/cpt_list.pkl")
