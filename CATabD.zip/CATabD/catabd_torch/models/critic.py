# coding=utf-8
# Copyright (C) 2021. Huawei Technologies Co., Ltd. All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import torch
import torch.nn as nn


class Critic(nn.Module):

    def __init__(self, batch_size, max_length, input_dimension, hidden_dim,
                 init_baseline, device=None):
        super().__init__()

        self.batch_size      = batch_size
        self.max_length      = max_length
        self.input_dimension = input_dimension
        # Network config
        self.input_embed     = hidden_dim
        self.num_neurons     = hidden_dim
        self.device     = device

        # Baseline setup
        self.init_baseline = init_baseline

        layer0 = nn.Linear(in_features=self.input_dimension,
                           out_features=self.num_neurons).to(self.device)
        torch.nn.init.xavier_uniform_(layer0.weight)
        self.h0_layer = nn.Sequential(layer0, nn.ReLU()).to(self.device)

        self.layer1 = nn.Linear(in_features=self.num_neurons,
                                out_features=1).to(self.device)
        torch.nn.init.xavier_uniform_(self.layer1.weight)
        self.layer1.bias.data = torch.Tensor([self.init_baseline]).to(self.device)

    def forward(self, encoder_output):
        # [Batch size, Sequence Length, Num_neurons] to [Batch size, Num_neurons]
        frame = torch.mean(encoder_output.detach(), dim=1)

        # ffn 1
        h0 = self.h0_layer(frame)
        # ffn 2
        h1 = self.layer1(h0)
        self.predictions = torch.squeeze(h1)

# import torch
# import torch.nn as nn
# import torch.nn.functional as F
# from torch_geometric.nn import GATConv, global_mean_pool


# class Critic(nn.Module):
#     """简化版GNN Critic，保留GAT和池化架构"""

#     def __init__(self, hidden_dim):
#         super(Critic, self).__init__()
#         # 网络配置
#         self.num_neurons = hidden_dim
#         self.heads = 4

#         # 初始化GAT层和池化层
#         self.gat_layer = GATConv(
#             in_channels=self.num_neurons,
#             out_channels=self.num_neurons,
#             heads=self.heads,  # 单头注意力
#             concat=True,
#             dropout=0.0,
#             add_self_loops=True,  # 自动添加自连接
#         )

#         # 输出层
#         self.output_layer = nn.Linear(self.num_neurons * self.heads, 1)  # 输出维度为1

#     def forward(self, adj, node_features):
#         """
#         简化的GNN预测流程
#         adj: [batch_size, max_length, max_length] 邻接矩阵
#         node_features: [batch_size, max_length, hidden_dim] 节点特征
#         """
#         batch_size, max_length, _ = adj.size()

#         # 准备图数据格式 (PyTorch Geometric需要边缘索引格式)
#         edge_indices = []
#         batch_indices = []

#         # 为每个图样本创建边缘索引
#         for b in range(batch_size):
#             # 获取当前图的邻接矩阵
#             adj_matrix = adj[b]

#             # 转换为边缘索引格式 [2, num_edges]
#             edge_index = (adj_matrix > 0).nonzero().t()

#             # 添加偏移量以处理批次
#             edge_index[0] += b * max_length
#             edge_index[1] += b * max_length

#             edge_indices.append(edge_index)
#             batch_indices.extend([b] * max_length)

#         # 合并所有图的边缘索引
#         edge_index = torch.cat(edge_indices, dim=1)

#         # 重塑节点特征 [batch_size * max_length, hidden_dim]
#         x = node_features.detach().reshape(-1, self.num_neurons)

#         # 批次索引 [batch_size * max_length]
#         batch = torch.tensor(batch_indices, device=node_features.device)

#         # GAT层处理
#         h = F.relu(self.gat_layer(x, edge_index))

#         # 全局平均池化 [batch_size, hidden_dim]
#         graph_embed = global_mean_pool(h, batch)

#         h1 = self.output_layer(graph_embed)

#         # 输出层 [batch_size]
#         self.predictions = torch.squeeze(h1)
