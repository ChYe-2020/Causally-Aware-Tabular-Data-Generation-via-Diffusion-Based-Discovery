# coding=utf-8
# Copyright (C) 2021. Huawei Technologies Co., Ltd. All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import numpy as np
from sklearn.linear_model import LinearRegression
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.preprocessing import PolynomialFeatures
from scipy.spatial.distance import pdist


def BIC_input_graph(X, g, reg_type="LR", score_type="BIC", use_laplace_smoothing=True):
    """cal BIC score for given graph without penalty term"""
    X_int = X.astype(np.int64)
    n_samples, maxlen = X_int.shape

    unique_values = [np.unique(X[:, i]) for i in range(maxlen)]
    value_to_index = [
        {val: idx for idx, val in enumerate(unique_values[i])} for i in range(maxlen)
    ]
    n_categories = [len(uv) for uv in unique_values]

    if score_type == "DB":
        import time

        start = time.time()

        log_likelihood = 0.0
        for i in range(maxlen):
            col = g[i]  # 获取当前节点的列

            if np.sum(col) < 0.1:  # 没有父节点
                counts = np.bincount(
                    [value_to_index[i][val] for val in X[:, i]],
                    minlength=n_categories[i],
                )
                if use_laplace_smoothing:
                    probs = (counts + 1) / (n_samples + n_categories[i])
                else:
                    probs = counts / n_samples
                log_likelihood_node = np.sum(counts * np.log(probs + 1e-10))
            else:
                parents = np.where(col > 0.5)[0]  # 获取父节点的索引
                log_likelihood_node = 0.0

                # 统计父节点组合的唯一取值及频次
                parent_data = X[:, parents]
                parent_combs, parent_counts = np.unique(
                    parent_data, axis=0, return_counts=True
                )
                parent_hash = {
                    tuple(comb): count
                    for comb, count in zip(parent_combs, parent_counts)
                }
                # 统计父节点+子节点组合的唯一取值及频次
                joint_data = np.column_stack((parent_data, X[:, i]))
                joint_combs, joint_counts = np.unique(
                    joint_data, axis=0, return_counts=True
                )
                # 计算似然
                for joint_comb, joint_count in zip(joint_combs, joint_counts):
                    # 分离父节点部分和子节点部分
                    parent_part = joint_comb[:-1]

                    # 找到对应的父节点组合的计数
                    parent_count = parent_hash.get(tuple(parent_part), 0)
                    # 计算概率
                    if use_laplace_smoothing:
                        prob = (joint_count + 1) / (parent_count + n_categories[i])
                    else:
                        prob = joint_count / parent_count

                    log_likelihood_node += joint_count * np.log(prob + 1e-10)

            log_likelihood += log_likelihood_node

        end = time.time()
        print(f"Time taken for log likelihood calculation: {end - start:.4f} seconds")

        return -log_likelihood / n_samples

    else:
        # Original BIC calculation for continuous variables
        RSS_ls = []

        if reg_type in ("LR", "QR"):
            reg = LinearRegression()
        else:
            reg = GaussianProcessRegressor()

        poly = PolynomialFeatures()

        for i in range(maxlen):
            y_ = X[:, [i]]
            inds_x = list(np.abs(g[i]) > 0.1)

            if np.sum(inds_x) < 0.1:
                y_pred = np.mean(y_)
            else:
                X_ = X[:, inds_x]
                if reg_type == "QR":
                    X_ = poly.fit_transform(X_)[:, 1:]
                elif reg_type == "GPR":
                    med_w = np.median(pdist(X_, "euclidean"))
                    X_ = X_ / med_w
                reg.fit(X_, y_)
                y_pred = reg.predict(X_)
            RSSi = np.sum(np.square(y_ - y_pred))

            if reg_type == "GPR":
                RSS_ls.append(RSSi + 1.0)
            else:
                RSS_ls.append(RSSi)

        if score_type == "BIC":
            return np.log(np.sum(RSS_ls) / n_samples + 1e-8)
        elif score_type == "BIC_different_var":
            return np.sum(np.log(np.array(RSS_ls) / n_samples + 1e-8))


def BIC_lambdas(
    X,
    gl=None,
    gu=None,
    gtrue=None,
    reg_type="LR",
    score_type="BIC",
    use_laplace_smoothing=False,
):
    """
    :param X: dataset
    :param gl: input graph to get score lower bound
    :param gu: input graph to get score upper bound
    :param gtrue: input true graph
    :param reg_type: 'LR', 'QR' or 'GPR' (only used for continuous data)
    :param score_type: 'BIC', 'BIC_different_var' or 'DB'
    :param use_laplace_smoothing: whether to use Laplace smoothing for DB score
    :return: score lower bound, score upper bound, true score (only for monitoring)
    """

    n, d = X.shape

    if score_type == "BIC":
        bic_penalty = np.log(n) / (n * d)
    elif score_type == "BIC_different_var":
        bic_penalty = np.log(n) / n
    elif score_type == "DB":
        bic_penalty = 0  # No penalty term for DB score

    # default gl for BIC score: complete graph (except diagonals)
    if gl is None:
        if score_type == "DB":
            gl = np.triu(np.ones((X.shape[1], X.shape[1]), dtype=int), k=1)
        else:
            g_ones = np.ones((d, d))
            for i in range(d):
                g_ones[i, i] = 0
            gl = g_ones
    # default gu for BIC score: empty graph
    if gu is None:
        gu = np.zeros((d, d))

    sl = BIC_input_graph(X, gl, reg_type, score_type, use_laplace_smoothing)
    su = BIC_input_graph(X, gu, reg_type, score_type, use_laplace_smoothing)

    if gtrue is None:
        strue = sl - 10
    else:
        if score_type == "DB":
            # For DB score, no penalty term
            strue = BIC_input_graph(
                X, gtrue, reg_type, score_type, use_laplace_smoothing
            )
        else:
            strue = (
                BIC_input_graph(X, gtrue, reg_type, score_type, use_laplace_smoothing)
                + np.sum(gtrue) * bic_penalty
            )

    return sl, su, strue
