import os


from helpers.config_graph import get_config


from models.vae.tab_vae import train_vae
from models.tabddpm.main_train import train_tabppdm
from models.tabddpm.main_sample import sample_tabppdm

# Configure matplotlib for plotting
import matplotlib

matplotlib.use("Agg")
import os


if __name__ == "__main__":

    os.environ["XLA_FLAGS"] = "--xla_gpu_cuda_data_dir=/home/zh/.conda/envs/zh"

    num_f = {
        "adult": 14,
        "abalone": 9,
        "pm25": 12,
        "adult_o": 15,
        "abalone_o": 10,
        "pm25_o": 13,
        "statlog": 37,
        "shuttle": 10,
        "asia": 8,
        "cancer": 5,
        "survey": 6,
        "syn": 10,
        "sachs": 11,
        "child": 20,
        "alarm": 37,
        "insurance": 27,
        "survey": 6,
        "mildew": 35,
        "water": 32,
        "barley": 48,
    }

    # Get running configuration
    dataset = "barley"  # 数据集名称
    opt_path = f"output/{dataset}"
    device = "cuda:1"  # 使用第一个GPU
    data_path = f"datasets/{dataset}.csv"
    config, _ = get_config()
    config.opt_path = opt_path  # 设置输出路径
    config.max_length = num_f[dataset]  # 最大长度
    config.hidden_dim = 64  # 特征向量维度
    config.lambda_flag_default = (
        True  # 启用自动配置lambda1和lambda2 如果false 则手动指定sl su等参数
    )
    config.transpose = True  # true graph会被转置

    import sys

    train_vae(
        device=device,
        din=3000,
        dout=config.hidden_dim,
        num_samples=1000,  # 指定采样数量
        learning_rate=1e-3,
        batch_size=1024,
        epochs=100,
        data_path=data_path,
        load_model_path=None,
        opt_path=opt_path,
    )
    train_tabppdm(
        steps=10000,
        device=device,
        opt_path=opt_path,
        load_model_path=None,
        n_classes=config.max_length,
    )
    num_samples = 1000  # 采样数量
    sample_tabppdm(
        device=device,
        num_samples=num_samples,
        batch_size=1000,
        ddim=False,
        steps=100,
        num_numerical=config.hidden_dim,
        opt_path=opt_path,
        load_model_path=None,
        n_classes=config.max_length,
    )
