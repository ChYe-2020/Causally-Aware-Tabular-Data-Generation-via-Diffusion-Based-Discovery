"""
用于自定义损失函数的vae部分 新增stats hist mmd hybrid等损失函数
"""

# import os
# from typing import Optional
# from typing import Tuple
# from torch import Tensor

# import torch
# import torch.nn.functional as F

# from ...data.datasets import BaseDataset
# from ..base.base_utils import ModelOutput
# from ..nn import BaseDecoder, BaseEncoder
# from ..vae import VAE
# from .beta_vae_config import BetaVAEConfig


# class BetaVAE(VAE):
#     r"""
#     :math:`\beta`-VAE model.

#     Args:
#         model_config (BetaVAEConfig): The Variational Autoencoder configuration setting the main
#             parameters of the model.

#         encoder (BaseEncoder): An instance of BaseEncoder (inheriting from `torch.nn.Module` which
#             plays the role of encoder. This argument allows you to use your own neural networks
#             architectures if desired. If None is provided, a simple Multi Layer Preception
#             (https://en.wikipedia.org/wiki/Multilayer_perceptron) is used. Default: None.

#         decoder (BaseDecoder): An instance of BaseDecoder (inheriting from `torch.nn.Module` which
#             plays the role of decoder. This argument allows you to use your own neural networks
#             architectures if desired. If None is provided, a simple Multi Layer Preception
#             (https://en.wikipedia.org/wiki/Multilayer_perceptron) is used. Default: None.

#     .. note::
#         For high dimensional data we advice you to provide you own network architectures. With the
#         provided MLP you may end up with a ``MemoryError``.
#     """

#     def __init__(
#         self,
#         model_config: BetaVAEConfig,
#         encoder: Optional[BaseEncoder] = None,
#         decoder: Optional[BaseDecoder] = None,
#     ):

#         VAE.__init__(self, model_config=model_config, encoder=encoder, decoder=decoder)

#         self.model_name = "BetaVAE"
#         self.beta = model_config.beta

#     def forward(self, inputs: BaseDataset, **kwargs):
#         """
#         The VAE model

#         Args:
#             inputs (BaseDataset): The training dataset with labels

#         Returns:
#             ModelOutput: An instance of ModelOutput containing all the relevant parameters

#         """

#         x = inputs["data"]

#         encoder_output = self.encoder(x)

#         mu, log_var = encoder_output.embedding, encoder_output.log_covariance

#         std = torch.exp(0.5 * log_var)
#         z, eps = self._sample_gauss(mu, std)
#         recon_x = self.decoder(z)["reconstruction"]

#         loss, recon_loss, kld = self.loss_function(recon_x, x, mu, log_var, z)

#         output = ModelOutput(
#             recon_loss=recon_loss,
#             reg_loss=kld,
#             loss=loss,
#             recon_x=recon_x,
#             z=z,
#         )

#         return output

#     def loss_function(
#         self,
#         recon_x: Tensor,
#         x: Tensor,
#         mu: Tensor,
#         log_var: Tensor,
#         z: Tensor
#     ) -> Tuple[Tensor, Tensor, Tensor]:
#         """
#         支持多模式选择的损失函数：
#         - 原始选项：mse / bce
#         - 新增选项：stats / hist / mmd / sorted_mse
#         """
#         # 最大均值差异（MMD）损失
#         def _compute_mmd(x: Tensor, y: Tensor, kernel: str = 'multiscale') -> Tensor:
#             """计算批处理MMD，支持高斯核/多尺度核"""
#             xx = torch.flatten(x, start_dim=1)  # (batch, features)
#             yy = torch.flatten(y, start_dim=1)

#             if kernel == 'linear':
#                 k_xx = torch.matmul(xx, xx.T)
#                 k_yy = torch.matmul(yy, yy.T)
#                 k_xy = torch.matmul(xx, yy.T)
#             else:
#                 # 高斯核或多尺度核
#                 def _gaussian_kernel(a: Tensor, b: Tensor, gamma: float = 1.0) -> Tensor:
#                     pairwise_dist = torch.cdist(a, b, p=2) ** 2
#                     return torch.exp(-gamma * pairwise_dist)

#                 if kernel == 'multiscale':
#                     # 多尺度核：组合多个带宽的核
#                     bandwidths = [0.1, 1.0, 10.0]
#                     k_xx = sum(_gaussian_kernel(xx, xx, gamma=1/(2*b)) for b in bandwidths)
#                     k_yy = sum(_gaussian_kernel(yy, yy, gamma=1/(2*b)) for b in bandwidths)
#                     k_xy = sum(_gaussian_kernel(xx, yy, gamma=1/(2*b)) for b in bandwidths)
#                 else:  # 默认单高斯核
#                     gamma = 1.0 / xx.shape[1]  # 自适应带宽
#                     k_xx = _gaussian_kernel(xx, xx, gamma)
#                     k_yy = _gaussian_kernel(yy, yy, gamma)
#                     k_xy = _gaussian_kernel(xx, yy, gamma)

#             # MMD公式
#             mmd = k_xx.mean() + k_yy.mean() - 2 * k_xy.mean()
#             return mmd

#         # 1. KL散度计算（保持不变）
#         KLD = -0.5 * torch.sum(1 + log_var - mu.pow(2) - log_var.exp(), dim=-1)

#         # 2. 重构损失选择器
#         recon_loss: Tensor
#         if self.model_config.reconstruction_loss == "mse":
#             recon_loss = 0.5 * F.mse_loss(
#                 recon_x.reshape(x.shape[0], -1),
#                 x.reshape(x.shape[0], -1),
#                 reduction="none"
#             ).sum(dim=-1)

#         elif self.model_config.reconstruction_loss == "bce":
#             recon_loss = F.binary_cross_entropy(
#                 recon_x.reshape(x.shape[0], -1),
#                 x.reshape(x.shape[0], -1),
#                 reduction="none"
#             ).sum(dim=-1)

#         elif self.model_config.reconstruction_loss == "stats":
#             # 统计分布损失（均值/标准差/分位数）
#             mean_loss = F.l1_loss(recon_x.mean(dim=0), x.mean(dim=0))
#             std_loss = F.l1_loss(recon_x.std(dim=0), x.std(dim=0))
#             quantiles = torch.tensor([0.25, 0.5, 0.75]).to(x.device)
#             quant_loss = F.l1_loss(
#                 torch.quantile(recon_x, quantiles, dim=0),
#                 torch.quantile(x, quantiles, dim=0)
#             )
#             recon_loss = (mean_loss + std_loss + quant_loss).expand(x.shape[0])

#         elif self.model_config.reconstruction_loss == "hist":
#             # 直方图损失（动态bin适应）
#             def _hist_loss(a: Tensor, b: Tensor, bins: int = 10) -> Tensor:
#                 min_val = 0
#                 max_val = 1
#                 hist_a = torch.histc(a, bins=bins, min=min_val, max=max_val) / a.numel()
#                 hist_b = torch.histc(b, bins=bins, min=min_val, max=max_val) / b.numel()
#                 return F.l1_loss(hist_a, hist_b)

#             # 逐样本计算后取平均（保持与其他损失格式一致）
#             batch_loss = torch.stack([
#                 _hist_loss(recon_x[i], x[i]) for i in range(x.shape[0])
#             ])
#             recon_loss = batch_loss * x[0].numel()  # 缩放以匹配MSE/BCE的量级

#         elif self.model_config.reconstruction_loss == "mmd":

#             # 计算整个批次的MMD（保持输出形状与其他损失一致）
#             mmd_loss = _compute_mmd(recon_x, x)
#             recon_loss = mmd_loss.expand(x.shape[0]) * x[0].numel()  # 缩放量级

#         elif self.model_config.reconstruction_loss == "hybrid":
#             # 统计分布损失（均值/标准差/分位数）
#             mean_loss = F.l1_loss(recon_x.mean(dim=0), x.mean(dim=0))
#             std_loss = F.l1_loss(recon_x.std(dim=0), x.std(dim=0))
#             quantiles = torch.tensor([0.25, 0.5, 0.75]).to(x.device)
#             quant_loss = F.l1_loss(
#                 torch.quantile(recon_x, quantiles, dim=0),
#                 torch.quantile(x, quantiles, dim=0)
#             )
#             loss1 = (mean_loss + std_loss + quant_loss).expand(x.shape[0])
#             # 计算整个批次的MMD（保持输出形状与其他损失一致）
#             mmd_loss = _compute_mmd(recon_x, x)
#             loss2 = mmd_loss.expand(x.shape[0]) * x[0].numel()  # 缩放量级
#             recon_loss = (loss1 + loss2) / 2  # 平均两种损失

#         else:
#             raise ValueError(
#                 f"Unsupported loss type: {self.model_config.reconstruction_loss}. "
#                 f"Available: mse / bce / stats / hist / mmd / sorted_mse"
#             )

#         # 总损失计算（保持与原始结构一致）
#         total_loss = (recon_loss + self.beta * KLD).mean(dim=0)
#         return total_loss, recon_loss.mean(dim=0), KLD.mean(dim=0)

#     def _sample_gauss(self, mu, std):
#         # Reparametrization trick
#         # Sample N(0, I)
#         eps = torch.randn_like(std)
#         return mu + eps * std, eps
