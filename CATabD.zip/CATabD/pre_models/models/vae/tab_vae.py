import numpy as np
import torch
import torch.nn as nn
import pandas as pd
import logging
import matplotlib.pyplot as plt
from pythae.models import BetaVAE, BetaVAEConfig
from pythae.trainers import BaseTrainerConfig
from pythae.pipelines.training import TrainingPipeline
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import StandardScaler, MinMaxScaler, OrdinalEncoder
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer

# 准备需要的文件夹
import os


class MixedDecoder(nn.Module):
    def __init__(self, latent_dim, num_continuous, num_categories):
        super().__init__()
        # 共享的隐藏层
        self.shared = nn.Sequential(
            nn.Linear(latent_dim, 512), nn.ReLU(), nn.Linear(512, 1024), nn.ReLU()
        )

        # 连续输出部分
        self.continuous_out = nn.Sequential(
            nn.Linear(1024, num_continuous), nn.Sigmoid()
        )

        # 离散输出部分（假设每个分类特征有对应的类别数）
        self.discrete_outs = nn.ModuleList(
            [
                nn.Sequential(nn.Linear(1024, n_classes), nn.Softmax(dim=-1))
                for n_classes in num_categories
            ]
        )

    def forward(self, z):
        h = self.shared(z)
        cont_out = self.continuous_out(h)
        disc_outs = [out(h) for out in self.discrete_outs]
        return torch.cat([cont_out] + disc_outs, dim=-1)


class TabBetaVAE:
    def __init__(
        self,
        din: int,
        dout: int,
        data_path: str,
        num_samples: int = 1000,  # New parameter for number of samples
        max_length: int = 0,
        learning_rate: float = 1e-3,
        batch_size: int = 64,
        device: str = "cuda:0",
        categorical_features: list = None,
        numerical_features: list = None,
    ):
        """
        初始化表格BetaVAE模型

        参数:
            max_length: 表格列数(特征数量)
            din: 输入维度(采样行数)
            dout: 输出维度(直接作为潜在空间维度)
            num_samples: 采样数量(默认1000)
            learning_rate: 学习率
            batch_size: 批量大小
            device: 训练设备
            categorical_features: 分类特征列名列表
            numerical_features: 数值特征列名列表
        """
        self.max_length = max_length
        self.din = din
        self.dout = dout  # latent_dim = dout
        self.num_samples = num_samples  # Store num_samples
        self.learning_rate = learning_rate
        self.batch_size = batch_size
        self.device = device
        self.categorical_features = categorical_features or []
        self.numerical_features = numerical_features or []
        self.data_path = data_path

        # 初始化日志系统
        self._init_logging("vae_train.log")
        # 初始化预处理管道
        self._init_preprocessor()
        # 加载并预处理数据
        self.load_data(data_path)
        # 初始化模型
        self._init_model()

    def _init_logging(self, log_file: str):
        """配置日志系统"""
        self.logger = logging.getLogger()
        self.logger.setLevel(logging.INFO)

        # 清除现有处理器，避免重复日志
        if self.logger.hasHandlers():
            self.logger.handlers.clear()

        # 文件处理器（保存到文件）
        file_handler = logging.FileHandler(log_file)
        file_handler.setFormatter(
            logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")
        )
        self.logger.addHandler(file_handler)

        # 也可以添加控制台输出（可选）
        console_handler = logging.StreamHandler()
        console_handler.setFormatter(logging.Formatter("%(message)s"))
        self.logger.addHandler(console_handler)

    def _init_preprocessor(self):
        """初始化数据预处理管道"""
        # 数值特征处理管道
        numerical_pipeline = Pipeline(
            [
                ("imputer", SimpleImputer(strategy="median")),  # 填充缺失值
                (
                    "scaler",
                    # StandardScaler(),
                    MinMaxScaler(),
                ),  # 标准化
            ]
        )

        # 分类特征处理管道 - 使用TargetEncoder进行统计编码
        categorical_pipeline = Pipeline(
            [
                ("imputer", SimpleImputer(strategy="most_frequent")),
                (
                    "ordinal",
                    OrdinalEncoder(
                        handle_unknown="use_encoded_value", unknown_value=-1
                    ),
                ),
                (
                    "scaler",
                    # StandardScaler(),
                    MinMaxScaler(),
                ),  # 或 ('scaler', MinMaxScaler())  # 可选的归一化
            ]
        )

        # 组合预处理步骤
        self.preprocessor = ColumnTransformer(
            [
                ("num", numerical_pipeline, self.numerical_features),
                ("cat", categorical_pipeline, self.categorical_features),
            ]
        )

    def _init_model(self):
        """初始化BetaVAE模型（latent_dim = dout）"""
        model_config = BetaVAEConfig(
            input_dim=(self.din,),
            latent_dim=self.dout,
            beta=1,  # beta参数控制KL散度的权重
            reconstruction_loss="hybrid",
        )

        self.model = BetaVAE(
            model_config=model_config,
            encoder=None,  # 使用默认编码器
            decoder=None,  # 使用默认解码器
        ).to(self.device)

        # 打印模型结构
        print(self.model.encoder)
        print(self.model.decoder)

    def load_data(self, csv_path: str) -> np.ndarray:
        """
        数据加载和预处理逻辑：
        1. 读取CSV数据
        2. 自动识别特征类型(如果未指定)
        3. 应用预处理
        4. 准备BetaVAE输入格式(使用放回采样)
        """
        # 读取原始数据
        raw_data = pd.read_csv(csv_path)

        # 如果未指定特征类型，自动识别
        if not self.categorical_features and not self.numerical_features:
            self._auto_detect_features(raw_data)

        # 应用预处理
        processed_data = self.preprocessor.fit_transform(raw_data)
        # processed_data = raw_data.copy().to_numpy()

        # 如果预处理后是稀疏矩阵，转换为密集矩阵
        if hasattr(processed_data, "toarray"):
            processed_data = processed_data.toarray()

        # 更新max_length为预处理后的特征数量
        self.max_length = processed_data.shape[1]
        total_rows = processed_data.shape[0]

        # 保存到csv
        self.processed_df = pd.DataFrame(
            processed_data,
        )

        # 准备BetaVAE输入格式 - 使用放回采样
        result = np.zeros((self.num_samples, self.max_length, self.din + 1))

        for i in range(self.num_samples):
            # 随机选择din个行索引(允许重复)
            batch_rows = np.random.choice(total_rows, size=self.din, replace=True)
            tmp = processed_data[batch_rows].T  # 转置得到[max_length, din]
            # 在每行的最后添加一个额外的维度 表示这个向量是第几个特征列采样的
            # 使用广播一次性添加索引
            result[i, :, :-1] = tmp
            result[i, :, -1] = np.arange(self.max_length)  # [max_length,din+1]

        data = result.astype(np.float32)
        print(f"数据加载完成: {data.shape} (num_samples, max_length, din+1)")
        data_tensor = torch.from_numpy(data).to(self.device)
        self.dataset = data_tensor.reshape(-1, self.din + 1)
        # 实际训练不需要label列
        self.train_dataset = self.dataset[: int(0.8 * self.num_samples), :-1]
        self.eval_dataset = self.dataset[int(0.8 * self.num_samples) :, :-1]

        # 另一种采样方式：直接划分原数据 不放回
        # self.num_samples = total_rows // self.din
        # print(f"采样数量: {self.num_samples} (每{self.din}行采样一次)")
        # # 先打乱行顺序
        # processed_data = processed_data[np.random.permutation(total_rows)]
        # # 截断多余部分
        # processed_data = processed_data[: self.num_samples * self.din]
        # data = processed_data.reshape(
        #     -1, self.din, self.max_length
        # )  # [num_samples, din, max_length]
        # result = np.zeros((self.num_samples, self.max_length, self.din + 1))
        # for i in range(data.shape[0]):
        #     # 在每行的最后添加一个额外的维度 表示这个向量是第几个特征列采样的
        #     # 使用广播一次性添加索引
        #     tmp = data[i].T  # 转置得到[max_length, din]
        #     result[i, :, :-1] = tmp  # 前面din列是特征
        #     result[i, :, -1] = np.arange(self.max_length)

        # data_tensor = torch.from_numpy(result.astype(np.float32)).to(self.device)
        # self.dataset = data_tensor.reshape(
        #     -1, self.din + 1
        # )  # [num_samples * max_length, din + 1]
        # # 实际训练不需要label列
        # self.train_dataset = self.dataset[:, :-1]  # 取全部数据
        # self.eval_dataset = self.dataset[
        #     int(0.8 * self.num_samples * self.max_length) :, :-1
        # ]

        print(
            f"训练集形状: {self.train_dataset.shape} , 验证集形状: {self.eval_dataset.shape}"
        )

    def _auto_detect_features(self, df: pd.DataFrame):
        """自动识别数值型和分类型特征"""
        self.numerical_features = df.select_dtypes(
            include=["int64", "float64"]
        ).columns.tolist()
        self.categorical_features = df.select_dtypes(
            include=["object", "category", "bool"]
        ).columns.tolist()

        print(f"自动识别特征类型:")
        print(f"数值型特征: {self.numerical_features}")
        print(f"分类型特征: {self.categorical_features}")

        # 重新初始化预处理管道
        self._init_preprocessor()

    def train(
        self,
        opt_path: str,
        epochs: int = 10,
    ):
        """训练BetaVAE模型"""

        trainer_config = BaseTrainerConfig(
            output_dir=f"{opt_path}/vae/models",
            learning_rate=self.learning_rate,
            per_device_train_batch_size=self.batch_size,
            per_device_eval_batch_size=self.batch_size,
            num_epochs=epochs,
            optimizer_cls="AdamW",
            optimizer_params={"weight_decay": 0.05, "betas": (0.91, 0.99)},
            no_cuda=self.device == "cpu",
            steps_saving=None,
        )

        pipeline = TrainingPipeline(training_config=trainer_config, model=self.model)
        pipeline(train_data=self.train_dataset, eval_data=self.eval_dataset)

    def encode(self, input_data):
        """编码原始数据为潜在空间表示"""
        # 编码
        latent = self.model.encoder(input_data).embedding
        return latent.detach().cpu().numpy()

    def save_model(self, path: str):
        """保存模型"""
        if not os.path.exists(path):
            os.makedirs(path)
        torch.save(
            {
                "model_state_dict": self.model.state_dict(),
                "config": {
                    "din": self.din,
                    "dout": self.dout,
                    "num_samples": self.num_samples,
                    "learning_rate": self.learning_rate,
                    "batch_size": self.batch_size,
                },
            },
            path + "/vae_model.pt",
        )

    def load_model(self, path: str):
        """加载模型"""
        # path = path + "/vae_model.pt"
        # self.model.load_state_dict(
        #     torch.load(path, map_location=self.device)["model_state_dict"]
        # )
        # self.model.to(self.device)
        # self.logger.info(f"模型加载成功: {path}")
        # # 打印模型参数
        # print(self.model.encoder.__dict__)
        self.model = BetaVAE.load_from_folder(
            path,
        ).to(self.device)


def train_vae(
    device="cuda:0",  # 使用第二个GPU
    din=3000,
    dout=64,
    num_samples=10000,  # 指定采样数量
    learning_rate=1e-3,
    batch_size=1024,
    epochs=100,
    data_path=None,
    load_model_path=None,
    opt_path=None,
):
    """训练BetaVAE模型
    参数:
        device: 训练设备
        din: 输入维度(采样行数)
        dout: 输出维度(直接作为潜在空间维度)
        num_samples: 采样数量
        learning_rate: 学习率
        batch_size: 批量大小
        data_path: 数据路径
        epochs: 训练轮数
    """
    if not os.path.exists(f"{opt_path}/vae/data"):
        os.makedirs(f"{opt_path}/vae/data", exist_ok=True)
    if not os.path.exists(f"{opt_path}/vae/models"):
        os.makedirs(f"{opt_path}/vae/models", exist_ok=True)
    if not os.path.exists(f"{opt_path}/vae/data/reconstruct"):
        os.makedirs(f"{opt_path}/vae/data/reconstruct", exist_ok=True)
    if not os.path.exists(f"{opt_path}/vae/data/encode"):
        os.makedirs(f"{opt_path}/vae/data/encode", exist_ok=True)

    vae = TabBetaVAE(
        device=device,
        din=din,
        dout=dout,
        num_samples=num_samples,  # 指定采样数量
        learning_rate=learning_rate,
        batch_size=batch_size,
        data_path=data_path,
        # categorical_features=categorical_cols,
        # numerical_features=numerical_cols,
    )

    # load模型
    if load_model_path:
        vae.load_model(load_model_path)

    # 训练模型
    vae.train(epochs=epochs, opt_path=opt_path)

    # 保存预处理后的数据
    vae.processed_df.to_csv(f"{opt_path}/vae/data/processed_data.csv", index=False)

    # 重构示例数据
    n = 15  # 重构前15个样本
    print(vae.eval_dataset.device)
    print(vae.device)
    print(vae.model.device)
    vae.model.to(vae.device)
    recon = vae.model.reconstruct(vae.eval_dataset[:n].to(vae.device)).detach().cpu()
    print(f"重构结果形状: {recon.shape}")
    print(f"原始数据形状: {vae.eval_dataset.cpu().numpy().shape}")
    # 保存到CSV文件
    recon_df = pd.DataFrame(recon.numpy())
    recon_df.to_csv(
        f"{opt_path}/vae/data/reconstruct/reconstructed_data.csv", index=False
    )
    print(f"重构数据已保存到: {opt_path}/vae/data/reconstruct/reconstructed_data.csv")
    df = pd.DataFrame(vae.eval_dataset[:n].cpu().numpy())
    df.to_csv(f"{opt_path}/vae/data/reconstruct/original_data.csv", index=False)
    print(f"原始数据已保存到: {opt_path}/vae/data/reconstruct/original_data.csv")

    # 编码示例数据
    data = vae.dataset[:10000]
    x = data[:, :-1]  # 去掉最后一列label
    y = data[:, -1]  # 最后一列label
    encoded_data = vae.encode(x)
    encoded_data = np.append(
        encoded_data, y.unsqueeze(1).cpu().numpy(), axis=1
    )  # 添加label列
    print(f"编码结果形状: {encoded_data.shape}")
    # 保存编码结果
    np.save(f"{opt_path}/vae/data/encode/encoded_data.npy", encoded_data)
    pd.DataFrame(encoded_data).to_csv(
        f"{opt_path}/vae/data/encode/encoded_data.csv", index=False
    )


# 示例用法
if __name__ == "__main__":
    # 指定特征类型
    categorical_cols = [
        "workclass",
        "education",
        "marital-status",
        "occupation",
        "relationship",
        "race",
        "sex",
        "native-country",
    ]
    numerical_cols = [
        "age",
        # "fnlwgt",
        # "education-num",
        # "hours-per-week",
    ]

    # 初始化模型
    vae = TabBetaVAE(
        device="cuda:0",  # 使用第二个GPU
        din=3000,
        dout=64,
        num_samples=1000,  # 指定采样数量
        learning_rate=1e-3,
        batch_size=1024,
        data_path="datasets/adult-raw.csv",
        # categorical_features=categorical_cols,
        # numerical_features=numerical_cols,
    )

    # load模型
    # vae.load_model("output/models/vae/syn/final_model")

    # 训练模型
    vae.train(epochs=300, opt_path="test")

    # 保存模型
    # vae.save_model("output/models/vae/syn")

    # 重构示例数据
    n = 15  # 重构前15个样本
    recon = vae.model.reconstruct(vae.eval_dataset[:n].to(vae.device)).detach().cpu()
    print(f"重构结果形状: {recon.shape}")
    print(f"原始数据形状: {vae.eval_dataset.cpu().numpy().shape}")
    # 保存到CSV文件
    recon_df = pd.DataFrame(recon.numpy())
    recon_df.to_csv(f"reconstructed_data.csv", index=False)
    df = pd.DataFrame(vae.eval_dataset[:n].cpu().numpy())
    df.to_csv(f"original_data.csv", index=False)

    # 编码示例数据
    data = vae.dataset[:10000]
    x = data[:, :-1]  # 去掉最后一列label
    y = data[:, -1]  # 最后一列label
    encoded_data = vae.encode(x)
    encoded_data = np.append(
        encoded_data, y.unsqueeze(1).cpu().numpy(), axis=1
    )  # 添加label列
    print(f"编码结果形状: {encoded_data.shape}")
    pd.DataFrame(encoded_data).to_csv(f"encoded_data.csv", index=False)
