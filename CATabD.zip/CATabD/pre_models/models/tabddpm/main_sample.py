import os
import argparse
import sys
from pathlib import Path


from models.tabddpm.sample import DiffusionSampler
from models.tabddpm import util


def sample_tabppdm(
    device="cuda:0",
    num_samples=1000,
    batch_size=1000,
    ddim=False,
    steps=100,
    num_numerical=None,
    n_classes=2,
    opt_path=None,
    load_model_path=None,
):

    model_save_path = f"{opt_path}/tabppdm/models"
    read_data_path = f"{opt_path}/vae/data/encode/encoded_data.npy"
    sample_save_path = f"{opt_path}/tabppdm/data/sampled_data.csv"

    if not os.path.exists(sample_save_path):
        os.makedirs(f"{opt_path}/tabppdm/data", exist_ok=True)

    print("START SAMPLING")
    diffusion = DiffusionSampler(
        num_numerical=num_numerical,
        model_save_path=model_save_path,
        device=device,
        n_classes=n_classes,
        real_data_path=read_data_path,
    )

    diffusion.sample(
        num_samples=num_samples,
        batch_size=batch_size,
        ddim=ddim,
        steps=steps,
        save_path=sample_save_path,
    )


if __name__ == "__main__":

    parser = argparse.ArgumentParser(description="tabddpm")
    parser.add_argument("--dataname", type=str, default="adult")
    parser.add_argument("--gpu", type=int, default=0)
    parser.add_argument(
        "--ddim",
        action="store_true",
        default=False,
        help="Whether to use ddim sampling.",
    )
    parser.add_argument("--steps", type=int, default=10)

    args = parser.parse_args()

    sample_tabppdm(args)
