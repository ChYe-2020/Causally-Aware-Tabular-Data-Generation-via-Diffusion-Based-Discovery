import numpy as np
import os

from models.tabddpm import data, util
from torch.utils.data import Dataset


class TabularDataset(Dataset):
    def __init__(self, X_num, X_cat):
        self.X_num = X_num
        self.X_cat = X_cat

    def __getitem__(self, index):
        this_num = self.X_num[index]
        this_cat = self.X_cat[index]

        sample = (this_num, this_cat)

        return sample

    def __len__(self):
        return self.X_num.shape[0]


def preprocess(
    dataset_path, task_type="binclass", inverse=False, cat_encoding=None, concat=True
):

    T_dict = {}

    T_dict["normalization"] = "quantile"
    T_dict["num_nan_policy"] = "mean"
    T_dict["cat_nan_policy"] = None
    T_dict["cat_min_frequency"] = None
    T_dict["cat_encoding"] = cat_encoding
    T_dict["y_policy"] = "default"

    T = data.Transformations(**T_dict)

    dataset = make_dataset(
        data_path=dataset_path,
        T=T,
        task_type=task_type,
        change_val=False,
        concat=concat,
    )

    if cat_encoding is None:
        X_num = dataset.X_num
        X_cat = dataset.X_cat

        X_train_num, X_test_num = X_num["train"], X_num["test"]
        X_train_cat, X_test_cat = X_cat["train"], X_cat["test"]

        categories = util.get_categories(X_train_cat)
        d_numerical = X_train_num.shape[1]

        X_num = (X_train_num, X_test_num)
        X_cat = (X_train_cat, X_test_cat)

        if inverse:
            num_inverse = dataset.num_transform.inverse_transform
            cat_inverse = dataset.cat_transform.inverse_transform

            return X_num, X_cat, categories, d_numerical, num_inverse, cat_inverse
        else:
            return X_num, X_cat, categories, d_numerical
    else:
        return dataset


def update_ema(target_params, source_params, rate=0.999):
    """
    Update target parameters to be closer to those of source parameters using
    an exponential moving average.
    :param target_params: the target parameter sequence.
    :param source_params: the source parameter sequence.
    :param rate: the EMA rate (closer to 1 means slower).
    """
    for target, source in zip(target_params, source_params):
        target.detach().mul_(rate).add_(source.detach(), alpha=1 - rate)


def concat_y_to_X(X, y):
    if X is None:
        return y.reshape(-1, 1)
    return np.concatenate([y.reshape(-1, 1), X], axis=1)


def make_dataset(
    data_path: str,
    T: data.Transformations,
    change_val: bool,
    n_classes: int = 1,
):

    # Load the dataset and split

    X = np.load(data_path, allow_pickle=True)
    X_num = {}
    # 70% train 30% test
    indices = np.arange(X.shape[0])
    np.random.shuffle(indices)
    train_size = int(0.7 * X.shape[0])
    train_indices = indices[:train_size]
    test_indices = indices[train_size:]
    X_num["train"] = X[train_indices, :]
    X_num["test"] = X[test_indices, :]

    X = np.load(data_path, allow_pickle=True)
    X_num = {}
    y = {}
    indices = np.arange(X.shape[0])
    np.random.shuffle(indices)
    train_size = int(0.7 * X.shape[0])
    train_indices = indices[:train_size]
    test_indices = indices[train_size:]
    # X是除了最后一列的数值特征 y是最后一列的标签
    X_num["train"] = X[train_indices, :-1]  # 数值特征
    X_num["test"] = X[test_indices, :-1]  # 数值特征
    y["train"] = X[train_indices, -1]  # 标签
    y["test"] = X[test_indices, -1]  # 标签

    D = data.Dataset(
        X_num,
        None,
        y,
        y_info={},
        task_type="multiclass",  # 多分类任务
        n_classes=n_classes,
    )

    if change_val:
        D = data.change_val(D)

    # def categorical_to_idx(feature):
    #     unique_categories = np.unique(feature)
    #     idx_mapping = {category: index for index, category in enumerate(unique_categories)}
    #     idx_feature = np.array([idx_mapping[category] for category in feature])
    #     return idx_feature

    # for split in ['train', 'val', 'test']:
    # D.y[split] = categorical_to_idx(D.y[split].squeeze(1))

    return data.transform_dataset(D, T, None)
