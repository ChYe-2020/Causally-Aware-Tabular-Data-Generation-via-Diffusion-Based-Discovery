import torch
import numpy as np
import pandas as pd
import time
from typing import Optional

from .models_.gaussian_multinomial_distribution import GaussianMultinomialDiffusion
from .models_.modules import MLPDiffusion
from . import data
from .utils_train import make_dataset


class DiffusionSampler:
    def __init__(
        self,
        model_save_path: str,
        real_data_path: str,
        num_numerical: int = 0,
        n_classes: int = 2,
        num_timesteps: int = 1000,
        gaussian_loss_type: str = "mse",
        scheduler: str = "cosine",
        device: torch.device = torch.device("cuda:0"),
    ):
        """
        初始化扩散模型采样器，加载模型一次，后续可多次采样

        参数:
            model_save_path: 模型保存路径
            real_data_path: 真实数据路径
            task_type: 任务类型 ('binclass', 'multiclass', 'regression')
            model_type: 模型类型 ('mlp')
            model_params: 模型参数
            num_timesteps: 扩散步数
            gaussian_loss_type: 高斯损失类型 ('mse', 'kl')
            scheduler: 调度器类型 ('cosine', 'linear')
            T_dict: 数据转换参数
            disbalance: 不平衡处理参数
            device: 计算设备
            change_val: 是否改变验证集
        """
        self.device = device
        self.model_type = "mlp"  # 目前仅支持 MLP 模型
        self.model_params = {
            "d_in": num_numerical,
            "num_classes": n_classes,
            "is_y_cond": True,
            "rtdl_params": {
                "d_layers": [
                    1024,
                    2048,
                    2048,
                    1024,
                ],
                "dropout": 0.0,
            },
        }
        self.num_timesteps = num_timesteps
        self.gaussian_loss_type = gaussian_loss_type
        self.scheduler = scheduler
        self.n_classes = n_classes

        # 初始化数据转换和数据集
        T_dict = {
            "seed": 0,
            "normalization": "quantile",
            "num_nan_policy": "mean",
            "cat_nan_policy": "__none__",
            "cat_min_frequency": "__none__",
            "cat_encoding": "__none__",
            "y_policy": "default",
        }
        T = data.Transformations(**T_dict)

        self.D = make_dataset(
            T=T,
            data_path=real_data_path,
            change_val=False,
            n_classes=n_classes,
        )

        # 初始化模型
        K = np.array([0])
        self.model = self._get_model("mlp", self.model_params)
        model_path = f"{model_save_path}/model.pt"
        self.model.load_state_dict(torch.load(model_path, map_location="cpu"))

        # 初始化扩散模型
        self.diffusion = GaussianMultinomialDiffusion(
            K,
            num_numerical_features=num_numerical,
            denoise_fn=self.model,
            num_timesteps=num_timesteps,
            gaussian_loss_type=gaussian_loss_type,
            scheduler=scheduler,
            device=device,
        )

        self.diffusion.to(device)
        self.diffusion.eval()

    def _get_model(self, model_name: str, model_params: dict):
        """获取指定类型的模型"""
        if model_name == "mlp":
            return MLPDiffusion(**model_params)
        raise ValueError(f"Unknown model: {model_name}")

    @torch.no_grad()
    def sample(
        self,
        num_samples: int,
        batch_size: int = 2000,
        ddim: bool = False,
        steps: int = 1000,
        save_path: Optional[str] = None,
    ) -> np.ndarray:
        """
        执行采样

        参数:
            num_samples: 要生成的样本数量
            batch_size: 批量大小
            ddim: 是否使用DDIM采样
            steps: DDIM采样步数

        返回:
            生成的样本数组，形状为 [d, batch_size]
        """
        start_time = time.time()
        x_gen = []
        for i in range(self.n_classes):
            y = torch.tensor([i], device=self.device)
            if not ddim:
                x_gen.append(
                    self.diffusion.sample_all(num_samples, batch_size, ddim=False, y=y)
                )
            else:
                x_gen.append(
                    self.diffusion.sample_all(
                        num_samples, batch_size, ddim=True, steps=steps, y=y
                    )
                )

        # x_gen = x_gen.T  # 转置为 [d, batch_size] 形状

        num_inverse = self.D.num_transform.inverse_transform

        for i in range(self.n_classes):
            # 逆变换
            syn_data = num_inverse(x_gen[i]).astype(np.float32)  # 去掉最后一列
            # save to csv
            df = pd.DataFrame(syn_data)
            path_i = save_path.replace(".csv", f"_{i}.csv")
            df.to_csv(path_i, index=False)

        end_time = time.time()
        # print("采样时间:", end_time - start_time)
        # print("输出数组形状:", x_gen.shape)
        # print("输出数组前5行:", x_gen[0])

        return syn_data
