import os
from models.tabddpm.train import train




def train_tabppdm(
    steps=10000,
    n_classes=2,
    device="cuda:0",
    opt_path=None,
    load_model_path=None,
):

    model_save_path = f"{opt_path}/tabppdm/models"
    real_data_path = f"{opt_path}/vae/data/encode/encoded_data.npy"

    if not os.path.exists(model_save_path):
        os.makedirs(model_save_path)

    print("START TRAINING")
    train(
        model_save_path=model_save_path,
        model_load_path=load_model_path,
        real_data_path=real_data_path,
        model_type="mlp",
        steps=steps,
        n_classes=n_classes,
        device=device,
    )


if __name__ == "__main__":
    train_tabppdm(
        steps=10000,
        device="cuda:0",
        opt_path=None,
        load_model_path=None,
    )
